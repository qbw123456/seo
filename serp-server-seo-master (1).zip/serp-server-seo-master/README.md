# SEO 关键词排名

## 部署

### 编译
```shell
go build -o seo --ldflags "-w -s"
```

### 配置

复制配置文件 `resources\config.remote.dev.yaml` 存为 `config.prod.yaml`

修改 `config.prod.yaml` 中的关键配置项

```yaml
server:
  mode: prod         # 应用程序运行模式（dev开发环境、test测试环境、prod线上环境）
  host: 0.0.0.0     # 服务器IP地址，默认使用0.0.0.0
  name: dilu-seo      # 服务名称
  node: 1           # 服务节点ID，建议每个节点设置不同的ID，范围0-1023
  port: 9998       # 服务端口号
  remote-enable: true
remote:
  provider: consul
  endpoint: 10.0.0.222:8500
  path: /projects/server/prod/serp-seo.yaml
  secret-keyring: xxxx
  config-type: yaml
```

## 运行

```shell
./seo start -c .\config.prod.yaml
```

## consul

```shell
consul kv get -token=35d535b3-8d2a-2882-82c8-d01e1228ad69 -http-addr=http://localhost:8500 projects/server/test/serp-seo.yaml
consul kv get -token=35d535b3-8d2a-2882-82c8-d01e1228ad69 -http-addr=http://43.159.143.42:8500 projects/server/test/serp-seo.yaml
```