package start

var AppRouters = make([]func(), 0)
