package start

import "dilu/modules/prometheus/router"

func init() {
	AppRouters = append(AppRouters, router.InitRouter)
}
