package start

import (
	"dilu/modules/tools/router"
)

func init() {
	AppRouters = append(AppRouters, router.InitRouter)
}
