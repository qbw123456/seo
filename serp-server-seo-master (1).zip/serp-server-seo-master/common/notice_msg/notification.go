package notice_msg

import (
	"log/slog"
)

type Notification struct {
	notifier Notifier
}

func NewNotification(notifier Notifier) *Notification {
	return &Notification{
		notifier: notifier,
	}
}

func (n *Notification) Notice() {
	go func() {
		defer func() {
			if err := recover(); err != nil {
				slog.Error("发送用户通知错误", err)
			}
		}()

		_ = n.notifier.Send()
	}()
}
