package notice_msg

type Notifier interface {
	Send() error
}
