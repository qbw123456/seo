package notice_msg

import (
	"dilu/common/third/ding"
	"fmt"
)

var dinDinNoticeMsg = "【SDK充值】SDK有用户充值了！！！用户手机号/邮箱：%d,充值额度：%s"

type DingDing struct {
	Token     string
	UserId    int64
	UserName  string
	PayAmount string
}

func (d *DingDing) Send() error {
	dataDing := fmt.Sprintf(dinDinNoticeMsg, d.UserId, d.PayAmount)
	ding.SendDingMsg(dataDing, DinDinApiToken, "")
	return nil
}
