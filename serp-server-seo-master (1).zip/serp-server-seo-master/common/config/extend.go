package config

import (
	"time"

	coreConfig "github.com/baowk/dilu-core/config"
	"github.com/baowk/dilu-rd/config"
)

var Ext *Extend

func init() {
	Ext = new(Extend)
}

type Extend struct {
	AdminJWT  coreConfig.JWT `mapstructure:"admin-jwt" json:"admin-jwt" yaml:"admin-jwt"` //后台jwt配置
	Ding      DingCfg        `mapstructure:"ding" json:"ding" yaml:"ding"`
	RdConfig  config.Config  `mapstructure:"rd-config" json:"rd-config" yaml:"rd-config"`
	AesKey    string         `mapstructure:"aes-key" json:"aes-key" yaml:"aes-key"`
	SerpAPI   SerpAPIConfig  `mapstructure:"serp-api" json:"serp-api" yaml:"serp-api"`
	Scheduler Scheduler      `mapstructure:"scheduler" json:"scheduler" yaml:"scheduler"`
}

type DingCfg struct {
	AgentId   string `mapstructure:"agent-id" json:"agent-id" yaml:"agent-id"`
	AppKey    string `mapstructure:"app-key" json:"app-key" yaml:"app-key"`
	AppSecret string `mapstructure:"app-secret" json:"app-secret" yaml:"app-secret"`
	CropId    string `mapstructure:"crop-id" json:"crop-id" yaml:"crop-id"`
}

type OpenMap struct {
	GatewayUrl   string `mapstructure:"gateway-url" json:"gateway-url" yaml:"gateway-url"`
	UserRoute    string `mapstructure:"user-route" json:"user-route" yaml:"user-route"`
	SearchLogUrl string `mapstructure:"search-log-url" json:"search-log-url" yaml:"search-log-url"`
}

type SerpAPIConfig struct {
	Host       string           `mapstructure:"host" json:"host" yaml:"host"`
	ApiKey     string           `mapstructure:"api-key" json:"api-key" yaml:"api-key"`
	MaxPage    int              `mapstructure:"max-page" json:"max-page" yaml:"max-page"`
	ChargeBase ChargeBaseConfig `mapstructure:"charge-base" json:"charge-base" yaml:"charge-base"`
}

type ChargeBaseConfig struct {
	BaseOne int `mapstructure:"baseOne" json:"baseOne" yaml:"baseOne"`
	BaseTwo int `mapstructure:"baseTwo" json:"baseTwo" yaml:"baseTwo"`
}

type Scheduler struct {
	Enable          bool          `mapstructure:"enable" json:"enable" yaml:"enable"`
	Type            string        `mapstructure:"type" json:"type" yaml:"type"`
	ScanCronExpr    string        `mapstructure:"scan-cron-expr" json:"scan-cron-expr" yaml:"scan-cron-expr"`
	MinScanInterval time.Duration `mapstructure:"min-scan-interval" json:"min-scan-interval" yaml:"min-scan-interval"`
	MaxScanInterval time.Duration `mapstructure:"max-scan-interval" json:"max-scan-interval" yaml:"max-scan-interval"`
	Worker          WorkerConfig  `mapstructure:"worker" json:"worker" yaml:"worker"`
}

type WorkerConfig struct {
	MaxWorkers     int `mapstructure:"max-workers" json:"max-workers" yaml:"max-workers"`
	TaskQueueSize  int `mapstructure:"task-queue-size" json:"task-queue-size" yaml:"task-queue-size"`
	BatchSize      int `mapstructure:"batch-size" json:"batch-size" yaml:"batch-size"`
	ScanWindowMins int `mapstructure:"scan-window-mins" json:"scan-window-mins" yaml:"scan-window-mins"`
}
