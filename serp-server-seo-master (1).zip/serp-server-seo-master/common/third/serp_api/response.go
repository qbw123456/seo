package serp_api

import (
	"encoding/json"
	"fmt"
)

// Responses 详情参数
type Responses struct {
	ReqId string      `json:"reqId"`
	Code  int         `json:"code"`
	Msg   string      `json:"msg"`
	Data  interface{} `json:"data"`
}

type SearchAPIData struct {
	OrganicResults []OrganicResults `json:"organic_results"`
	Pagination     Pagination       `json:"pagination"`
}

type OrganicResults struct {
	Position      int         `json:"position"`       // 排名位置
	Title         string      `json:"title"`          // 标题
	Link          interface{} `json:"link"`           // 兼容：Google 返回 []string，Bing 返回 string
	RedirectLink  string      `json:"redirect_link"`  // 重定向链接
	DisplayedLink string      `json:"displayed_link"` //跳转链接
	Marker        Marker      `json:"marker,omitempty"`
}

type Marker struct {
	Name string `json:"name"`
	Link string `json:"link"`
}

type Pagination struct {
	Current interface{} `json:"current"`
	Next    string      `json:"next"`
}

// ToSearchAPIData 将 interface{} 转换为 SearchAPIData
func ToSearchAPIData(data interface{}) (*SearchAPIData, error) {
	if data == nil {
		return nil, fmt.Errorf("data is nil")
	}

	// 如果已经是 SearchAPIData 类型，直接返回
	if searchAPIData, ok := data.(SearchAPIData); ok {
		return &searchAPIData, nil
	}

	// 如果是 map，需要 JSON 重新解析
	if m, ok := data.(map[string]interface{}); ok {
		jsonBytes, err := json.Marshal(m)
		if err != nil {
			return nil, fmt.Errorf("failed to marshal data: %w", err)
		}

		var result SearchAPIData
		if err := json.Unmarshal(jsonBytes, &result); err != nil {
			return nil, fmt.Errorf("failed to unmarshal data: %w", err)
		}

		return &result, nil
	}

	return nil, fmt.Errorf("unsupported data type: %T", data)
}
