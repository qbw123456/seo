package serp_api

import (
	"net/http"
	"time"
)

// ClientOption 客户端选项函数
type ClientOption func(config *Config)

// WithHTTPClient 设置自定义客户端
func WithHTTPClient(client *http.Client) ClientOption {
	return func(c *Config) {
		c.HTTPClient = client
	}
}

// WithTimeout 设置超时
func WithTimeout(timeout time.Duration) ClientOption {
	return func(c *Config) {
		c.TimeOut = timeout
		c.HTTPClient.Timeout = timeout
	}
}

// WithRetryWaitBase 设置重试等待时间
func WithRetryWaitBase(waitTime time.Duration) ClientOption {
	return func(c *Config) {
		c.RetryWaitBase = waitTime
	}
}

func WithApiKey(apiKey string) ClientOption {
	return func(c *Config) {
		c.APIKey = apiKey
	}
}

func WithHost(host string) ClientOption {
	return func(c *Config) {
		c.Host = host
	}
}
