package serp_api

import (
	"fmt"
	"testing"
	"time"
)

func TestEngineRequest(t *testing.T) {
	client := NewSerpApiClientWithOptions(
		WithTimeout(1*time.Minute),
		WithRetryWaitBase(3),
		WithHost("https://us.serp.sharklogin.com"),
		WithApiKey("c88ddd41cec145e1ac48a71d95671cfb"),
	)

	req := Request{
		EngineApi: GOOGLE_API,
		Keywords:  "苍井空",
	}

	ret, retErr := client.CallWithRequest(req)

	if retErr != nil {
		fmt.Println("获取请求结果失败", retErr)
	}

	// 使用 ToSearchAPIData 解析数据
	searchAPIData, err := ToSearchAPIData(ret.Data)
	if err != nil {
		fmt.Println("解析数据失败", err)
		return
	}

	fmt.Printf("请求结果; %+v", len(searchAPIData.OrganicResults))
}
