package serp_api

import (
	"dilu/common/config"
	"net/http"
	"time"
)

type Config struct {
	APIKey        string        // api key
	Host          string        // 请求域名
	API           string        // 请求api接口
	Engine        string        // 请求浏览器引擎
	MaxRetries    int           // 重试次数
	HTTPClient    *http.Client  // http 客户端
	TimeOut       time.Duration // 超时设置
	ChargeBaseOne int           // 扣费基数 1
	ChargeBaseTwo int           // 扣费基数 2
	RetryWaitBase time.Duration
}

func DefaultConfig() *Config {
	return &Config{
		APIKey:        config.Ext.SerpAPI.ApiKey,
		ChargeBaseOne: config.Ext.SerpAPI.ChargeBase.BaseOne,
		ChargeBaseTwo: config.Ext.SerpAPI.ChargeBase.BaseTwo,
		TimeOut:       30 * time.Second,
		RetryWaitBase: 1 * time.Second,
		MaxRetries:    3,
		HTTPClient: &http.Client{
			Timeout: 30 * time.Second,
		},
	}
}
