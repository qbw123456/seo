package serp_api

func NewSerpApiClientWithOptions(opts ...ClientOption) *Client {
	var engineOptions []ClientOption

	allOpts := append(engineOptions, opts...)

	client := NewClient(allOpts...)
	return client
}
