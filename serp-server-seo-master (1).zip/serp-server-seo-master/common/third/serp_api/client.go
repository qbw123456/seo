package serp_api

import (
	"bytes"
	"dilu/common/config"
	"encoding/json"
	"fmt"
	"io"
	"log/slog"
	"net/http"
	"sync"
	"time"
)

// Client 自定义配置
type Client struct {
	httpClient *http.Client
	config     *Config
	Url        string
	ApiKey     string
}

// NewClient 初始化客户端
func NewClient(opts ...ClientOption) *Client {
	cfg := DefaultConfig()

	for _, opt := range opts {
		opt(cfg)
	}

	// 初始化客户端
	defClient := http.DefaultClient
	defClient.Timeout = cfg.TimeOut

	url := config.Ext.SerpAPI.Host

	if url == "" {
		url = cfg.Host
	}

	client := &Client{
		httpClient: defClient,
		ApiKey:     cfg.APIKey,
		Url:        url,
		config:     cfg,
	}

	return client
}

// CallWithRequest 发起请求
func (client *Client) CallWithRequest(req Request) (*Responses, error) {
	if client.ApiKey == "" && client.config.APIKey == "" {
		return nil, fmt.Errorf("api key is empty")
	}

	var lastErr error

	maxRetries := client.config.MaxRetries

	for attempt := 1; attempt <= maxRetries; attempt++ {
		if attempt > 1 {
			slog.Error(fmt.Sprintf("serp api call failed，retrying (%d/%d)...", attempt, maxRetries))
		}

		// start request
		result, err := client.callWithRequest(req)
		if err == nil {
			return result, nil
		}

		lastErr = err

		if attempt < maxRetries {
			waitTime := client.config.RetryWaitBase * time.Duration(attempt)
			slog.Warn(fmt.Sprintf("wait %v before retry...", waitTime))
			time.Sleep(waitTime)
		}
	}

	return nil, fmt.Errorf("the retry request still failed  %d retries: %w", maxRetries, lastErr)
}

func (client *Client) buildRequest(url string, jsonData []byte) (*http.Request, error) {
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, fmt.Errorf("fail to build request: %w", err)
	}

	req.Header.Set("Content-Type", "application/json")

	slog.Info(fmt.Sprintf("request params %s, %s", url, string(jsonData)))
	return req, nil
}

// 发起请求
func (client *Client) callWithRequest(req Request) (*Responses, error) {
	requestBody := client.buildRequestBodyFromRequest(req)

	jsonData, err := client.marshalRequestBody(requestBody)
	if err != nil {
		return nil, err
	}

	httpReq, err := client.buildRequest(client.Url+req.EngineApi, jsonData)

	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	resp, err := client.httpClient.Do(httpReq)
	if err != nil {
		return nil, fmt.Errorf("failed to send request: %w", err)
	}

	defer func() { _ = resp.Body.Close() }()

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response: %w", err)
	}

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("api returned error (status %d): %s", resp.StatusCode, string(body))
	}

	result, err := client.parseResponse(body)
	if err != nil {
		return nil, fmt.Errorf("fail to parse from serp api response: %w", err)
	}

	return result, nil
}

func (client *Client) marshalRequestBody(requestBody map[string]any) ([]byte, error) {
	jsonData, err := json.Marshal(requestBody)
	if err != nil {
		return nil, fmt.Errorf("failed to serialize request: %w", err)
	}

	return jsonData, nil
}

// 构建请求参数
func (client *Client) buildRequestBodyFromRequest(req Request) map[string]any {
	apiKey := client.ApiKey

	requestBody := map[string]interface{}{
		"api_key": apiKey,
		"q":       req.Keywords,
	}

	switch req.EngineType {
	case ENGINE_TO_BING:
		requestBody["first"] = req.First
	default:
		requestBody["start"] = req.Start
	}

	return requestBody
}

// 解析结果
func (client *Client) parseResponse(body []byte) (*Responses, error) {
	var res *Responses

	if err := json.Unmarshal(body, &res); err != nil {
		return res, fmt.Errorf("json parese error: %w", err)
	}

	return res, nil
}

// defaultClient 默认客户端单例
var (
	defaultClient *Client
	clientOnce    sync.Once
)

// GetDefaultClient 获取默认客户端单例
func GetDefaultClient() *Client {
	clientOnce.Do(func() {
		defaultClient = NewClient(
			WithTimeout(1*time.Minute),
			WithRetryWaitBase(3),
		)
		slog.Info("Serp API 默认客户端初始化成功")
	})
	return defaultClient
}

// CallWithDefaultClient 使用默认客户端发起请求
func CallWithDefaultClient(req Request) (*Responses, error) {
	return GetDefaultClient().CallWithRequest(req)
}
