package serp_api

const (
	GOOGLE_API       = "/api/v1/open/search"      // goggle api
	BING_API         = "/api/v1/open/bing/search" // bing api
	ENGINE_TO_BING   = "bing"
	ENGINE_TO_GOOGLE = "google"
)

var SerpApiMap = map[string]string{
	ENGINE_TO_BING:   BING_API,
	ENGINE_TO_GOOGLE: GOOGLE_API,
}
