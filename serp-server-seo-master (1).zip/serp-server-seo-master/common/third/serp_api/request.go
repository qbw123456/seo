package serp_api

// Request 请求参数
type Request struct {
	EngineName string `json:"engineName"`          // 引擎名称，当前只用于google
	EngineType string `json:"engineType"`          // 引擎类型，google | bing | ....
	Keywords   string `json:"keywords"`            // 关键词
	Start      int    `json:"start,omitempty"`     // google page
	First      int    `json:"first,omitempty"`     // bing page
	EngineApi  string `json:"engineApi,omitempty"` // 请求api地址
}
