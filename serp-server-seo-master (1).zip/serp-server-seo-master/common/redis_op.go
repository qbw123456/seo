package common

import (
	"fmt"
	"strconv"
	"time"

	"github.com/baowk/dilu-core/core"
	"github.com/redis/go-redis/v9"
)

func GetMpAccessToken(appId string) string {
	j, err := core.Cache.Get("acctoken:" + appId)
	if err == nil {
		return j
	}
	return ""
}

func SetMpAccessToken(appId string, token string) {
	core.Cache.Set("acctoken:"+appId, token, 7000)
}

func GetMpOpenId(scene string) (string, error) {
	return core.Cache.Get("mp:login:" + scene)
}

func SetMpOpenId(scene, openId string) {
	core.Cache.Set("mp:login:"+scene, openId, 400)
}

func DelMpOpenId(scene string) error {
	err := core.Cache.Del("mp:login:" + scene)
	if err != nil {
		return err
	}
	return nil
}

func TeamMemberKey(teamId, userId int) string {
	return fmt.Sprintf("t:m:%d:%d", teamId, userId)
}

// 统计请求次数
func IncrRequestCount(clientIp, path string, dur time.Duration) (int64, error) {
	key := fmt.Sprintf("request:count:%s:%s", clientIp, path)
	incr, err := core.Cache.Incr(key)
	if err != nil {
		return 0, err
	}
	if incr <= 1 {
		// 过期时间设置为5秒
		core.Cache.Expire(key, dur)
	}
	return incr, nil
}

// 用户最后修改密码时间
func SetUserLastPasswordResetTime(userId int64, t time.Time) error {
	key := fmt.Sprintf("user:last_password_reset:%d", userId)
	err := core.Cache.Set(key, t.Unix(), redis.KeepTTL)
	if err != nil {
		return err
	}
	return nil
}

// 获取用户最后修改密码时间
func GetUserLastPasswordResetTime(userId int64) time.Time {
	key := fmt.Sprintf("user:last_password_reset:%d", userId)
	v, err := core.Cache.Get(key)
	if err != nil {
		return time.Time{}
	}
	i, err := strconv.ParseInt(v, 10, 64)
	if err != nil {
		return time.Time{}
	}
	return time.Unix(i, 0)
}

// 设置 token 黑名单
func SetTokenBlacklist(token string, exp int64) error {
	endTime := time.Unix(exp, 0)
	if endTime.Before(time.Now()) {
		return fmt.Errorf("expired time must be after current time")
	}
	key := fmt.Sprintf("token:blacklist:%s", token)
	err := core.Cache.Set(key, exp, time.Until(endTime))
	if err != nil {
		return err
	}
	return nil
}

// 检查 token 是否在黑名单中
func CheckTokenBlacklist(token string) bool {
	key := fmt.Sprintf("token:blacklist:%s", token)
	return core.Cache.Exists(key)
}
