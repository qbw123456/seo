package consts

const (
	CacheApiKey       = "c:sys:api:"
	CacheCreateSeoPro = "seo:create:"
)
