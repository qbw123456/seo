package timerange

import (
	"fmt"
	"github.com/dreamsxin/go-now"
	"time"
)

type RangeUnit string

const (
	UnitMinute RangeUnit = "minute"
	UnitHour   RangeUnit = "hour"
	UnitDay    RangeUnit = "day"
	UnitWeek   RangeUnit = "week"
	UnitMonth  RangeUnit = "month"
)

type TimeGenerateUnit struct {
	start time.Time
	end   time.Time
	unit  RangeUnit
}

func New(start, end time.Time) *TimeGenerateUnit {
	return &TimeGenerateUnit{
		start: start,
		end:   end,
		unit:  UnitMonth,
	}
}

func (t *TimeGenerateUnit) SetUnit(unit RangeUnit) *TimeGenerateUnit {
	t.unit = unit
	return t
}

// Generate 生成 start～end 范围内的全部时间节点
func (t *TimeGenerateUnit) Generate() []string {
	var result []string

	cursor := normalizeStart(t.start, t.unit)

	for !cursor.After(t.end) {
		result = append(result, formatTime(cursor, t.unit))
		cursor = increment(cursor, t.unit)
	}

	return result
}

// normalizeStart（天/月/周/分钟）
func normalizeStart(t time.Time, unit RangeUnit) time.Time {
	switch unit {
	case UnitDay:
		return now.With(t).BeginningOfDay()
	case UnitMonth:
		return now.With(t).BeginningOfMonth()
	case UnitWeek:
		return now.With(t).BeginningOfWeek()
	case UnitMinute:
		return t.Truncate(time.Minute)
	case UnitHour:
		return t.Truncate(time.Hour)
	}
	return t
}

// increment 增加单位
func increment(t time.Time, unit RangeUnit) time.Time {
	switch unit {
	case UnitDay:
		return t.AddDate(0, 0, 1)
	case UnitMonth:
		return t.AddDate(0, 1, 0)
	case UnitWeek:
		return t.AddDate(0, 0, 7)
	case UnitMinute:
		return t.Add(time.Minute)
	case UnitHour:
		return t.Add(time.Hour)

	}
	return t
}

// formatTime 格式化
func formatTime(t time.Time, unit RangeUnit) string {
	switch unit {
	case UnitDay:
		return t.Format("2006-01-02")
	case UnitMonth:
		return t.Format("2006-01")
	case UnitWeek:
		year, week := t.ISOWeek()
		return fmt.Sprintf("%d-%d", year, week)
	case UnitMinute:
		return t.Format("2006-01-02 15:04")
	case UnitHour:
		return t.Format("2006-01-02 15")

	}
	return t.String()
}
