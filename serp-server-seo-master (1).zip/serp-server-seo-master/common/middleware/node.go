package middleware

import (
	"log/slog"

	"github.com/gin-gonic/gin"
)

func NodeHandler() gin.HandlerFunc {
	return func(c *gin.Context) {
		authorization := c.GetHeader("Authorization")
		// accessToken, err := GetAccessToken(authorization)
		// if err != nil {
		// 	Fail(c, 401, err.Error())
		// 	return
		// }
		if authorization != "CLip95@ZF5m#kZvLkE2Hr" && authorization != "Adafserr21dfd!aser13dfccd" {
			slog.ErrorContext(c, "NodeHandler", "err", "invalid token", "authorization", authorization)
			Fail(c, 401, "invalid token")
			return
		}

		c.Next()
	}
}
