package middleware

import (
	"dilu/common"
	"errors"
	"log/slog"
	"net/http"
	"strings"
	"time"

	"github.com/baowk/dilu-core/core"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"
)

type AppClaims struct {
	Uid                  int64  `json:"uid,omitempty"`
	Nature               string `json:"nature"`  // 性质 global：全部, temp：临时
	Scope                string `json:"scope"`   // 作用域 只用用于指定的操作范围
	OrderNo              string `json:"orderNo"` // 订单号
	jwt.RegisteredClaims        // 内嵌标准的声明
}

func NewAppClaims(userId int64, expiresAt time.Time, issuer, subject string) AppClaims {
	//now := time.Now()
	return AppClaims{
		Uid: userId,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expiresAt),  // 定义过期时间
			Issuer:    issuer,                         // 签发人
			IssuedAt:  jwt.NewNumericDate(time.Now()), // 签发时间
			Subject:   subject,                        // 签发主体
			//NotBefore: jwt.NewNumericDate(now),       // 生效时间
		},
	}
}

var (
	Secret              = core.Cfg.JWT.SignKey                             //密码自行设定
	TokenExpireDuration = int64(core.Cfg.JWT.Expires) * int64(time.Second) //设置过期时间

	TokenLookup   = "header: Authorization, query: token, cookie: jwt"
	TokenHeadName = "Bearer"

	// ErrEmptyAuthHeader can be thrown if authing with a HTTP header, the Auth header needs to be set
	ErrEmptyAuthHeader = errors.New("auth header is empty")

	// ErrInvalidAuthHeader indicates auth header is invalid, could for example have the wrong Realm name
	ErrInvalidAuthHeader = errors.New("auth header is invalid")

	// ErrEmptyQueryToken can be thrown if authing with URL Query, the query token variable is empty
	ErrEmptyQueryToken = errors.New("query token is empty")

	// ErrEmptyCookieToken can be thrown if authing with a cookie, the token cokie is empty
	ErrEmptyCookieToken = errors.New("cookie token is empty")

	// ErrEmptyParamToken can be thrown if authing with parameter in path, the parameter in path is empty
	ErrEmptyParamToken = errors.New("parameter token is empty")
	TempToken          = "temp"
	TempTokenCacheKey  = "tempToken:"
)

func JWTAppAuthMiddleware() func(c *gin.Context) {
	if Secret == "" {
		Secret = core.Cfg.JWT.SignKey                                          //密码自行设定
		TokenExpireDuration = int64(core.Cfg.JWT.Expires) * int64(time.Second) //设置过期时间
	}
	return func(c *gin.Context) {
		var token string
		var err error

		methods := strings.Split(TokenLookup, ",")
		for _, method := range methods {
			if len(token) > 0 {
				break
			}
			parts := strings.Split(strings.TrimSpace(method), ":")
			k := strings.TrimSpace(parts[0])
			v := strings.TrimSpace(parts[1])
			switch k {
			case "header":
				token, err = jwtFromHeader(c, v)
			case "query":
				token, err = jwtFromQuery(c, v)
			case "cookie":
				token, err = jwtFromCookie(c, v)
			case "param":
				token, err = jwtFromParam(c, v)
			}
		}

		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{
				"code": 1001,
				"msg":  "无有效token",
			})
			c.Abort()
			return
		}

		appClaims := new(AppClaims)

		err = Parse(token, appClaims, Secret)

		if err != nil {
			c.JSON(http.StatusUnauthorized, gin.H{
				"code": 1001,
				"msg":  "无效的Token",
			})
			c.Abort()
			return
		}

		if isOk := natureVerify(appClaims, c); !isOk {
			c.JSON(http.StatusUnauthorized, gin.H{
				"code": 1001,
				"msg":  "无效的访问",
			})
			c.Abort()
			return
		}

		// 是否在黑名单
		if common.CheckTokenBlacklist(token) {
			Fail(c, 401, "token is blacklisted")
			return
		}

		// 获取用户重置密码时间
		issuedAt, err := appClaims.GetIssuedAt()
		if err == nil {
			if issuedAt != nil {
				slog.Debug("issuedAt", "time", issuedAt.Time)
				lastResetTime := common.GetUserLastPasswordResetTime(appClaims.Uid)
				slog.Debug("lastResetTime", "time", lastResetTime)
				if lastResetTime.After(issuedAt.Time) {
					Fail(c, 401, "token is expired, please login again")
					return
				}
			}
		} else {
			slog.Error("get issuedAt", "err", err)
		}

		exp, err := appClaims.GetExpirationTime()
		// 获取过期时间返回err,或者exp为nil都返回错误
		if err != nil {
			Fail(c, 401, err.Error())
			return
		}

		// 将当前请求的username信息保存到请求的上下文c上
		c.Set("uid", appClaims.Uid)
		c.Set("userId", appClaims.ID)
		c.Set("token", token)
		c.Set("exp", exp.Unix())

		if appClaims.Issuer != "" {
			c.Set("companyId", appClaims.Issuer)
		}

		c.Next()
	}
}

func jwtFromHeader(c *gin.Context, key string) (string, error) {
	authHeader := c.Request.Header.Get(key)
	if authHeader == "" {
		return "", ErrEmptyAuthHeader
	}

	parts := strings.SplitN(authHeader, " ", 2)
	if !(len(parts) == 2 && parts[0] == TokenHeadName) {
		return "", ErrInvalidAuthHeader
	}

	return parts[1], nil
}

func jwtFromQuery(c *gin.Context, key string) (string, error) {
	token := c.Query(key)

	if token == "" {
		return "", ErrEmptyQueryToken
	}

	return token, nil
}

func jwtFromCookie(c *gin.Context, key string) (string, error) {
	cookie, _ := c.Cookie(key)

	if cookie == "" {
		return "", ErrEmptyCookieToken
	}

	return cookie, nil
}

func jwtFromParam(c *gin.Context, key string) (string, error) {
	token := c.Param(key)

	if token == "" {
		return "", ErrEmptyParamToken
	}

	return token, nil
}

// 临时token使用校验
func natureVerify(a *AppClaims, c *gin.Context) bool {
	if a.Nature != TempToken {
		return true
	}

	if !core.Cache.Exists(TempTokenCacheKey + a.OrderNo) {
		return false
	}

	scopes := strings.Split(a.Scope, ",")

	for _, scope := range scopes {
		if allowPath := allowScopePath(scope); allowPath == c.Request.URL.Path {
			return true
		}
	}

	return false
}

func allowScopePath(scope string) string {
	paths := map[string]string{
		"pay":  "/api/app/order/pay",
		"find": "/api/app/order/findBy",
	}

	path, _ := paths[scope]
	return path
}
