package middleware

import (
	"strconv"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/golang-jwt/jwt/v5"

	"dilu/common/config"
	"dilu/common/utils"
)

func JwtAdminHandler() gin.HandlerFunc {
	return func(c *gin.Context) {
		authorization := c.GetHeader("Authorization")
		accessToken, err := GetAccessToken(authorization)
		if err != nil {
			Fail(c, 401, err.Error())
			return
		}
		customClaims := new(utils.CustomClaims)
		// 解析Token
		err = Parse(accessToken, customClaims, config.Ext.AdminJWT.SignKey, jwt.WithSubject(config.Ext.AdminJWT.Subject))
		if err != nil {
			Fail(c, 401, err.Error())
			return
		}

		exp, err := customClaims.GetExpirationTime()
		// 获取过期时间返回err,或者exp为nil都返回错误
		if err != nil || exp == nil {
			Fail(c, 401, err.Error())
			return
		}

		// 刷新时间大于0则判断剩余时间小于刷新时间时刷新Token并在Response header中返回
		if config.Ext.AdminJWT.Refresh > 0 {
			now := time.Now()
			diff := exp.Time.Sub(now)
			refreshTTL := time.Duration(config.Ext.AdminJWT.Refresh) * time.Minute
			//fmt.Println(diff.Seconds(), refreshTTL)
			if diff < refreshTTL {
				exp := time.Now().Add(time.Duration(config.Ext.AdminJWT.Expires) * time.Minute)
				customClaims.ExpiresAt(exp)
				newToken, _ := Refresh(customClaims, config.Ext.AdminJWT.SignKey)
				c.Writer.Header().Set("refresh-access-token", newToken)
				c.Writer.Header().Set("refresh-exp", strconv.FormatInt(exp.Unix(), 10))
			}
		}

		c.Set("a_uid", customClaims.UserId)
		c.Set("a_rid", customClaims.RoleId)
		c.Set("a_mobile", customClaims.Phone)
		c.Set("a_nickname", customClaims.Nickname)
		c.Set("jwt_data", customClaims.JwtData)
		c.Next()
	}
}
