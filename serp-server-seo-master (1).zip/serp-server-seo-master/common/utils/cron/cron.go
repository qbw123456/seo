package cron

import (
	"fmt"

	"github.com/robfig/cron/v3"
)

const (
	Daily   = "daily"
	Weekly  = "weekly"
	Monthly = "monthly"
)

// Task 秒  分  时  日  月  周
type Task struct {
	schType string
	date    string
	hour    int
	minute  int
}

func NewCronTask(cronType, date string, hour, minute int) *Task {
	return &Task{
		schType: cronType,
		date:    date,
		hour:    hour,
		minute:  minute,
	}
}

func (t *Task) GeneratedCronExpr() (string, error) {
	expr := ""
	switch t.schType {
	case Daily:
		expr = t.buildDailyCron()
	case Weekly:
		expr = t.buildWeeklyCron()
	case Monthly:
		expr = t.buildMonthlyCron()
	default:
	}

	_, err := cron.NewParser(
		cron.Second | cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow | cron.Descriptor,
	).Parse(expr)
	if err != nil {
		return "", err
	}

	return expr, nil
}

// 解析每天表达式
func (t *Task) buildDailyCron() string {

	return fmt.Sprintf("0 %d %d * * *", t.minute, t.hour)
}

// 解析周表达式
func (t *Task) buildWeeklyCron() string {
	return fmt.Sprintf("0 %d %d * * %s", t.minute, t.hour, t.date)
}

// 解析月表示
func (t *Task) buildMonthlyCron() string {
	return fmt.Sprintf("0 %d %d %s * *", t.minute, t.hour, t.date)
}
