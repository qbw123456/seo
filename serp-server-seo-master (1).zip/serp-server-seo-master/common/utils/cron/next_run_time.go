package cron

import (
	"fmt"
	"time"

	"github.com/robfig/cron/v3"
)

func NextRunTime(t time.Time, cronExpr string) (time.Time, error) {
	c, err := cron.NewParser(
		cron.Second | cron.Minute | cron.Hour | cron.Dom | cron.Month | cron.Dow | cron.Descriptor,
	).Parse(cronExpr)
	if err != nil {
		return time.Time{}, err
	}
	return c.Next(time.Now()), nil
}

// CalculateNextRunTime 计算下次执行时间
// cronExpr格式: 秒 分 时 日 月 周
// 每天执行: "秒 分 时 * * *"
// 每周执行: "秒 分 时 * * 周" (0=周日, 1=周一, ..., 6=周六)
// 每月执行: "秒 分 时 日 * *"
func CalculateNextRunTime(cronExpr string) time.Time {
	// 获取当前时间
	now := time.Now()

	// 简单解析cron表达式
	var second, minute, hour int
	var dayOfMonth, month, dayOfWeek string

	fmt.Sscanf(cronExpr, "%d %d %d %s %s %s", &second, &minute, &hour, &dayOfMonth, &month, &dayOfWeek)

	// 判断调度类型
	if dayOfWeek == "*" && dayOfMonth == "*" {
		// 每天执行: "秒 分 时 * * *"
		return calculateDailyTime(now, second, minute, hour)
	} else if dayOfWeek != "*" && dayOfMonth == "*" {
		// 每周执行: "秒 分 时 * * 周"
		// dayOfWeek: 0=周日, 1=周一, ..., 6=周六
		targetDay := 0
		fmt.Sscanf(dayOfWeek, "%d", &targetDay)
		return calculateWeeklyTime(now, second, minute, hour, targetDay)
	} else if dayOfWeek == "*" && dayOfMonth != "*" {
		// 每月执行: "秒 分 时 日 * *"
		targetDay := 1
		fmt.Sscanf(dayOfMonth, "%d", &targetDay)
		return calculateMonthlyTime(now, second, minute, hour, targetDay)
	}

	// 默认24小时后
	return now.Add(24 * time.Hour)
}

// calculateDailyTime 计算每天执行时间
func calculateDailyTime(now time.Time, second, minute, hour int) time.Time {
	nextTime := time.Date(now.Year(), now.Month(), now.Day(), hour, minute, second, 0, now.Location())
	if nextTime.Before(now) || nextTime.Equal(now) {
		nextTime = nextTime.Add(24 * time.Hour)
	}
	return nextTime
}

// calculateWeeklyTime 计算每周执行时间
func calculateWeeklyTime(now time.Time, second, minute, hour, targetDayOfWeek int) time.Time {
	currentDayOfWeek := int(now.Weekday()) // 0=周日, 1=周一, ..., 6=周六

	// 计算到目标周几的天数差
	daysDiff := targetDayOfWeek - currentDayOfWeek
	if daysDiff < 0 {
		daysDiff += 7 // 如果目标周几已过，则下周
	}

	nextTime := time.Date(now.Year(), now.Month(), now.Day(), hour, minute, second, 0, now.Location())
	nextTime = nextTime.AddDate(0, 0, daysDiff)

	// 如果计算出的时间早于或等于当前时间，则加一周
	if nextTime.Before(now) || nextTime.Equal(now) {
		nextTime = nextTime.AddDate(0, 0, 7)
	}

	return nextTime
}

// calculateMonthlyTime 计算每月执行时间
func calculateMonthlyTime(now time.Time, second, minute, hour, targetDay int) time.Time {
	// 当前月份
	year, month, _ := now.Date()

	// 计算目标日期（注意处理月份天数不足的情况）
	nextTime := time.Date(year, month, targetDay, hour, minute, second, 0, now.Location())

	// 如果目标日期无效（如2月30日），则使用当月最后一天
	if nextTime.Month() != month {
		nextTime = time.Date(year, month, 1, hour, minute, second, 0, now.Location())
		nextTime = nextTime.AddDate(0, 1, -1) // 下个月第一天减一天=当月最后一天
	}

	// 如果计算出的时间早于或等于当前时间，则加一个月
	if nextTime.Before(now) || nextTime.Equal(now) {
		nextTime = nextTime.AddDate(0, 1, 0)
	}

	return nextTime
}
