package excel

import (
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/xuri/excelize/v2"
	"net/http"
	"reflect"
	"sort"
	"strconv"
	"strings"
)

// Export instance
// list 需要导出的对象数组
// title 标题
// fileName 文件名字
// sheet sheet名
// fields 需要忽略的字段
// isGhbj 是否设置隔行背景色
// isIgnore 是否忽略字段
// changeHead 设置需要改变的字段头
type Export struct {
	List       interface{}
	FileName   string
	Title      string
	Sheet      string
	Fields     string
	IsGhbj     bool
	IsIgnore   bool
	ChangeHead map[string]string
	excel      *Excel
}

// NewExcelExport new build excel of export instance
func NewExcelExport(list interface{}, fileName string) *Export {
	return &Export{
		List:       list,
		FileName:   fileName,
		Sheet:      "sheet1",
		IsGhbj:     false,
		IsIgnore:   false,
		ChangeHead: make(map[string]string),
		excel:      Init(),
	}
}

func (e *Export) SetFileName(fileName string) *Export {
	e.FileName = fileName
	return e
}

func (e *Export) SetTitle(title string) *Export {
	e.Title = title
	return e
}

func (e *Export) SetFields(fields string) *Export {
	e.Fields = fields
	return e
}

func (e *Export) SetSheet(sheet string) *Export {
	e.Sheet = sheet
	return e
}

func (e *Export) SetIsGhbj(bj bool) *Export {
	e.IsGhbj = bj
	return e
}

func (e *Export) SetIsIgnore(ig bool) *Export {
	e.IsIgnore = ig
	return e
}

func (e *Export) SetChangeHead(hed map[string]string) *Export {
	e.ChangeHead = hed
	return e
}

// GetExcelColumnName 根据列数生成 Excel 列名
func (e *Export) GetExcelColumnName(columnNumber int) string {
	columnName := ""
	for columnNumber > 0 {
		columnNumber--
		columnName = string(rune('A'+columnNumber%26)) + columnName
		columnNumber /= 26
	}
	return columnName
}

// ExportExcel excel导出
// sheet, title, fields string, isGhbj, isIgnore bool, list interface{}, changeHead map[string]string,
func (e *Export) exportExcel() (err error) {
	index, _ := e.excel.F.GetSheetIndex(e.Sheet)

	// 如果sheet名称不存在
	if index < 0 {
		_, _ = e.excel.F.NewSheet(e.Sheet)
	}

	// 构造excel表格
	// 取目标对象的元素类型、字段类型和 tag
	dataValue := reflect.ValueOf(e.List)

	// 判断数据的类型
	if dataValue.Kind() != reflect.Slice {
		err = errors.New("invalid data type")
		return
	}

	// 构造表头
	endColName, dataRow, err := e.normalBuildTitle(dataValue)

	if err != nil {
		return
	}

	// 构造数据行
	err = e.normalBuildDataRow(endColName, dataRow, dataValue)
	return
}

// NormalDownLoad 导出excel并下载（单个sheet）
func (e *Export) NormalDownLoad(res http.ResponseWriter) error {
	f, err := e.NormalDynamicExport()

	if err != nil {
		return err
	}

	return e.DownLoadExcel(e.FileName, res, f)
}

// NormalDownLoadTo 动态导出excel并下载（单个sheet）
func (e *Export) NormalDownLoadTo(res gin.ResponseWriter) error {
	f, err := e.NormalDynamicExport()
	if err != nil {
		return err
	}

	return e.DownLoadExcelTo(e.FileName, res, f)
}

// NormalDynamicExport 导出excel
// 需要在传入的结构体中的字段加上tag：exce:"title:列头名称;index:列下标(从0开始)
func (e *Export) NormalDynamicExport() (file *excelize.File, err error) {
	err = e.exportExcel()

	if err != nil {
		return
	}

	return e.excel.F, err
}

// 构造表头（endColName 最后一列的列名 dataRow 数据行开始的行号）
func (e *Export) normalBuildTitle(dataValue reflect.Value) (endColName string, dataRow int, err error) {
	// 获取导入目标对象的类型信息
	dataType := dataValue.Type().Elem()

	// 遍历目标对象的字段
	var exportTitle []Tag

	for i := 0; i < dataType.NumField(); i++ {
		var excelTag Tag

		// 获取字段信息和tag
		field := dataType.Field(i)
		tag := field.Tag.Get(TagKey)

		// 如果非导出则跳过
		if tag == "" {
			continue
		}

		// 选择要导出或要忽略的字段
		if e.Fields != "" {
			// 忽略指定字段
			if e.IsIgnore && strings.Contains(e.Fields, field.Name+",") {
				continue
			}

			// 导出指定字段
			if !e.IsIgnore && !strings.Contains(e.Fields, field.Name+",") {
				continue
			}
		}

		err = excelTag.GetTag(tag)
		if err != nil {
			return
		}

		// 更改指定字段的表头标题
		if e.ChangeHead != nil && e.ChangeHead[field.Name] != "" {
			excelTag.Name = e.ChangeHead[field.Name]
		}

		exportTitle = append(exportTitle, excelTag)
	}

	// 排序
	sort.Slice(exportTitle, func(i, j int) bool {
		return exportTitle[i].Index < exportTitle[j].Index
	})

	// 列头行
	var titleRowData []interface{}

	for i, colTitle := range exportTitle {
		endColName := e.GetExcelColumnName(i + 1)
		// 根据给定的宽度设置列宽
		if colTitle.Width > 0 {
			_ = e.excel.F.SetColWidth(e.Sheet, endColName, endColName, float64(colTitle.Width))
		} else {
			// 默认宽度为20
			_ = e.excel.F.SetColWidth(e.Sheet, endColName, endColName, float64(20))
		}
		titleRowData = append(titleRowData, colTitle.Name)
	}

	// 根据列数生成 Excel 列名
	endColName = e.GetExcelColumnName(len(titleRowData))

	// 如果有title，那么从第3行开始就是数据行，第1行是title，第2行是表头
	if e.Title != "" {
		dataRow = 3

		_ = e.excel.F.SetCellValue(e.Sheet, "A1", e.Title)
		_ = e.excel.F.MergeCell(e.Sheet, "A1", endColName+"1") // 合并标题单元格
		_ = e.excel.F.SetCellStyle(e.Sheet, "A1", endColName+"1", e.excel.TitleStyle)
		_ = e.excel.F.SetRowHeight(e.Sheet, 1, float64(30)) // 第一行行高
		_ = e.excel.F.SetRowHeight(e.Sheet, 2, float64(30)) // 第二行行高
		_ = e.excel.F.SetCellStyle(e.Sheet, "A2", endColName+"2", e.excel.HeadStyle)

		if err = e.excel.F.SetSheetRow(e.Sheet, "A2", &titleRowData); err != nil {
			return
		}
	} else {
		// 如果没有title，那么从第2行开始就是数据行，第1行是表头
		dataRow = 2

		_ = e.excel.F.SetRowHeight(e.Sheet, 1, float64(30))
		_ = e.excel.F.SetCellStyle(e.Sheet, "A1", endColName+"1", e.excel.HeadStyle)
		if err = e.excel.F.SetSheetRow(e.Sheet, "A1", &titleRowData); err != nil {
			return
		}
	}
	return
}

// 构造数据行
func (e *Export) normalBuildDataRow(endColName string, row int, dataValue reflect.Value) (err error) {
	for i := 0; i < dataValue.Len(); i++ {
		startCol := fmt.Sprintf("A%d", row)
		endCol := fmt.Sprintf("%s%d", endColName, row)
		item := dataValue.Index(i)
		typ := item.Type()
		num := item.NumField()
		var exportRow []Tag

		// 记录这一行中，数据最多的单元格的值的长度
		maxLen := 0

		//遍历结构体的所有字段
		for j := 0; j < num; j++ {
			//获取到struct标签，需要通过reflect.Type来获取tag标签的值
			dataField := typ.Field(j)

			tagVal := dataField.Tag.Get(TagKey)

			// 如果非导出则跳过
			if tagVal == "" {
				continue
			}

			// 选择要导出或要忽略的字段
			if e.Fields != "" {
				// 忽略指定字段
				if e.IsIgnore && strings.Contains(e.Fields, dataField.Name+",") {
					continue
				}

				// 导出指定字段
				if !e.IsIgnore && !strings.Contains(e.Fields, dataField.Name+",") {
					continue
				}
			}

			var dataCol Tag
			err = dataCol.GetTag(tagVal)

			// 取字段值
			fieldData := item.FieldByName(dataField.Name)

			// string类型的才计算长度
			if fieldData.Type().String() == "string" {

				// 当前单元格内容的长度
				rwsTemp := fieldData.Len()

				//这里取每一行中的每一列字符长度最大的那一列的字符
				if rwsTemp > maxLen {
					maxLen = rwsTemp
				}
			}

			// 替换
			if dataCol.Replace != "" {
				split := strings.Split(dataCol.Replace, ",")
				for j := range split {
					// 根据下划线进行分割，格式：需要替换的内容_替换后的内容
					s := strings.Split(split[j], "_")

					value := fieldData.String()
					if strings.Contains(fieldData.Type().String(), "int") {
						value = strconv.Itoa(int(fieldData.Int()))
					} else if fieldData.Type().String() == "bool" {
						value = strconv.FormatBool(fieldData.Bool())
					} else if strings.Contains(fieldData.Type().String(), "float") {
						value = strconv.FormatFloat(fieldData.Float(), 'f', -1, 64)
					}
					if s[0] == value {
						dataCol.Value = s[1]
					}
				}
			} else {
				dataCol.Value = fieldData
			}
			if err != nil {
				return
			}
			exportRow = append(exportRow, dataCol)
		}

		// 排序
		sort.Slice(exportRow, func(i, j int) bool {
			return exportRow[i].Index < exportRow[j].Index
		})

		// 数据列
		var rowData []interface{}

		for _, colTitle := range exportRow {
			rowData = append(rowData, colTitle.Value)
		}

		if e.IsGhbj && row%2 == 0 {
			_ = e.excel.F.SetCellStyle(e.Sheet, startCol, endCol, e.excel.ContentStyle2)
		} else {
			_ = e.excel.F.SetCellStyle(e.Sheet, startCol, endCol, e.excel.ContentStyle1)
		}

		// 自适应行高
		if maxLen > 25 {
			d := maxLen / 25
			f := 25 * d
			_ = e.excel.F.SetRowHeight(e.Sheet, row, float64(f))
		} else {
			// 默认行高25
			_ = e.excel.F.SetRowHeight(e.Sheet, row, float64(25))
		}
		if err = e.excel.F.SetSheetRow(e.Sheet, startCol, &rowData); err != nil {
			return
		}
		row++
	}
	return
}

// DownLoadExcel 下载
func (e *Export) DownLoadExcel(fileName string, res http.ResponseWriter, file *excelize.File) error {
	//res.Header().Set("Content-Type", "text/html; charset=UTF-8")
	res.Header().Set("Content-Type", "application/octet-stream")
	res.Header().Set("Content-Disposition", "attachment; filename="+fileName+".xlsx")
	res.Header().Set("Access-Control-Expose-Headers", "Content-Disposition")
	err := file.Write(res)

	if err != nil {
		http.Error(res, err.Error(), http.StatusInternalServerError)
		return err
	}

	return nil
}

func (e *Export) DownLoadExcelTo(fileName string, res gin.ResponseWriter, file *excelize.File) error {
	//res.Header().Set("Content-Type", "text/html; charset=UTF-8")
	res.Header().Set("Content-Type", "application/octet-stream")
	res.Header().Set("Content-Disposition", "attachment; filename="+fileName+".xlsx")
	res.Header().Set("Access-Control-Expose-Headers", "Content-Disposition")

	err := file.Write(res)

	if err != nil {
		http.Error(res, err.Error(), http.StatusInternalServerError)
		return err
	}

	return nil
}
