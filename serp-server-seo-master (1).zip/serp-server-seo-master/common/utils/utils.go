package utils

import (
	"fmt"
	"regexp"
	"strconv"
	"unicode"
)

func StrLenVerify(strs string, assignLen int) bool {
	if len(strs) > assignLen {
		return true
	}

	return false
}

func Convert[T any](v any) T {
	var zero T

	switch any(zero).(type) {
	case string:
		switch val := v.(type) {
		case string:
			return any(val).(T)
		case []byte:
			return any(string(val)).(T)
		case []string:
			if len(val) > 0 {
				return any(val[0]).(T)
			}
		case []interface{}:
			if len(val) > 0 {
				return Convert[T](val[0])
			}
		default:
			return any(fmt.Sprintf("%v", val)).(T)
		}
	case int:
		switch val := v.(type) {
		case int:
			return any(val).(T)
		case int64:
			return any(int(val)).(T)
		case float64:
			return any(int(val)).(T)
		case string:
			i, _ := strconv.Atoi(val)
			return any(i).(T)
		}
	case int64:
		switch val := v.(type) {
		case int:
			return any(int64(val)).(T)
		case int64:
			return any(val).(T)
		case string:
			i, _ := strconv.ParseInt(val, 10, 64)
			return any(i).(T)
		}
	case float64:
		switch val := v.(type) {
		case float64:
			return any(val).(T)
		case float32:
			return any(float64(val)).(T)
		case int:
			return any(float64(val)).(T)
		case string:
			f, _ := strconv.ParseFloat(val, 64)
			return any(f).(T)
		}
	}

	return zero
}

func IsValidDomain(domain string) bool {
	const domainRegex = `^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$`
	re := regexp.MustCompile(domainRegex)
	return re.MatchString(domain)
}

// 判断是否为中文字符
func IsChinese(r rune) bool {
	return unicode.Is(unicode.Han, r)
}

// 判断是否为ASCII字母
func IsASCIILetter(r rune) bool {
	return (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z')
}

// 遍历字符判断
func IsValidKeyword(s string) bool {
	for _, r := range s {
		// 判断是否为中文字符、英文字母或数字
		if !IsChinese(r) && !unicode.IsLetter(r) && !unicode.IsDigit(r) {
			return false
		}

		// 如果是英文字母，确保是ASCII字母（排除其他语言的字母）
		if unicode.IsLetter(r) && !IsASCIILetter(r) && !IsChinese(r) {
			return false
		}
	}
	return true
}
