package hashUtil

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"sort"
	"strings"
)

func GenerateSignature(params map[string]string) string {
	secret := "abcdACacadcLUBmc12366RtObscCQlEGxV88009WT"

	keys := make([]string, 0, len(params))

	for k := range params {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	var sb strings.Builder

	for i, k := range keys {
		if params[k] == "" {
			continue
		}

		sb.WriteString(k)
		sb.WriteString("=")
		sb.WriteString(params[k])

		if i != len(keys)-1 {
			sb.WriteString("&")
		}
	}

	signString := sb.String()

	h := hmac.New(sha256.New, []byte(secret))
	h.Write([]byte(signString))

	return hex.EncodeToString(h.Sum(nil))
}
