package utils

import (
	"errors"
	"strings"

	"gorm.io/gorm"
)

func IsErrDuplicatedKey(err error) bool {
	return errors.Is(err, gorm.ErrDuplicatedKey) ||
		// For MySQL
		strings.Contains(err.Error(), "Duplicate entry") ||
		// For PostgreSQL
		strings.Contains(err.Error(), "duplicate key value violates unique constraint") ||
		// For SQLite
		strings.Contains(err.Error(), "UNIQUE constraint failed")
}
