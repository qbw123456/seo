package prometheus

import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

const (
	payType = "pay_type"
	errType = "error_type"
)

// ****** Prometheus的数据类型有四种 ******
// Counter：计数器 只增不减
// Gauge：仪表盘 可增可减
// Histogram 直方图 数据分布情况
// Summary 摘要 数据分布情况
// Vec代表分区

var (
	UserPayErrorCount = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "user_pay_error_count",
			Help: "用户支付失败数",
		},
		[]string{payType, errType},
	)

	SeoCronErrorCount = prometheus.NewCounterVec(
		prometheus.CounterOpts{
			Name: "seo_cron_error_count",
			Help: "SEO定时任务执行失败数",
		},
		[]string{payType, errType},
	)
)

func init() {
	prometheus.MustRegister(UserPayErrorCount)
	prometheus.MustRegister(SeoCronErrorCount)
}

func Handler() http.Handler {
	return promhttp.Handler()
}
