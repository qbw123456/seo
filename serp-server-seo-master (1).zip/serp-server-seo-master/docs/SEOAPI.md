[TOC]

## 搜索引擎

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/engine-types \
  --header 'Content-Type: application/json' \
  --data '{
}'
```

-- 返回

```json
{
  "reqId": "ceff9208-0364-4c4c-8e39-528e5cf01092",
  "code": 200,
  "msg": "OK",
  "data": [
    "bing",
    "google"
  ]
}
```

## 创建项目

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/create \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
  "exec": 1,
	"proName": "测试测试",
	"engineTypes": ["google"],
	"domainList": [{"domainName":"yunlogin.com", "domainType": 1}],
	"keywordList": [{"keyName":"指纹浏览器"},{"keyName":"云登"}],
	"cronTasks": {
		"schType": "daily",
        "days":"1",
        "hour": 1,
        "minute": 0
	}
}'
```

- 字段说明
- exec: 执行状态，1：立即执行，0：根据设定时间执行
- proName: 项目名称
- engineTypes: 搜索引擎类型，google、bing、yandex
- domainList: 域名列表
  - domainType: 1 根域名（后缀匹配）2 子域
  - isActive: 1 启用 0 停用
- keywordList: 关键词列表
  - isActive: 1 启用 0 停用
- cronTasks: 定时任务配置
  - schType: 调度类型：daily，weekly，monthly
  - days: 执行间隔天数 （daily：1-31，weekly：1-7，monthly：1-28）:1,2,3
  - hour: 执行时间小时
  - minute: 执行时间分钟



- 返回值

```json
{
  "reqId": "15c6e7c2-1f0a-4626-9cb0-e21d43153193",
  "code": 200,
  "msg": "OK"
}
```

## 更新项目

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/update \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1,
	"proName": "云登浏览器",
	"engineTypes": ["google"],
	"domainList": [{"domainName":"www.yunlogin.com"}],
	"keywordList": [{"keyName":"yunlogin"},{"keyName":"test"}],
	"cronTasks": {
		"schType": "daily",
        "days":"2",
        "hour": 1,
        "minute": 0
	}
}'
```

## 项目详情

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/get \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 1
}'
```

### 项目关键字列表

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project-keywords/page \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 1
}'
```


- 返回值

```json
{
  "reqId": "c1794625-ad0b-42aa-8786-d44518e8d5c2",
  "code": 200,
  "msg": "OK",
  "data": {
    "list": [
      {
        "id": 2,
        "userId": 986,
        "projectId": 1,
        "keywordId": 4,
        "keyName": "云登",
        "isActive": 1,
        "createdAt": "2026-01-08T16:01:16+08:00"
      },
      {
        "id": 1,
        "userId": 986,
        "projectId": 1,
        "keywordId": 3,
        "keyName": "指纹浏览器",
        "isActive": 1,
        "createdAt": "2026-01-08T16:01:16+08:00"
      }
    ],
    "total": 2,
    "pageSize": 10,
    "currentPage": 1
  }
}
```

### 项目关键词新增

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project-keywords/create \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1,
	"keywordList": [{"keyName":"yunlogin"},{"keyName":"test"}]'
```

### 项目关键词状态更新

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project-keywords/update \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1,
  "isActive": 1
}'
```

### 项目关键词删除

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project-keywords/del \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1
}'
```

### 项目域名列表

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-user-domains/page \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 1
}'
```

- 返回值

```json
{
  "reqId": "6062738b-97d7-44fb-b34c-43fb1a643fa7",
  "code": 200,
  "msg": "OK",
  "data": {
    "list": [
      {
        "id": 2,
        "userId": 986,
        "projectId": 1,
        "domainId": 4,
        "domainName": "www.yunlogin.com",
        "isActive": 1,
        "domainType": 0,
        "createdAt": "2026-01-08T16:01:16+08:00"
      },
      {
        "id": 1,
        "userId": 986,
        "projectId": 1,
        "domainId": 1,
        "domainName": "yunlogin.com",
        "isActive": 1,
        "domainType": 0,
        "createdAt": "2026-01-08T16:01:16+08:00"
      }
    ],
    "total": 2,
    "pageSize": 10,
    "currentPage": 1
  }
}
```

### 项目域名新增

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-user-domains/create \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1,
	"domainList": [{"domainName":"www.yunlogin.com"}]
}'
```

### 项目域名状态更新

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-user-domains/update \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1,
  "isActive": 1
}'
```

### 项目域名删除

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-user-domains/del \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1
}'
```

## 项目列表

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/page \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
}'
```


- 返回值

```json
{
  "reqId": "d5b97d3a-e488-4192-b13c-d95568eb1dd4",
  "code": 200,
  "msg": "OK",
  "data": {
    "id": 1,
    "userId": 986,
    "proName": "云登浏览器",
    "keywordNum": 2,
    "domainNum": 2,
    "engineTypes": [
      "google"
    ],
    "deviceTypes": null,
    "ranking": 0,
    "lifeTime": "1970-01-01T08:00:00+08:00",
    "schType": "daily",
    "days": "1",
    "hour": 1,
    "minute": 0,
    "cronExpr": "",
    "state": 1,
    "createdAt": "2026-01-08T16:01:16+08:00",
    "updatedAt": "2026-01-08T19:04:25+08:00",
    "deletedAt": null
  }
}
```

## 删除项目

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/del \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 6
}'
```

## 启动/停止项目

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/on-off \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 6,
    "state": 2
}'
```

## 项目执行频率更新

第二天生效。

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project/update-cron \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"id": 1,
	"cronTasks": {
		"schType": "weekly",
        "days":"1,2",
        "hour": 1,
        "minute": 0
	}
}'
```

## 项目任务执行结果详情

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-user-ranking-history/page \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 1
}'
```

- 返回
```json
{
  "reqId": "55eea8e9-0a9e-41ab-ba52-c4b7120cfef7",
  "code": 200,
  "msg": "OK",
  "data": {
    "list": [
      {
        "id": 2,
        "userId": 986,
        "projectId": 1,
        "projectName": "测试测试",
        "taskId": 2,
        "keywordId": 4,
        "keywordName": "云登",
        "domainId": 1,
        "domainName": "yunlogin.com",
        "engineType": "google",
        "rankPosition": 1,
        "preRanking": 0,
        "rankChange": 0,
        "createdAt": "2026-01-09T15:53:51+08:00"
      },
      {
        "id": 1,
        "userId": 986,
        "projectId": 1,
        "projectName": "测试测试",
        "taskId": 1,
        "keywordId": 3,
        "keywordName": "指纹浏览器",
        "domainId": 1,
        "domainName": "yunlogin.com",
        "engineType": "google",
        "rankPosition": 4,
        "preRanking": 0,
        "rankChange": 0,
        "createdAt": "2026-01-09T15:53:51+08:00"
      }
    ],
    "total": 2,
    "pageSize": 10,
    "currentPage": 1
  }
}
```

## 项目关键词排名历史记录导出

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-user-ranking-history/export \
  --header 'Authorization: Bearer xxx' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 1
}'
```

-- 导出文件说明
-- 文件名格式：{项目名称}_关键词排名_{日期}.csv
-- 日期格式：20260102

## 项目关键词排名分布

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-user-ranking-history/distribution \
  --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjk4NiwiZXhwIjoxNzY4MjY1ODk5LCJqdGkiOiJjMDkwNGE4ZmUzOTk0NzZmOTBhMzBhZjk1M2EzYjJmYSIsImlzcyI6ImJmODA3NzY2NmVkZjQ5NjU5Yjk2ODNhOGIzZWEyOTQ2In0.DItJH_pn9TPXr1FFjojol1m7thCfr4LvQkJDFJLx9Dc' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 1,
    "domainId": 1,
    "engineType": "google",
    "startDate": "2025-12-01",
    "endDate": "2026-01-15"
}'
```

- 返回值

```json
{
  "reqId": "3d62b80f-5d48-4c94-a5dc-a2804fbc6b14",
  "code": 200,
  "msg": "OK",
  "data": [
    {
      "createdDate": "2026-01-09",
      "r1": 1, // 1-3 名
      "r2": 1, // 4-10 名
      "r3": 0, // 11-20 名
      "r4": 0, // 21-30 名
      "r5": 0, // 31-50 名
      "r6": 0 // 51-100 名
    },
    {
      "createdDate": "2026-01-10",
      "r1": 0,
      "r2": 0,
      "r3": 0,
      "r4": 0,
      "r5": 0,
      "r6": 0
    }
  ]
}
```

## 项目关键词排名对比

```shell
curl --request POST \
  --url http://localhost:9998/api/v1/seo/seo-project-keywords/first-last-rank \
  --header 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1aWQiOjk4NiwiZXhwIjoxNzY4MjY1ODk5LCJqdGkiOiJjMDkwNGE4ZmUzOTk0NzZmOTBhMzBhZjk1M2EzYjJmYSIsImlzcyI6ImJmODA3NzY2NmVkZjQ5NjU5Yjk2ODNhOGIzZWEyOTQ2In0.DItJH_pn9TPXr1FFjojol1m7thCfr4LvQkJDFJLx9Dc' \
  --header 'Content-Type: application/json' \
  --data '{
	"projectId": 1,
    "domainId": 1,
    "engineType": "google",
    "startDate": "2025-12-01",
    "endDate": "2026-01-15"
}'
```

- 返回值

```json
{
  "reqId": "06dbe281-a322-4986-8f2c-cfff6287f175",
  "code": 200,
  "msg": "OK",
  "data": [
    {
      "id": 2,
      "projectId": 1,
      "keywordId": 4,
      "keyName": "云登",
      "isActive": 0,
      "domains": [
        {
          "projectId": 3,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 3,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 3,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 3,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 4,
          "keyName": "云登",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 1,
          "lastDate": "2026-01-12",
          "lastRank": 1,
          "rankDiff": 0
        }
      ]
    },
    {
      "id": 1,
      "projectId": 1,
      "keywordId": 3,
      "keyName": "指纹浏览器",
      "isActive": 0,
      "domains": [
        {
          "projectId": 3,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 3,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 3,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 1,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 2,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 3,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        },
        {
          "projectId": 4,
          "keywordId": 3,
          "keyName": "指纹浏览器",
          "domainId": 1,
          "domainName": "yunlogin.com",
          "firstDate": "2026-01-12",
          "firstRank": 2,
          "lastDate": "2026-01-12",
          "lastRank": 2,
          "rankDiff": 0
        }
      ]
    }
  ]
}
```

## 接口返回字段说明

根据您提供的API接口文档和数据库表结构，以下是各个接口返回值的详细字段说明：

## 一、通用响应字段

```json
{
  "reqId": "string",      // 请求唯一标识，用于追踪请求
  "code": 200,            // 响应状态码：200-成功，400-客户端错误，500-服务器错误
  "msg": "OK",           // 响应消息：成功时为"OK"，错误时为错误描述
  "data": {}             // 响应数据，具体结构见各接口说明
}
```


```go
const (
	SUCCESS                = 200   //成功
	FAILURE                = 500   //失败
	InvalidToken_401       = 401   //没有登录
	AuthorizationError_403 = 403   //没有权限
	NotFound_404           = 404   //资源不存在
	UserNotExist           = 1027  //当前账号不存在，请先注册
	UserLock               = 1028  //当前账号被冻结
	PwdNotExist            = 1029  //尚未设置密码，请选择验证码登录
	ThirdNotScan           = 1055  //未收到扫描信息
	ThirdExpire            = 1056  //已过期
	InvalidParameter       = 10000 //参数错误
	ErrRePassword          = 10001 //重复密码不一致
	ErrPasswordFMT         = 10002 //密码长度必须6位
	ErrMobileOrEmail       = 10003 //必须手机号或者邮箱注册
	ErrParams              = 10004 //参数错误
	ErrVerifyCode          = 10005 //验证码错误
	ErrBind                = 10008 //绑定失败
	ErrUserExist           = 10011 //账号已经注册，请直接登录
	ErrPwd                 = 10012 //密码错误
	ErrUsernameOrPwd       = 10013 //账号或密码错误
	RequestsFrequently     = 10102 //请求太频繁
	CaptchaErr             = 10103 //获取验证码失败
	CaptchaVerifyErr       = 10104 //验证码
	PhoneExistErr          = 10201 //手机号已存在
	EmailExistErr          = 10202 //邮箱已存在
)

const (
	ErrProName           = 10301 //项目名称不能为空
	ErrProNameExist      = 10311 //项目名称已存在
	ErrDomainEmpty       = 10302 //域名不能为空
	ErrDomainInvalid     = 10303 //域名格式错误
	ErrDomainNumTooMany  = 10304 //域名不能超过5个
	ErrKeywordEmpty      = 10305 //关键词不能为空
	ErrKeywordInvalid    = 10306 //关键词格式错误
	ErrKeywordNumTooMany = 10307 //关键词不能超过1000个
	ErrEngineEmpty       = 10308 //引擎不能为空
	ErrEngineInvalid     = 10309 //引擎格式错误
	ErrAmountNotEnough   = 10310 //余额不足
	ErrDomainExist       = 10312 //域名已存在
	ErrKeywordExist      = 10313 //关键词已存在
	ErrProjectNumTooMany = 10314 //项目数已超过套餐限制
	ErrProjectNoExist    = 10315 //项目不存在
)
```

## 二、各个接口返回值字段说明

### 1. 搜索引擎列表接口
**端点：** `POST /api/v1/seo/seo-project/engine-types`
```json
"data": ["bing", "google"]  // 数组，支持的搜索引擎类型列表
```

### 2. 创建项目接口
**端点：** `POST /api/v1/seo/seo-project/create`
```json
"data": null  // 无数据返回，通过code和msg判断是否成功
```

### 3. 更新项目接口
**端点：** `POST /api/v1/seo/seo-project/update`
```json
"data": null  // 无数据返回，通过code和msg判断是否成功
```

### 4. 项目详情接口
**端点：** `POST /api/v1/seo/seo-project/get`
```json
"data": {
  "id": 1,                    // 项目ID
  "userId": 986,              // 用户ID
  "proName": "云登浏览器",      // 项目名称
  "keywordNum": 2,            // 关键词数量
  "domainNum": 2,             // 域名数量
  "engineTypes": ["google"],  // 搜索引擎类型数组
  "deviceTypes": null,        // 设备类型数组（pc, mobile）
  "ranking": 0,               // 排名设置：0-未知，1-前10，2-前20，3-前30，4-前40，5-前50，6-前100
  "lifeTime": "1970-01-01T08:00:00+08:00", // 项目生命周期
  "schType": "daily",         // 调度类型：daily, weekly, monthly
  "days": "1",                // 执行周期天数
  "hour": 1,                  // 执行时间小时（0-23）
  "minute": 0,                // 执行时间分钟（0-59）
  "cronExpr": "",             // cron表达式
  "state": 1,                 // 项目状态：1-正常，2-停止
  "createdAt": "2026-01-08T16:01:16+08:00", // 创建时间
  "updatedAt": "2026-01-08T19:04:25+08:00", // 更新时间
  "deletedAt": null           // 删除时间，null表示未删除
}
```

### 5. 项目关键词列表接口（分页）
**端点：** `POST /api/v1/seo/seo-project-keywords/page`
```json
"data": {
  "list": [                  // 关键词列表数据
    {
      "id": 2,               // 项目关键词配置ID
      "userId": 986,         // 用户ID
      "projectId": 1,        // 项目ID
      "keywordId": 4,        // 关键词ID
      "keyName": "云登",      // 关键词名称
      "isActive": 1,         // 是否启用：0-否，1-是
      "createdAt": "2026-01-08T16:01:16+08:00" // 创建时间
    }
  ],
  "total": 2,                // 总记录数
  "pageSize": 10,            // 每页大小
  "currentPage": 1           // 当前页码
}
```

### 6. 项目域名列表接口（分页）
**端点：** `POST /api/v1/seo/seo-user-domains/page`
```json
"data": {
  "list": [                  // 域名列表数据
    {
      "id": 2,               // 用户域名配置ID
      "userId": 986,         // 用户ID
      "projectId": 1,        // 项目ID
      "domainId": 4,         // 域名ID
      "domainName": "www.yunlogin.com", // 域名名称
      "isActive": 1,         // 是否启用：0-否，1-是
      "domainType": 0,       // 域名类型：1-根域，2-子域（文档中0可能是未知或根域）
      "createdAt": "2026-01-08T16:01:16+08:00" // 创建时间
    }
  ],
  "total": 2,                // 总记录数
  "pageSize": 10,            // 每页大小
  "currentPage": 1           // 当前页码
}
```

### 7. 项目列表接口（分页）
**端点：** `POST /api/v1/seo/seo-project/page`
```json
"data": {
  "id": 1,                    // 项目ID
  "userId": 986,              // 用户ID
  "proName": "云登浏览器",      // 项目名称
  "keywordNum": 2,            // 关键词数量
  "domainNum": 2,             // 域名数量
  "engineTypes": ["google"],  // 搜索引擎类型数组
  "deviceTypes": null,        // 设备类型数组
  "ranking": 0,               // 排名设置
  "lifeTime": "1970-01-01T08:00:00+08:00", // 项目生命周期
  "schType": "daily",         // 调度类型
  "days": "1",                // 执行周期天数
  "hour": 1,                  // 执行时间小时
  "minute": 0,                // 执行时间分钟
  "cronExpr": "",             // cron表达式
  "state": 1,                 // 项目状态
  "createdAt": "2026-01-08T16:01:16+08:00", // 创建时间
  "updatedAt": "2026-01-08T19:04:25+08:00", // 更新时间
  "deletedAt": null           // 删除时间
}
```

### 8. 删除项目接口
**端点：** `POST /api/v1/seo/seo-project/del`
```json
"data": null  // 无数据返回，通过code和msg判断是否成功
```

### 9. 启动/停止项目接口
**端点：** `POST /api/v1/seo/seo-project/on-off`
```json
"data": null  // 无数据返回，通过code和msg判断是否成功
```

### 10. 项目执行频率更新接口
**端点：** `POST /api/v1/seo/seo-project/update-cron`
```json
"data": null  // 无数据返回，通过code和msg判断是否成功
```

### 11. 项目任务执行结果详情接口（分页）
**端点：** `POST /api/v1/seo/seo-user-ranking-history/page`
```json
"data": {
  "list": [                  // 排名历史记录列表
    {
      "id": 2,               // 排名历史记录ID
      "userId": 986,         // 用户ID
      "projectId": 1,        // 项目ID
      "projectName": "测试测试", // 项目名称
      "taskId": 2,           // 任务ID
      "keywordId": 4,        // 关键词ID
      "keywordName": "云登",  // 关键词名称
      "domainId": 1,         // 域名ID
      "domainName": "yunlogin.com", // 域名名称
      "engineType": "google", // 搜索引擎类型
      "rankPosition": 1,     // 排名位置（数字越小排名越靠前）
      "preRanking": 0,       // 上次排名位置（0表示首次排名）
      "rankChange": 0,       // 排名变化（当前排名 - 上次排名，负数表示上升）
      "createdAt": "2026-01-09T15:53:51+08:00" // 创建时间
    }
  ],
  "total": 2,                // 总记录数
  "pageSize": 10,            // 每页大小
  "currentPage": 1           // 当前页码
}
```

### 12. 项目关键词排名分布接口
**端点：** `POST /api/v1/seo/seo-user-ranking-history/distribution`
```json
"data": [                  // 按日期统计的排名分布数组
  {
    "createdDate": "2026-01-09", // 统计日期
    "r1": 1,                     // 1-3名数量
    "r2": 1,                     // 4-10名数量
    "r3": 0,                     // 11-20名数量
    "r4": 0,                     // 21-30名数量
    "r5": 0,                     // 31-50名数量
    "r6": 0                      // 51-100名数量
  }
]
```

### 13. 项目关键词排名对比接口
**端点：** `POST /api/v1/seo/seo-project-keywords/first-last-rank`
```json
"data": [                  // 关键词排名对比数据数组
  {
    "id": 2,               // 项目关键词配置ID
    "projectId": 1,        // 项目ID
    "keywordId": 4,        // 关键词ID
    "keyName": "云登",      // 关键词名称
    "isActive": 0,         // 是否启用：0-否，1-是
    "domains": [           // 该关键词在不同域名的排名变化数据
      {
        "projectId": 3,    // 项目ID
        "keywordId": 4,    // 关键词ID
        "keyName": "云登",  // 关键词名称
        "domainId": 1,     // 域名ID
        "domainName": "yunlogin.com", // 域名名称
        "firstDate": "2026-01-12",    // 首次有记录的日期
        "firstRank": 1,    // 首次排名位置
        "lastDate": "2026-01-12",     // 最后有记录的日期
        "lastRank": 1,     // 最后排名位置
        "rankDiff": 0      // 排名位差（lastRank - firstRank）
                           // 负数：排名上升；正数：排名下降；0：排名不变
      }
    ]
  }
]
```

## 三、关键字段状态说明

### 1. 项目状态 (state)
- `1`：正常（启用）
- `2`：停止（禁用）

### 2. 排名设置 (ranking)
- `0`：未知/默认
- `1`：前10名
- `2`：前20名
- `3`：前30名
- `4`：前40名
- `5`：前50名
- `6`：前100名

### 3. 调度类型 (schType)
- `daily`：每天执行
- `weekly`：每周执行
- `monthly`：每月执行

### 4. 是否启用 (isActive)
- `0`：否（禁用）
- `1`：是（启用）

### 5. 域名类型 (domainType)
- `1`：根域名（后缀匹配）
- `2`：子域
- `0`：未知/根域（根据文档中的示例）

### 6. 排名变化说明
- `rankDiff = lastRank - firstRank`
  - 负数：排名上升（如-3表示上升3名）
  - 正数：排名下降（如+2表示下降2名）
  - 0：排名不变

### 7. 排名位置 (rankPosition)
- `1-100`：具体的排名位置
- `0`：未收录/未找到排名
- 数字越小表示排名越靠前（1为第1名）

## 字段说明

### 一、seo_keywords (SEO关键词表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| key_name | VARCHAR(128) | 关键词名称，唯一索引 |
| state | TINYINT(1) | 状态：0-禁用，1-正常 |
| created_at | DATETIME | 创建时间 |

### 二、seo_domains (SEO域名表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| domain_name | VARCHAR(250) | 域名，唯一索引 |
| created_at | DATETIME | 创建时间 |
| deleted_at | DATETIME | 删除时间（软删除标志） |

### 三、seo_project (SEO项目配置表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| user_id | INT | 用户ID |
| pro_name | VARCHAR(64) | 项目名称 |
| keyword_num | INT | 关键词数量 |
| domain_num | INT | 域名数量 |
| engine_types | JSON | 搜索引擎类型：[google, bing, baidu] |
| device_types | JSON | 设备类型：[pc, mobile] |
| ranking | TINYINT | 排名设置：1-前10名，2-前20名，3-前30名，4-前40名，5-前50名，6-前100名 |
| life_time | DATETIME | 项目生命周期 |
| sch_type | VARCHAR(16) | 调度类型：daily, weekly, monthly |
| days | VARCHAR(32) | 执行周期天数 |
| hour | TINYINT | 执行时(0-23) |
| minute | TINYINT | 执行分(0-59) |
| cron_expr | VARCHAR(64) | cron表达式 |
| next_run_at | DATETIME | 下次执行时间 |
| last_run_at | DATETIME | 最新执行时间 |
| state | TINYINT(1) | 项目状态：1-正常，2-停止 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |
| deleted_at | DATETIME | 删除时间（软删除标志） |

### 四、seo_project_keywords (SEO项目关键词配置表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT UNSIGNED | 主键，自增ID |
| user_id | INT | 用户ID |
| project_id | INT | 项目ID |
| keyword_id | INT | 关键词ID |
| key_name | VARCHAR(128) | 关键词名称 |
| is_active | TINYINT | 是否启用：0-否，1-是 |
| created_at | DATETIME | 创建时间 |

### 五、seo_project_task (SEO项目任务表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| user_id | INT | 用户ID |
| project_id | INT | SEO项目ID |
| keyword_id | INT | 关键词ID |
| engine_type | VARCHAR(30) | 搜索引擎：google, bing, baidu |
| device_type | VARCHAR(30) | 设备类型：pc, mobile |
| state | TINYINT | 状态：-1失败，0未开始，1执行中，2完成，3暂停，4结束 |
| next_run_at | DATETIME | 下次执行时间 |
| created_at | DATETIME | 创建时间 |
| updated_at | DATETIME | 更新时间 |
| deleted_at | DATETIME | 删除时间（软删除标志） |

### 六、seo_results (SEO数据结果表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| engine_type | VARCHAR(32) | 引擎名称：google, bing, baidu |
| rank_position | INT | 排名位置 |
| keyword_name | VARCHAR(128) | 关键词名称 |
| keyword_id | INT | 关键词表ID |
| title | VARCHAR(512) | 名称 |
| link | VARCHAR(2048) | 结果域名1 |
| displayed_link | VARCHAR(2048) | 结果域名2 |
| current | SMALLINT | 页数 |
| created_at | DATETIME | 创建时间 |
| created_date | DATE | 创建日期 |
| updated_at | DATETIME | 更新时间 |

### 七、seo_task_exec_log (SEO项目任务执行记录表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| user_id | INT | 用户ID |
| project_id | INT | 项目ID |
| task_id | INT | 任务ID |
| start_time | DATETIME | 任务开始时间 |
| finished_time | DATETIME | 任务完成时间 |
| state | TINYINT | 状态：-1失败，0未开始，1执行中，2完成，3暂停，4结束 |
| total_keyworks | INT | 总关键词数 |
| processed_keyworks | INT | 已执行关键词数 |
| success_count | INT | 执行成功数 |
| faild_count | INT | 执行失败数 |
| api_count | INT UNSIGNED | api调用数 |
| err_msg | VARCHAR(512) | 错误信息 |
| created_at | DATETIME | 创建时间 |

### 八、seo_user_domains (SEO用户域名配置表)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| domain_id | INT | 域名ID |
| domain_name | VARCHAR(250) | 域名 |
| user_id | INT | 用户ID |
| project_id | INT | 项目ID |
| is_active | TINYINT | 是否匹配：0-否，1-是 |
| domain_type | TINYINT(1) | 域名类型：1-根域，2-子域 |
| created_at | DATETIME | 创建时间 |

### 九、seo_user_ranking_history (SEO用户排名数据变化记录)
| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | INT | 主键，自增ID |
| user_id | INT | 用户ID |
| project_id | INT | 项目ID |
| task_id | INT | 任务ID |
| keyword_id | INT | 关键词表ID |
| domain_id | INT | 域名表ID |
| rank_position | INT | 排名位置 |
| pre_ranking | INT | 上次排名位置 |
| rank_change | INT | 排名变化 |
| amount | INT | 消耗点数 |
| created_at | DATETIME | 创建时间 |
| created_date | DATE | 创建日期 |
