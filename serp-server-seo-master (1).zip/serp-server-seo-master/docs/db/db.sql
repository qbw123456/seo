-- --------------------------------------------------------
-- 主机:                           192.168.0.80
-- 服务器版本:                        8.0.42-0ubuntu0.22.04.1 - (Ubuntu)
-- 服务器操作系统:                      Linux
-- HeidiSQL 版本:                  12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 导出 search-seo 的数据库结构
CREATE DATABASE IF NOT EXISTS `search-seo` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `search-seo`;

-- 导出  表 search-seo.seo_domains 结构
CREATE TABLE IF NOT EXISTS `seo_domains` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domain_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '域名',
  `created_at` datetime NOT NULL DEFAULT (now()) COMMENT '创建时间',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domain_name` (`domain_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='SEO域名表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_keywords 结构
CREATE TABLE IF NOT EXISTS `seo_keywords` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key_name` varchar(128) NOT NULL DEFAULT '' COMMENT '关键词名称',
  `state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：0：禁用；1：正常',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ky` (`key_name`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='SEO关键词表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_project 结构
CREATE TABLE IF NOT EXISTS `seo_project` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `pro_name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '项目名称',
  `keyword_num` int NOT NULL DEFAULT (0) COMMENT '关键词数量',
  `domain_num` int NOT NULL DEFAULT (0) COMMENT '域名数量',
  `engine_types` json DEFAULT NULL COMMENT '搜索引擎类型；google，bing，baidu',
  `device_types` json DEFAULT NULL COMMENT '设备类型；pc，mobbile',
  `ranking` tinyint NOT NULL DEFAULT '1' COMMENT '排名设置；1:前10名，2:前20名， 3:前30名， 4:前40名，5:前50名，6：前100名',
  `life_time` datetime DEFAULT NULL COMMENT '项目生命周期',
  `sch_type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '调度类型：daily，weekly，monthly',
  `days` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '0' COMMENT '执行周期天数',
  `hour` tinyint NOT NULL DEFAULT '0' COMMENT '执行时',
  `minute` tinyint NOT NULL DEFAULT '0' COMMENT '执行分',
  `cron_expr` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT 'cron表达式',
  `next_run_at` datetime DEFAULT NULL COMMENT '下次执行时间',
  `last_run_at` datetime DEFAULT NULL COMMENT '最新执行时间',
  `state` tinyint(1) NOT NULL DEFAULT '1' COMMENT '项目状态；1：正常；2：停止',
  `pending_tasks` int NOT NULL DEFAULT '0' COMMENT '待执行任务数',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uid` (`user_id`) USING BTREE,
  KEY `pro_name` (`pro_name`),
  KEY `state` (`state`),
  KEY `next_run_at` (`next_run_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='SEO项目配置表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_project_keywords 结构
CREATE TABLE IF NOT EXISTS `seo_project_keywords` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `project_id` int NOT NULL COMMENT '项目ID',
  `keyword_id` int NOT NULL,
  `key_name` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否启用；0：否；1：是',
  `created_at` datetime NOT NULL DEFAULT (now()) COMMENT '创建时间',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id_keyword_id` (`project_id`,`keyword_id`),
  KEY `key_name` (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC COMMENT='SEO项目关键词配置表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_project_task 结构
CREATE TABLE IF NOT EXISTS `seo_project_task` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `project_id` int NOT NULL COMMENT 'SEO 项目ID',
  `keyword_id` int NOT NULL DEFAULT '0' COMMENT '关键词ID',
  `engine_type` varchar(30) NOT NULL COMMENT '搜索引擎；google，bing，baidu',
  `device_type` varchar(30) NOT NULL COMMENT '设备类型；pc，mobbile',
  `state` tinyint NOT NULL DEFAULT '0' COMMENT '状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束',
  `next_run_at` datetime DEFAULT NULL COMMENT '下次执行时间',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `engine_type` (`engine_type`),
  KEY `project_id` (`project_id`),
  KEY `keyword_id` (`keyword_id`),
  KEY `state` (`state`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='SEO项目任务表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_results 结构
CREATE TABLE IF NOT EXISTS `seo_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `engine_type` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '引擎名称；google bing baidu ...',
  `rank_position` int NOT NULL DEFAULT '0' COMMENT '排名位置',
  `keyword_name` varchar(128) NOT NULL DEFAULT '' COMMENT '关键词名称',
  `keyword_id` int NOT NULL DEFAULT '0' COMMENT '关键词表ID',
  `title` varchar(512) NOT NULL DEFAULT '' COMMENT '名称',
  `link` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '结果域名1',
  `displayed_link` varchar(2048) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '结果域名2',
  `current` smallint NOT NULL DEFAULT '0' COMMENT '页数',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_date` date DEFAULT NULL COMMENT '创建日期',
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kid_e_rp` (`created_date`,`keyword_id`,`engine_type`,`rank_position`,`current`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='SEO数据结果表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_task_exec_log 结构
CREATE TABLE IF NOT EXISTS `seo_task_exec_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `project_id` int NOT NULL COMMENT '项目ID',
  `task_id` int NOT NULL COMMENT '任务ID',
  `start_time` datetime NOT NULL COMMENT '任务开始时间',
  `finished_time` datetime DEFAULT NULL COMMENT '任务完成时间',
  `state` tinyint NOT NULL DEFAULT '0' COMMENT '状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束',
  `total_keyworks` int NOT NULL DEFAULT '0' COMMENT '总关键词数',
  `processed_keyworks` int NOT NULL DEFAULT '0' COMMENT '已执行关键词数',
  `success_count` int NOT NULL DEFAULT '0' COMMENT '执行成功数',
  `faild_count` int NOT NULL DEFAULT '0' COMMENT '执行失败数',
  `api_count` int unsigned NOT NULL DEFAULT '0' COMMENT 'api调用数',
  `err_msg` varchar(512) NOT NULL DEFAULT '' COMMENT '错误信息',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`user_id`) USING BTREE,
  KEY `proid` (`project_id`) USING BTREE,
  KEY `tid` (`task_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='SEO项目任务执行记录表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_user_domains 结构
CREATE TABLE IF NOT EXISTS `seo_user_domains` (
  `id` int NOT NULL AUTO_INCREMENT,
  `domain_id` int NOT NULL DEFAULT '0',
  `domain_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '域名',
  `user_id` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `project_id` int NOT NULL COMMENT '项目ID',
  `is_active` tinyint NOT NULL DEFAULT '1' COMMENT '是否匹配；0：否；1：是',
  `domain_type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '域名类型；1：根域；2：子域',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domain_id_project_id` (`domain_id`,`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='SEO用户域名配置表';

-- 数据导出被取消选择。

-- 导出  表 search-seo.seo_user_ranking_history 结构
CREATE TABLE IF NOT EXISTS `seo_user_ranking_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL DEFAULT '0' COMMENT '用户ID',
  `project_id` int NOT NULL DEFAULT '0' COMMENT '项目ID',
  `task_id` int NOT NULL DEFAULT '0' COMMENT '任务ID',
  `keyword_id` int NOT NULL DEFAULT '0' COMMENT '关键词表ID',
  `domain_id` int NOT NULL DEFAULT '0' COMMENT '域名表ID',
  `engine_type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '搜索引擎；google，bing，baidu',
  `rank_position` int NOT NULL DEFAULT '0' COMMENT '排名位置',
  `pre_ranking` int NOT NULL DEFAULT '0' COMMENT '上次排名位置',
  `rank_change` int NOT NULL DEFAULT '0' COMMENT '排名变化',
  `amount` int NOT NULL DEFAULT '0' COMMENT '消耗点数',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `created_date` date DEFAULT NULL COMMENT '创建日期',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_id_keyword_id_domain_id_created_date` (`project_id`,`keyword_id`,`domain_id`,`created_date`),
  KEY `idx_kd_id` (`keyword_id`,`domain_id`) USING BTREE,
  KEY `user_id` (`user_id`),
  KEY `task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='SEO用户排名数据变化记录';

-- 数据导出被取消选择。

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
