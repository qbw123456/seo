package apis

var (
	InitApi = Init{}
)
