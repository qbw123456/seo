package prometheus

import (
	"context"
	"dilu/common/prometheus"
	"log/slog"
)

type Params struct {
	PayType string
	ErrType string
}

type Service struct {
	Params Params
	ctx    context.Context
}

// New 实例化
func New(metrics Params) *Service {
	return &Service{
		Params: metrics,
		ctx:    context.Background(),
	}
}

// SeoCronErrorCount 定时任务执行失败
func (pro *Service) SeoCronErrorCount() {
	payType := pro.Params.PayType
	errType := pro.Params.ErrType

	go func() {
		defer func() {
			if reErr := recover(); reErr != nil {
				slog.Error("get:SeoCronErrorCount", reErr)
			}
		}()

		prometheus.SeoCronErrorCount.WithLabelValues(payType, errType).Inc()
		slog.Info("SEO定时任务执行失败", "payType", payType, "errType", errType)
	}()
}
