package router

import (
	"dilu/common/prometheus"
	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerPrometheusRouter)
}

// 默认需登录认证的路由
func registerPrometheusRouter(v1 *gin.RouterGroup) {
	v1.GET("/", func(c *gin.Context) {
		c.Writer.Header().Set("Content-Encoding", "identity")
		prometheus.Handler().ServeHTTP(c.Writer, c.Request)
	})
}
