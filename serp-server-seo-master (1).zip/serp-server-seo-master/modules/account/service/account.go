package service

import (
	"dilu/modules/account/models"

	"github.com/baowk/dilu-core/core/base"
	"gorm.io/gorm"
)

type AccountService struct {
	*base.BaseService
}

var SerAccount = AccountService{
	base.NewService("account"),
}

func (s *AccountService) GetAccount(uid int) (account *models.Account, err error) {
	err = s.DB().Model(&models.Account{}).Where("user_id = ?", uid).Find(&account).Error
	return
}

// DecrementAmount 扣减用户的点数
func (s *AccountService) DecrementAmount(tx *gorm.DB, uid, amount int) *gorm.DB {
	return s.DB().Model(&models.Account{}).
		Where("user_id = ?", uid).
		UpdateColumn("amount", gorm.Expr("amount - ?", amount))
}
