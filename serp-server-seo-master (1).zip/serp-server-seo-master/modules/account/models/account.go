package models

import (
	"database/sql/driver"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"gorm.io/datatypes"
	"gorm.io/gorm"
)

const (
	UserTypeToPlan   = 1 // 套餐用户
	UserTypeToCredit = 2 // 授信用户
)

// 用户钱包账户
type Account struct {
	Id             uint64                      `json:"id" gorm:"type:bigint unsigned;primaryKey;autoIncrement;comment:主键"`    //主键
	UserId         int64                       `json:"userId" gorm:"type:bigint unsigned;comment:用户id"`                       //用户id
	Username       string                      `json:"username" gorm:"type:varchar(50);comment:用户名"`                          //联系人用户名
	Mobile         string                      `json:"mobile" gorm:"type:varchar(18);comment:手机号"`                            //联系人手机号
	Email          string                      `json:"email" gorm:"type:varchar(128);comment:邮箱"`                             //联系人邮箱
	Nickname       string                      `json:"nickname" gorm:"type:varchar(64);comment:昵称"`                           //联系人昵称
	Avatar         string                      `json:"avatar" gorm:"type:varchar(255);comment:头像"`                            //头像
	Amount         int64                       `json:"amount" gorm:"type:bigint;comment:余额"`                                  //余额
	TrustedAmount  int64                       `json:"trustedAmount" gorm:"type:bigint;comment:授信金额"`                         //授信金额
	ApiKey         string                      `json:"apiKey" gorm:"type:varchar(255);comment:api_key"`                       //api_key
	UserType       int8                        `json:"userType" gorm:"type:tinyint;default:1;comment:用户类型 1 套餐用户 2 授信账户"`     //用户类型 1 套餐用户 2 授信账户
	PlanExpired    time.Time                   `json:"planExpired" gorm:"type:datetime;comment:套餐截至时间"`                       //套餐截至时间
	Status         int8                        `json:"status" gorm:"type:tinyint;default:1;comment:1正常 -1锁定"`                 //1正常 -1锁定
	Limits         Limit                       `json:"limits" gorm:"type:json;comment:限制"`                                    //qps限制
	Servers        datatypes.JSONSlice[Server] `json:"servers"`                                                               //服务器列表
	Setting        datatypes.JSONType[Setting] `json:"setting"`                                                               //设置
	LastBuyId      int                         `json:"lastBuyId" gorm:"type:int;comment:最后一次购买套餐id"`                          //最后一次购买套餐id
	MealId         int64                       `json:"mealId" gorm:"type:bigint unsigned;comment:套餐id"`                       //套餐id
	Remark         string                      `json:"remark" gorm:"type:varchar(255);comment:备注"`                            //备注
	TotalRecharged int64                       `json:"totalRecharged" gorm:"type:bigint;comment:累计充值金额"`                      // 累计充值金额
	TotalConsumed  int64                       `json:"totalConsumed" gorm:"type:bigint;comment:累计消费次数"`                       // 累计消费次数
	CreatedAt      time.Time                   `json:"createdAt" gorm:"type:datetime;default:CURRENT_TIMESTAMP;comment:创建时间"` //创建时间
	UpdatedAt      time.Time                   `json:"updatedAt" gorm:"type:datetime;comment:更新时间"`                           //更新时间
	DeletedAt      gorm.DeletedAt              `json:"-" gorm:"index;comment:删除时间"`                                           //删除时间
}

const TBAccount = "account"

func (Account) TableName() string {
	return TBAccount
}

type Limit struct {
	Google  int `json:"google"`  // google并发数
	Bing    int `json:"bing"`    // bing并发数
	Project int `json:"project"` // 项目数
}

func (s *Limit) Scan(value interface{}) error {
	bytes, ok := value.([]byte)
	if !ok {
		return errors.New(fmt.Sprint("Failed to unmarshal JSONB value:", value))
	}
	if len(bytes) == 0 {
		*s = Limit{
			Bing:   10,
			Google: 10,
		}
		return nil
	}
	err := json.Unmarshal(bytes, s)
	if err != nil {
		slog.Error("json.Unmarshal failed", "err", err)
	}
	return err
}

// Value return json value, implement driver.Valuer interface
func (s Limit) Value() (driver.Value, error) {
	return json.Marshal(s)
}

type Server struct {
	Url    string `json:"url"`    // 主机地址
	Region string `json:"region"` // 区域
	Engine string `json:"engine"` // 引擎类型 google/bing/browser
}

func (a *Account) GetServerUrls(region, engine string) ([]string, error) {
	var urls []string
	for _, server := range a.Servers {
		if server.Region == region && server.Engine == engine {
			urls = append(urls, server.Url)
		}
	}
	return urls, nil
}

type Setting struct {
	GoogleIPPool  string `json:"googleIPPool"`  // google ip池
	BingIPPool    string `json:"bingIPPool"`    // bing ip池
	BrowserIPPool string `json:"browserIPPool"` // browser ip池
}
