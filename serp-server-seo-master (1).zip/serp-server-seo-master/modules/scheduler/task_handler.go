package scheduler

import (
	"dilu/modules/seo/service"
	"dilu/modules/scheduler/worker"
	"log/slog"
)

// TaskHandlerImpl 任务处理器实现
type TaskHandlerImpl struct{}

// Execute 执行任务
func (h *TaskHandlerImpl) Execute(task worker.Task) error {
	// 调用SEO服务执行任务
	slog.Debug("TaskHandler执行任务", "taskId", task.Id, "userId", task.UserId)
	return service.SerSeoProjectTask.ExecuteTask(task)
}
