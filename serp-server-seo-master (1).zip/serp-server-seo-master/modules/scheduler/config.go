package scheduler

import (
	"dilu/common/config"
	"time"
)

// Config 调度器配置
type Config struct {
	Enable          bool
	Type            string
	ScanCronExpr    string        // Cron 表达式（如 "*/30 * * * *" 表示每30秒）
	MinScanInterval time.Duration // 最小扫描间隔
	MaxScanInterval time.Duration // 最大扫描间隔
	MaxWorkers      int           // 最大工作协程数
	TaskQueueSize   int           // 队列任务数
	BatchSize       int           // 批量任务处理大小
	ScanWindowMins  int           // 扫描时间窗口（分钟）
}

// DefaultConfig 默认配置
func DefaultConfig() Config {
	scanCronExpr := config.Ext.Scheduler.ScanCronExpr
	if scanCronExpr == "" {
		scanCronExpr = "*/30 * * * *" // 默认每30秒扫描一次
	}

	return Config{
		Enable:          config.Ext.Scheduler.Enable,
		Type:            "cron",
		ScanCronExpr:    scanCronExpr,
		MinScanInterval: config.Ext.Scheduler.MinScanInterval,
		MaxScanInterval: config.Ext.Scheduler.MaxScanInterval,
		MaxWorkers:      config.Ext.Scheduler.Worker.MaxWorkers,
		TaskQueueSize:   config.Ext.Scheduler.Worker.TaskQueueSize,
		BatchSize:       config.Ext.Scheduler.Worker.BatchSize,
		ScanWindowMins:  config.Ext.Scheduler.Worker.ScanWindowMins,
	}
}
