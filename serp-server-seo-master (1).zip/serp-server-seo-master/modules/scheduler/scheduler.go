package scheduler

import (
	"context"
	"dilu/modules/scheduler/worker"
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"log/slog"
	"sync"
	"time"

	"github.com/baowk/dilu-core/core"
	"github.com/robfig/cron/v3"
	"gorm.io/gorm"
)

// Scheduler SEO任务调度器
type Scheduler struct {
	db         *gorm.DB
	workerPool *worker.Pool
	cron       *cron.Cron
	mu         sync.RWMutex
	taskChan   chan worker.Task
	ctx        context.Context
	cancel     context.CancelFunc
	config     Config
	closed     bool
}

// NewScheduler 创建调度器实例
func NewScheduler(cfg Config) *Scheduler {
	ctx, cancel := context.WithCancel(context.Background())

	// 创建 Cron 调度器
	c := cron.New(cron.WithSeconds(), cron.WithChain(cron.SkipIfStillRunning(cron.DefaultLogger)))

	// 创建worker池
	pool := worker.NewWorkerPool(worker.Config{
		MaxWorkers:    cfg.MaxWorkers,
		TaskQueueSize: cfg.TaskQueueSize,
	}, nil)

	return &Scheduler{
		db:         core.Db("seo"),
		cron:       c,
		workerPool: pool,
		mu:         sync.RWMutex{},
		config:     cfg,
		taskChan:   make(chan worker.Task, cfg.TaskQueueSize),
		ctx:        ctx,
		cancel:     cancel,
	}
}

// Start 启动调度器
func (s *Scheduler) Start() {
	if !s.config.Enable {
		slog.Info("SEO任务调度器未启用")
		return
	}

	// 启动工作池
	s.workerPool.Start()

	// 启动任务分发器
	go s.taskDispatcher()

	// 启动项目状态更新器
	if _, err := s.cron.AddFunc(s.config.ScanCronExpr, s.updateProjectCompletedTasks); err != nil {
		slog.Error("添加Cron任务失败", "cron_expr", s.config.ScanCronExpr, "error", err)
		return
	}

	// 启动任务生成器
	if _, err := s.cron.AddFunc(s.config.ScanCronExpr, s.scanPendingProjects); err != nil {
		slog.Error("添加Cron任务失败", "cron_expr", s.config.ScanCronExpr, "error", err)
		return
	}

	// 启动任务扫描器
	if _, err := s.cron.AddFunc(s.config.ScanCronExpr, s.scanPendingTasks); err != nil {
		slog.Error("添加Cron任务失败", "cron_expr", s.config.ScanCronExpr, "error", err)
		return
	}

	// 启动 Cron 调度器
	s.cron.Start()

	slog.Info("SEO任务调度器已启动", "type", s.config.Type, "maxWorkers", s.config.MaxWorkers, "scan_cron", s.config.ScanCronExpr)
}

// Stop 停止调度器
func (s *Scheduler) Stop() {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.closed {
		return
	}

	s.cron.Stop()
	s.cancel()

	// 等待一小段时间确保 goroutine 有机会退出
	time.Sleep(50 * time.Millisecond)

	// 安全关闭 channel
	select {
	case <-s.taskChan:
	default:
	}
	close(s.taskChan)

	s.closed = true
	slog.Info("SEO任务调度器已停止")
}

// ReloadTasks 重新加载任务（用于热更新）
func (s *Scheduler) ReloadTasks() error {
	slog.Info("开始重新加载定时任务")
	return nil
}

func (s *Scheduler) updateProjectCompletedTasks() {

	batchSize := s.config.BatchSize
	totalDispatched := 0
	totalDispatchErrors := 0
	totalProjectCount := 0

	lastId := 0

	for {
		// 查询已经达到执行时间的项目
		var projects []models.SeoProject
		err := service.SerSeoProject.DB().Model(&models.SeoProject{}).
			Where("id > ? and pending_tasks>0", lastId).
			Order("id asc").
			Limit(batchSize + 1).
			Find(&projects).Error

		if err != nil {
			slog.Error("扫描待执行项目失败", "cursor_id", lastId, "error", err)
			break
		}

		if len(projects) <= 0 {
			break
		}

		for _, project := range projects {
			totalProjectCount++

			// 查询项目已完成任务数
			var pendingTasks int64
			if err := service.SerSeoProjectTask.DB().Model(&models.SeoProjectTask{}).
				Where("project_id = ? AND state <> ?", project.Id, models.TASK_TATE_TO_FINISHED).
				Count(&pendingTasks).Error; err != nil {
				slog.Error("查询项目已完成任务数失败", "projectId", project.Id, "error", err)
				continue
			}
			// updates := map[string]interface{}{
			// 	"completed_tasks": completedTasks,
			// 	"last_run_at":     time.Now(),
			// 	"pending_tasks":   0,
			// }
			updates := map[string]interface{}{
				"pending_tasks": pendingTasks,
			}
			if pendingTasks <= 0 {
				updates["last_run_at"] = time.Now()
				updates["pending_tasks"] = 0
			}

			// 更新项目已完成任务数
			if upErr := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("id = ?", project.Id).Updates(updates).Error; upErr != nil {
				slog.Error("更新项目已完成任务数失败", "projectId", project.Id, "error", upErr.Error())
				continue
			}
			slog.Debug("更新项目已完成任务数成功", "projectId", project.Id, "pending_tasks", pendingTasks)
		}

	}

	slog.Info("扫描项目状态完成", "total_project_count", totalProjectCount, "total_dispatched", totalDispatched, "total_errors", totalDispatchErrors)
}

// scanPendingProjects 扫描项目并生成任务
func (s *Scheduler) scanPendingProjects() {
	now := time.Now()

	endTime := now.Add(time.Minute)

	batchSize := s.config.BatchSize
	totalDispatched := 0
	totalDispatchErrors := 0
	totalProjectCount := 0

	lastId := 0

	for {
		// 查询已经达到执行时间的项目
		var projects []models.SeoProject
		err := service.SerSeoProject.DB().Model(&models.SeoProject{}).
			Where("id > ? and state = ? and next_run_at <= ? AND next_run_at is not null", lastId, models.STATE_TO_NORMAL, endTime).
			Order("id asc").
			Limit(batchSize + 1).
			Find(&projects).Error

		if err != nil {
			slog.Error("扫描待执行项目失败", "cursor_id", lastId, "error", err)
			break
		}

		if len(projects) <= 0 {
			break
		}

		for _, project := range projects {
			totalProjectCount++

			// 添加任务
			err := service.SerSeoProjectTask.AddCronTask(&project)
			if err != nil {
				totalDispatchErrors++
			}
		}

	}

	slog.Info("扫描项目完成", "total_project_count", totalProjectCount, "total_dispatched", totalDispatched, "total_errors", totalDispatchErrors)
}

// scanPendingTasks 扫描并分发待执行任务
func (s *Scheduler) scanPendingTasks() {
	now := time.Now()

	// 扫描过去N分钟到现在 + 未来1分钟内的任务，为了处理因分批执行导致延迟的任务
	//windowDuration := time.Duration(s.config.ScanWindowMins) * time.Minute
	//startTime := now.Add(-windowDuration)
	endTime := now.Add(time.Minute)

	batchSize := s.config.BatchSize
	totalDispatched := 0
	totalDispatchErrors := 0
	totalTaskCnt := 0

	lastId := 0

	for {
		// 查询即将执行的任务
		tasks, err := service.SerSeoProjectTask.GetTasksDue(lastId, batchSize, endTime)

		if err != nil {
			slog.Error("扫描待执行任务失败", "cursor_id", lastId, "error", err)
			break
		}

		tasksCnt := len(tasks)

		if tasksCnt == 0 {
			break
		}

		// 获取数据里最大的taskId
		lastId = tasks[tasksCnt-1].Id

		// 批量更新任务状态为执行中（使用乐观锁防止重复执行）
		taskIds := make([]int, len(tasks))

		for i, task := range tasks {
			taskIds[i] = task.Id
		}

		// 更新
		upErr := service.SerSeoProjectTask.UpdateTaskState(taskIds, models.TASK_TATE_TO_RUNNING)
		if upErr != nil {
			slog.Error("批量更新任务状态失败", "cursor_id", lastId, "error", upErr)
			break
		}

		// 分发实际需要处理的任务
		dispatched := 0

		for _, task := range tasks {
			select {
			case s.taskChan <- worker.Task{
				Id:         task.Id,
				UserId:     task.UserId,
				ProjectId:  task.ProjectId,
				KeywordId:  task.KeywordId,
				EngineType: task.EngineType,
			}:
				dispatched++
			default:
				slog.Error("任务发发失败，任务分发队列已满", "taskId", task.Id)
				totalDispatchErrors++
			}
		}

		totalDispatched += dispatched
		totalTaskCnt += tasksCnt
	}

	slog.Info("扫描任务完成", "total_task_count", totalTaskCnt, "total_dispatched", totalDispatched, "total_errors", totalDispatchErrors)
}

// taskDispatcher 任务分发器
func (s *Scheduler) taskDispatcher() {
	for {
		select {
		case <-s.ctx.Done():
			return
		case task := <-s.taskChan:
			s.workerPool.Submit(task)
		}
	}
}

// GetRunningTaskCount 获取正在运行的任务数
func (s *Scheduler) GetRunningTaskCount() int {
	return len(s.taskChan)
}

// SetTaskHandler 设置任务处理器
func (s *Scheduler) SetTaskHandler(handler worker.TaskHandler) *Scheduler {
	s.workerPool.SetHandler(handler)
	return s
}
