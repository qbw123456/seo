package scheduler

import (
	"sync"
)

var (
	globalScheduler *Scheduler
	mu              sync.RWMutex
)

// InitScheduler 初始化调度器
func InitScheduler() (err error) {
	cfg := DefaultConfig()

	// 设置任务处理器并执行
	NewScheduler(cfg).SetTaskHandler(&TaskHandlerImpl{}).Start()
	return
}

// GetScheduler 获取全局调度器实例
func GetScheduler() *Scheduler {
	mu.RLock()
	defer mu.RUnlock()

	return globalScheduler
}
