package worker

import (
	"sync/atomic"
	"testing"
	"time"
)

func TestWorkerPool_Basic(t *testing.T) {
	pool := NewWorkerPool(Config{
		MaxWorkers:    5,
		TaskQueueSize: 100,
	}, nil)
	defer pool.Stop()

	pool.Start()

	submitted := atomic.Int64{}
	executed := atomic.Int64{}

	// 提交10个任务
	for i := 0; i < 10; i++ {
		taskId := i
		go func() {
			submitted.Add(1)
			pool.Submit(Task{
				Id:         taskId,
				UserId:     1,
				ProjectId:  1,
				KeywordId:  taskId,
				EngineType: "google",
			})
			executed.Add(1)
		}()
	}

	// 等待所有任务完成
	time.Sleep(2 * time.Second)

	s, c, f := pool.GetStats()
	t.Logf("提交: %d, 完成: %d, 失败: %d", s, c, f)

	if submitted.Load() != 10 {
		t.Errorf("提交任务数不匹配: 期望 10, 实际 %d", submitted.Load())
	}
}

func TestWorkerPool_QueueFull(t *testing.T) {
	pool := NewWorkerPool(Config{
		MaxWorkers:    1,
		TaskQueueSize: 2,
	}, nil)
	defer pool.Stop()

	pool.Start()

	success := 0
	failed := 0

	// 提交超过队列大小的任务
	for i := 0; i < 10; i++ {
		taskId := i
		if pool.Submit(Task{
			Id:         taskId,
			UserId:     1,
			ProjectId:  1,
			KeywordId:  taskId,
			EngineType: "google",
		}) {
			success++
		} else {
			failed++
		}
	}

	t.Logf("成功提交: %d, 失败: %d", success, failed)

	if failed == 0 {
		t.Error("应该有部分任务因队列满而失败")
	}
}
