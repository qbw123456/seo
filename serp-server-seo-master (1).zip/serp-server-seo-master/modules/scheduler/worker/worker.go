package worker

import (
	"context"
	"log/slog"
	"sync"
	"sync/atomic"
)

// Task Worker执行的任务
type Task struct {
	Id         int
	UserId     int
	ProjectId  int
	KeywordId  int
	EngineType string
}

// TaskHandler 任务处理器接口
type TaskHandler interface {
	Execute(task Task) error
}

// Pool WorkerPool Worker池
type Pool struct {
	config    Config
	taskChan  chan Task
	workers   []*Worker
	wg        sync.WaitGroup
	ctx       context.Context
	cancel    context.CancelFunc
	submitted atomic.Int64
	completed atomic.Int64
	failed    atomic.Int64
	handler   TaskHandler
	closed    atomic.Bool
}

// Config Worker池配置
type Config struct {
	MaxWorkers    int
	TaskQueueSize int
}

// NewWorkerPool 创建Worker池
func NewWorkerPool(cfg Config, handler TaskHandler) *Pool {
	ctx, cancel := context.WithCancel(context.Background())

	return &Pool{
		config:   cfg,
		taskChan: make(chan Task, cfg.TaskQueueSize),
		ctx:      ctx,
		cancel:   cancel,
		handler:  handler,
	}
}

// Start 启动Worker池
func (p *Pool) Start() {
	for i := 0; i < p.config.MaxWorkers; i++ {
		w := NewWorker(i, p.taskChan, p.handler)
		p.workers = append(p.workers, w)

		p.wg.Add(1)
		go w.Run(&p.wg, p.ctx)
	}

	slog.Info("Worker池已启动", "workerCount", p.config.MaxWorkers)
}

func (p *Pool) Stop() {
	if !p.closed.CompareAndSwap(false, true) {
		return
	}

	p.cancel()
	close(p.taskChan)

	p.wg.Wait()
}

// Submit 提交任务到Worker池
func (p *Pool) Submit(task Task) bool {
	if p.closed.Load() {
		p.failed.Add(1)
		return false
	}

	p.submitted.Add(1)

	select {
	case p.taskChan <- task:
		return true
	default:
		p.failed.Add(1)
		slog.Warn("任务队列已满，任务丢弃", "taskId", task.Id)
		return false
	}
}

// GetStats 获取Worker池统计信息
func (p *Pool) GetStats() (submitted, completed, failed int64) {
	return p.submitted.Load(), p.completed.Load(), p.failed.Load()
}

// SetHandler 设置处理
func (p *Pool) SetHandler(handler TaskHandler) {
	p.handler = handler
}

// Worker 单个工作器
type Worker struct {
	id       int
	taskChan <-chan Task
	handler  TaskHandler
}

// NewWorker 创建Worker
func NewWorker(id int, taskChan <-chan Task, handler TaskHandler) *Worker {
	return &Worker{
		id:       id,
		taskChan: taskChan,
		handler:  handler,
	}
}

// Run 运行Worker
func (w *Worker) Run(g *sync.WaitGroup, ctx context.Context) {
	defer g.Done()

	for {
		select {
		case <-ctx.Done():
			return
		case task, ok := <-w.taskChan:
			if !ok {
				return
			}
			w.processTask(task)
		}
	}
}

func (w *Worker) processTask(task Task) bool {
	defer func() {
		if reErr := recover(); reErr != nil {
			slog.Error("processTaskErr", "taskId", task.Id, "err", reErr)
		}
	}()

	if w.handler == nil {
		slog.Error("Worker未设置任务处理器", "workerId", w.id)
		return false
	}

	if err := w.handler.Execute(task); err != nil {
		slog.Error("Worker处理任务失败", "workerId", w.id, "taskId", task.Id, "error", err)
		return false
	}

	slog.Debug("Worker处理任务成功", "workerId", w.id, "taskId", task.Id)
	return true
}
