package apis

import (
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"

	"github.com/baowk/dilu-core/core/base"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/copier"
)

type SeoKeywordsApi struct {
	base.BaseApi
}

var ApiSeoKeywords = SeoKeywordsApi{}

// @Summary 获取SEO关键词表列表
// @Tags seo-SeoKeywords
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoKeywordsGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoKeywords}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-keywords/page [post]
// @Security Bearer
func (e *SeoKeywordsApi) QueryPage(c *gin.Context) {
	var req dto.SeoKeywordsGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	list := make([]models.SeoKeywords, 0, req.GetSize())
	var total int64

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	if err := service.SerSeoKeywords.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

// @Summary 获取SEO关键词表
// @Tags seo-SeoKeywords
// @Accept application/json
// @Product application/json
// @Param data body base.ReqId true "body"
// @Success 200 {object} base.Resp{data=models.SeoKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-keywords/get [post]
// @Security Bearer
func (e *SeoKeywordsApi) Get(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoKeywords
	if err := service.SerSeoKeywords.Get(req.Id, &data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 创建SEO关键词表
// @Tags seo-SeoKeywords
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoKeywordsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-keywords/create [post]
// @Security Bearer
func (e *SeoKeywordsApi) Create(c *gin.Context) {
	var req dto.SeoKeywordsDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoKeywords
	copier.Copy(&data, req)
	if err := service.SerSeoKeywords.Create(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 更新SEO关键词表
// @Tags seo-SeoKeywords
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoKeywordsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-keywords/update [post]
// @Security Bearer
func (e *SeoKeywordsApi) Update(c *gin.Context) {
	var req dto.SeoKeywordsDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoKeywords
	copier.Copy(&data, req)
	if err := service.SerSeoKeywords.UpdateById(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 删除SEO关键词表
// @Tags seo-SeoKeywords
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-keywords/del [post]
// @Security Bearer
func (e *SeoKeywordsApi) Del(c *gin.Context) {
	var req base.ReqIds
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if err := service.SerSeoKeywords.DelIds(&models.SeoKeywords{}, req.Ids); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c)
}
