package apis

import (
	"dilu/common/codes"
	"dilu/common/utils"
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"
	"encoding/csv"
	"errors"
	"fmt"
	"net/http"
	"strconv"
	"time"

	"github.com/baowk/dilu-core/core/base"
	"github.com/gin-gonic/gin"
)

type SeoUserRankingHistoryApi struct {
	base.BaseApi
}

var ApiSeoUserRankingHistory = SeoUserRankingHistoryApi{}

// @Summary 获取SEO用户排名数据变化记录列表
// @Tags seo-SeoUserRankingHistory
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoUserRankingHistoryGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoUserRankingHistory}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-user-ranking-history/page [post]
// @Security Bearer
func (e *SeoUserRankingHistoryApi) QueryPage(c *gin.Context) {
	var req dto.SeoUserRankingHistoryGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.ProjectId <= 0 {
		e.Error(c, errors.New("projectId is empty"))
		return
	}

	list := make([]dto.SeoUserRankingHistoryDto, 0, req.GetSize())
	var total int64

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	req.UserId = int(utils.GetAppUid(c))

	if err := service.SerSeoUserRankingHistory.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

func (e *SeoUserRankingHistoryApi) Export(c *gin.Context) {
	var req dto.SeoUserRankingHistoryGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.ProjectId <= 0 {
		e.Fail(c, codes.ErrParams, "projectId is empty")
		return
	}
	req.UserId = int(utils.GetAppUid(c))

	data := models.SeoProject{}
	err := service.SerSeoProject.DB().Where("user_id = ? AND id = ?", req.UserId, req.ProjectId).First(&data).Error
	if err != nil {
		e.Fail(c, codes.ErrProjectNoExist, "projectId not exist")
		return
	}

	filename := fmt.Sprintf("%s_关键词排名_%s.csv", data.ProName, time.Now().Format("20060102"))

	if req.SortOrder == "" {
		req.SortOrder = "asc"
	}

	req.Page = 1
	req.PageSize = 5000 // CSV可以支持更大的分页

	// 设置响应头
	c.Header("Content-Type", "text/csv")
	c.Header("Content-Disposition", fmt.Sprintf("attachment; filename=%s.csv", filename))
	c.Header("Transfer-Encoding", "chunked")

	c.Writer.WriteString("\xEF\xBB\xBF")

	writer := csv.NewWriter(c.Writer)
	defer writer.Flush()

	// 写入CSV表头
	headers := []string{
		"项目名称", "关键词名称", "域名", "搜索引擎", "当前排名", "上次排名", "排名变化", "创建时间",
	}

	if err := writer.Write(headers); err != nil {
		e.Error(c, err)
		return
	}
	writer.Flush()

	totalExported := 0

	for {
		var total int64
		list := make([]dto.SeoUserRankingHistoryDto, 0, req.PageSize)

		if err := service.SerSeoUserRankingHistory.QueryPage(req, &list, &total, req.PageSize, (req.Page-1)*req.PageSize); err != nil {
			e.Error(c, err)
			return
		}

		if len(list) == 0 {
			break
		}

		// 写入数据行
		for _, history := range list {
			record := []string{
				history.ProjectName,
				history.KeywordName,
				history.DomainName,
				history.EngineType,
				strconv.Itoa(history.RankPosition),
				strconv.Itoa(history.PreRanking),
				strconv.Itoa(history.RankChange),
				history.CreatedAt.Format("2006-01-02 15:04:05"),
			}

			if err := writer.Write(record); err != nil {
				e.Error(c, err)
				return
			}
			totalExported++
		}

		writer.Flush() // 刷新缓冲区到HTTP响应

		// 如果支持Flush，则强制刷新
		if flusher, ok := c.Writer.(http.Flusher); ok {
			flusher.Flush()
		}

		// 更新进度
		fmt.Printf("已导出 %d 条记录\n", totalExported)

		// 检查是否结束
		if int64(totalExported) >= total || len(list) < req.PageSize {
			break
		}

		req.Page++
	}

	fmt.Printf("导出完成，共导出 %d 条记录\n", totalExported)
}

func (e *SeoUserRankingHistoryApi) Distribution(c *gin.Context) {
	var req dto.DistributionReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.ProjectId <= 0 {
		e.Fail(c, codes.ErrParams, "projectId is empty")
		return
	}

	if req.DomainId <= 0 {
		e.Fail(c, codes.ErrParams, "domainId is empty")
		return
	}

	if req.EngineType == "" {
		e.Fail(c, codes.ErrParams, "engineType is empty")
		return
	}

	// 验证开始日期格式
	if req.StartDate == "" {
		e.Fail(c, codes.ErrParams, "startDate is empty")
		return
	}
	// 验证结束日期
	if req.EndDate == "" {
		e.Fail(c, codes.ErrParams, "endDate is empty")
		return
	}

	// 可选：添加日期格式验证
	layout := "2006-01-02" // 根据实际格式调整
	if _, err := time.Parse(layout, req.StartDate); err != nil {
		e.Fail(c, codes.ErrParams, "startDate format is invalid, expected format: YYYY-MM-DD")
		return
	}
	if _, err := time.Parse(layout, req.EndDate); err != nil {
		e.Fail(c, codes.ErrParams, "endDate format is invalid, expected format: YYYY-MM-DD")
		return
	}

	// 验证结束日期不小于开始日期
	startTime, _ := time.Parse(layout, req.StartDate)
	endTime, _ := time.Parse(layout, req.EndDate)
	if endTime.Before(startTime) {
		e.Fail(c, codes.ErrParams, "endDate must be after or equal to startDate")
		return
	}
	// 验证结束日期和开始日期不超过3个月
	if endTime.Sub(startTime) > 3*30*24*time.Hour {
		e.Fail(c, codes.ErrParams, "endDate and startDate must be within 90 days")
		return
	}

	req.UserId = int(utils.GetAppUid(c))

	list := []dto.DistributionRes{}

	if err := service.SerSeoUserRankingHistory.DB().Raw(`
SELECT 
    created_date,
    SUM(IF(rank_position BETWEEN 1 AND 3, 1, 0)) AS r1,
    SUM(IF(rank_position BETWEEN 4 AND 10, 1, 0)) AS r2,
    SUM(IF(rank_position BETWEEN 11 AND 20, 1, 0)) AS r3,
    SUM(IF(rank_position BETWEEN 21 AND 30, 1, 0)) AS r4,
    SUM(IF(rank_position BETWEEN 31 AND 50, 1, 0)) AS r5,
    SUM(IF(rank_position > 50, 1, 0)) AS r6
FROM seo_user_ranking_history
WHERE deleted_at IS NULL 
    AND created_date IS NOT NULL
    AND user_id = ?
    AND project_id = ?
    AND domain_id = ?
    AND engine_type = ?
    AND created_date >= ?
    AND created_date <= ?
GROUP BY created_date
ORDER BY created_date ASC
	`, req.UserId, req.ProjectId, req.DomainId, req.EngineType, req.StartDate, req.EndDate).Scan(&list).Error; err != nil {
		e.Error(c, err)
		return
	}

	e.Ok(c, list)
}
