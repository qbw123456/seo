package apis

import (
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"

	"github.com/baowk/dilu-core/core/base"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/copier"
)

type SeoTaskExecLogApi struct {
	base.BaseApi
}

var ApiSeoTaskExecLog = SeoTaskExecLogApi{}

// @Summary 获取SEO项目任务执行记录表列表
// @Tags seo-SeoTaskExecLog
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoTaskExecLogGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoTaskExecLog}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-task-exec-log/page [post]
// @Security Bearer
func (e *SeoTaskExecLogApi) QueryPage(c *gin.Context) {
	var req dto.SeoTaskExecLogGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	list := make([]models.SeoTaskExecLog, 0, req.GetSize())
	var total int64

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	if err := service.SerSeoTaskExecLog.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

// @Summary 获取SEO项目任务执行记录表
// @Tags seo-SeoTaskExecLog
// @Accept application/json
// @Product application/json
// @Param data body base.ReqId true "body"
// @Success 200 {object} base.Resp{data=models.SeoTaskExecLog} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-task-exec-log/get [post]
// @Security Bearer
func (e *SeoTaskExecLogApi) Get(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoTaskExecLog
	if err := service.SerSeoTaskExecLog.Get(req.Id, &data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 创建SEO项目任务执行记录表
// @Tags seo-SeoTaskExecLog
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoTaskExecLogDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoTaskExecLog} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-task-exec-log/create [post]
// @Security Bearer
func (e *SeoTaskExecLogApi) Create(c *gin.Context) {
	var req dto.SeoTaskExecLogDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoTaskExecLog
	copier.Copy(&data, req)
	if err := service.SerSeoTaskExecLog.Create(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 更新SEO项目任务执行记录表
// @Tags seo-SeoTaskExecLog
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoTaskExecLogDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoTaskExecLog} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-task-exec-log/update [post]
// @Security Bearer
func (e *SeoTaskExecLogApi) Update(c *gin.Context) {
	var req dto.SeoTaskExecLogDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoTaskExecLog
	copier.Copy(&data, req)
	if err := service.SerSeoTaskExecLog.UpdateById(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 删除SEO项目任务执行记录表
// @Tags seo-SeoTaskExecLog
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoTaskExecLog} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-task-exec-log/del [post]
// @Security Bearer
func (e *SeoTaskExecLogApi) Del(c *gin.Context) {
	var req base.ReqIds
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if err := service.SerSeoTaskExecLog.DelIds(&models.SeoTaskExecLog{}, req.Ids); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c)
}
