package apis

import (
	"dilu/common/codes"
	"dilu/common/utils"
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"
	"errors"
	"log/slog"

	"github.com/baowk/dilu-core/core/base"
	"github.com/gin-gonic/gin"
)

type SeoUserDomainsApi struct {
	base.BaseApi
}

var ApiSeoUserDomains = SeoUserDomainsApi{}

// @Summary 获取SEO用户域名配置表列表
// @Tags seo-SeoUserDomains
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoUserDomainsGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoUserDomains}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-user-domains/page [post]
// @Security Bearer
func (e *SeoUserDomainsApi) QueryPage(c *gin.Context) {
	var req dto.SeoUserDomainsGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	list := make([]models.SeoUserDomains, 0, req.GetSize())
	var total int64

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	req.UserId = int(utils.GetAppUid(c))

	if err := service.SerSeoUserDomains.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

// @Summary 获取SEO用户域名配置表
// @Tags seo-SeoUserDomains
// @Accept application/json
// @Product application/json
// @Param data body base.ReqId true "body"
// @Success 200 {object} base.Resp{data=models.SeoUserDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-user-domains/get [post]
// @Security Bearer
func (e *SeoUserDomainsApi) Get(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoUserDomains
	if err := service.SerSeoUserDomains.DB().Model(&models.SeoUserDomains{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).First(&data).Error; err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 创建SEO用户域名配置表
// @Tags seo-SeoUserDomains
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoUserDomainsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoUserDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-user-domains/create [post]
// @Security Bearer
func (e *SeoUserDomainsApi) Create(c *gin.Context) {
	var req dto.SeoProjectDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if req.Id <= 0 {
		e.Error(c, errors.New("项目ID不能为空"))
		return
	}
	if !req.ValidDomainList() {
		e.Error(c, errors.New("the domain name is invalid"))
		return
	}

	// 查找项目是否存在
	var project models.SeoProject
	err := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("user_id = ? AND id = ?", utils.GetAppUid(c), req.Id).First(&project).Error
	if err != nil {
		e.Error(c, err)
		return
	}

	defer func() {
		// 更新项目域名数量
		num := int64(0)
		err := service.SerSeoUserDomains.DB().Model(&models.SeoUserDomains{}).Where("project_id = ? AND user_id = ?", project.Id, utils.GetAppUid(c)).Count(&num).Error
		if err != nil {
			e.Error(c, err)
			return
		}
		ret := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).UpdateColumn("domain_num", num)
		if ret.Error != nil {
			e.Error(c, ret.Error)
			return
		}
	}()

	// 查找域名，不存在则添加
	domainNames := make([]string, 0, len(req.DomainList))
	for _, d := range req.DomainList {
		domainNames = append(domainNames, d.DomainName)
	}

	// 检查项目中是否已经存在域名
	projectDomains := models.SeoUserDomains{}
	err = service.SerSeoUserDomains.DB().Model(&models.SeoUserDomains{}).Where("domain_name in ? AND project_id = ?", domainNames, project.Id).Limit(1).Find(&projectDomains).Error
	if err != nil {
		e.Error(c, err)
		return
	}
	if projectDomains.Id > 0 {
		e.Fail(c, codes.ErrDomainExist, "the domain "+projectDomains.DomainName+" already exists in the project")
		return
	}

	domains := []models.SeoDomains{}
	err = service.SerSeoDomains.DB().Model(&models.SeoDomains{}).Where("domain_name in ?", domainNames).Find(&domains).Error
	if err != nil {
		e.Error(c, err)
		return
	}

	noExistDomains := []string{}
	if len(domains) > 0 {
		domainNameMap := make(map[string]bool)
		for _, domain := range domains {
			domainNameMap[domain.DomainName] = true
		}

		for _, name := range domainNames {
			if _, ok := domainNameMap[name]; !ok {
				noExistDomains = append(noExistDomains, name)
			}
		}
	} else {
		noExistDomains = domainNames
	}

	if len(noExistDomains) > 0 {
		// 添加域名
		if addDomainsEr := service.SerSeoDomains.UpsertSeoDomain(noExistDomains); addDomainsEr != nil {
			e.Error(c, err)
			return
		}
		err = service.SerSeoDomains.DB().Model(&models.SeoDomains{}).Where("domain_name in ?", domainNames).Find(&domains).Error
		if err != nil {
			e.Error(c, err)
			return
		}
	}
	domainIds := map[string]int{}
	for _, domain := range domains {
		domainIds[domain.DomainName] = domain.Id
	}

	for i, kd := range req.DomainList {
		if _, ok := domainIds[kd.DomainName]; !ok {
			e.Error(c, errors.New("the domain "+kd.DomainName+" does not exist"))
			return
		}
		req.DomainList[i].DomainId = domainIds[kd.DomainName]
	}

	// 添加用户域名
	if err := service.SerSeoUserDomains.AddUserDomain(service.SerSeoUserDomains.DB(), int(utils.GetAppUid(c)), project.Id, req.DomainList); err != nil {
		slog.Error("添加用户域名发生错误", "err", err)
		if utils.IsErrDuplicatedKey(err) {
			e.Fail(c, codes.ErrDomainExist, "the domain already exists")
			return
		}
	}

	e.Ok(c)
}

// @Summary 更新SEO用户域名配置表
// @Tags seo-SeoUserDomains
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoUserDomainsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoUserDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-user-domains/update [post]
// @Security Bearer
func (e *SeoUserDomainsApi) Update(c *gin.Context) {
	var req dto.SeoUserDomainsDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if req.IsActive == 0 {
		// 禁用关键词
		if err := service.SerSeoUserDomains.DB().Model(&models.SeoUserDomains{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).Update("is_active", 0).Error; err != nil {
			e.Error(c, err)
			return
		}
	} else {
		// 启用关键词
		if err := service.SerSeoUserDomains.DB().Model(&models.SeoUserDomains{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).Update("is_active", 1).Error; err != nil {
			e.Error(c, err)
			return
		}
	}
	e.Ok(c)
}

// @Summary 删除SEO用户域名配置表
// @Tags seo-SeoUserDomains
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoUserDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-user-domains/del [post]
// @Security Bearer
func (e *SeoUserDomainsApi) Del(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if err := service.SerSeoUserDomains.DB().Model(&models.SeoUserDomains{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).Delete(&models.SeoUserDomains{}).Error; err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c)
}
