package apis

import (
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"

	"github.com/baowk/dilu-core/core/base"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/copier"
)

type SeoProjectTaskApi struct {
	base.BaseApi
}

var ApiSeoProjectTask = SeoProjectTaskApi{}

// @Summary 获取SEO项目任务表列表
// @Tags seo-SeoProjectTask
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectTaskGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoProjectTask}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-task/page [post]
// @Security Bearer
func (e *SeoProjectTaskApi) QueryPage(c *gin.Context) {
	var req dto.SeoProjectTaskGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	list := make([]models.SeoProjectTask, 0, req.GetSize())
	var total int64

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	if err := service.SerSeoProjectTask.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

// @Summary 获取SEO项目任务表
// @Tags seo-SeoProjectTask
// @Accept application/json
// @Product application/json
// @Param data body base.ReqId true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectTask} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-task/get [post]
// @Security Bearer
func (e *SeoProjectTaskApi) Get(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoProjectTask
	if err := service.SerSeoProjectTask.Get(req.Id, &data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 创建SEO项目任务表
// @Tags seo-SeoProjectTask
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectTaskDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectTask} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-task/create [post]
// @Security Bearer
func (e *SeoProjectTaskApi) Create(c *gin.Context) {
	var req dto.SeoProjectTaskDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoProjectTask
	copier.Copy(&data, req)
	if err := service.SerSeoProjectTask.Create(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 更新SEO项目任务表
// @Tags seo-SeoProjectTask
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectTaskDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectTask} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-task/update [post]
// @Security Bearer
func (e *SeoProjectTaskApi) Update(c *gin.Context) {
	var req dto.SeoProjectTaskDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoProjectTask
	copier.Copy(&data, req)
	if err := service.SerSeoProjectTask.UpdateById(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 删除SEO项目任务表
// @Tags seo-SeoProjectTask
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectTask} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-task/del [post]
// @Security Bearer
func (e *SeoProjectTaskApi) Del(c *gin.Context) {
	var req base.ReqIds
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if err := service.SerSeoProjectTask.DelIds(&models.SeoProjectTask{}, req.Ids); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c)
}
