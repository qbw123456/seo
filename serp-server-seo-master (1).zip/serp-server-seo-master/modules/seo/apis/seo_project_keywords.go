package apis

import (
	"dilu/common/codes"
	"dilu/common/utils"
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"
	"errors"
	"log/slog"
	"time"

	"github.com/baowk/dilu-core/core/base"
	"github.com/gin-gonic/gin"
)

type SeoProjectKeywordsApi struct {
	base.BaseApi
}

var ApiSeoProjectKeywords = SeoProjectKeywordsApi{}

// @Summary 获取SEO项目关键词配置表列表
// @Tags seo-SeoProjectKeywords
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectKeywordsGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoProjectKeywords}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-keywords/page [post]
// @Security Bearer
func (e *SeoProjectKeywordsApi) QueryPage(c *gin.Context) {
	var req dto.SeoProjectKeywordsGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	list := make([]models.SeoProjectKeywords, 0, req.GetSize())
	var total int64

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	req.UserId = int(utils.GetAppUid(c))

	if err := service.SerSeoProjectKeywords.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

// @Summary 获取SEO项目关键词配置表
// @Tags seo-SeoProjectKeywords
// @Accept application/json
// @Product application/json
// @Param data body base.ReqId true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-keywords/get [post]
// @Security Bearer
func (e *SeoProjectKeywordsApi) Get(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	var data models.SeoProjectKeywords
	if err := service.SerSeoProjectKeywords.DB().Model(&models.SeoProjectKeywords{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).First(&data).Error; err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 创建SEO项目关键词配置表
// @Tags seo-SeoProjectKeywords
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectKeywordsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-keywords/create [post]
// @Security Bearer
func (e *SeoProjectKeywordsApi) Create(c *gin.Context) {
	var req dto.SeoProjectDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if req.Id <= 0 {
		e.Error(c, errors.New("项目ID不能为空"))
		return
	}

	if !req.ValidDomainList() {
		e.Error(c, errors.New("the domain name is invalid"))
		return
	}

	// 查找项目是否存在
	var project models.SeoProject
	err := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("user_id = ? AND id = ?", utils.GetAppUid(c), req.Id).First(&project).Error
	if err != nil {
		e.Error(c, err)
		return
	}

	defer func() {
		// 更新项目关键词数量
		num := int64(0)
		err := service.SerSeoProjectKeywords.DB().Model(&models.SeoProjectKeywords{}).Where("project_id = ? AND user_id = ?", project.Id, utils.GetAppUid(c)).Count(&num).Error
		if err != nil {
			e.Error(c, err)
			return
		}
		ret := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).UpdateColumn("keyword_num", num)
		if ret.Error != nil {
			e.Error(c, ret.Error)
			return
		}
	}()

	// 查找域名，不存在则添加
	keyNames := make([]string, 0, len(req.KeywordList))
	for _, d := range req.KeywordList {
		keyNames = append(keyNames, d.KeyName)
	}

	// 检查项目中是否已经存在域名
	projectKeywords := models.SeoProjectKeywords{}
	err = service.SerSeoProjectKeywords.DB().Model(&models.SeoProjectKeywords{}).Where("key_name in ? AND project_id = ?", keyNames, project.Id).Limit(1).Find(&projectKeywords).Error
	if err != nil {
		e.Error(c, err)
		return
	}
	if projectKeywords.Id > 0 {
		e.Fail(c, codes.ErrDomainExist, "the keyword "+projectKeywords.KeyName+" already exists in the project")
		return
	}

	keywords := []models.SeoKeywords{}
	err = service.SerSeoKeywords.DB().Model(&models.SeoKeywords{}).Where("key_name in ?", keyNames).Find(&keywords).Error
	if err != nil {
		e.Error(c, err)
		return
	}

	noExistKeywords := []string{}
	if len(keywords) > 0 {
		keyNameMap := make(map[string]bool)
		for _, keyword := range keywords {
			keyNameMap[keyword.KeyName] = true
		}

		for _, keyname := range keyNames {
			if _, ok := keyNameMap[keyname]; !ok {
				noExistKeywords = append(noExistKeywords, keyname)
			}
		}
	} else {
		noExistKeywords = keyNames
	}

	if len(noExistKeywords) > 0 {
		// 添加关键词
		if addKeyWordsEr := service.SerSeoKeywords.UpsertSeoKeyword(noExistKeywords); addKeyWordsEr != nil {
			e.Error(c, addKeyWordsEr)
			return
		}

		// 获取关键词Ids
		keywords, err = service.SerSeoKeywords.ListByKeyNames(keyNames)
		if err != nil {
			e.Error(c, err)
			return
		}

	}
	keywordIds := map[string]int{}
	for _, keyword := range keywords {
		keywordIds[keyword.KeyName] = keyword.Id
	}

	for i, kd := range req.KeywordList {
		if _, ok := keywordIds[kd.KeyName]; !ok {
			e.Error(c, errors.New("the keyword "+kd.KeyName+" does not exist"))
			return
		}
		req.KeywordList[i].KeywordId = keywordIds[kd.KeyName]
	}
	// 添加关键词
	if err := service.SerSeoProjectKeywords.AddProjectKeywords(service.SerSeoProjectKeywords.DB(), int(utils.GetAppUid(c)), project.Id, req.KeywordList); err != nil {
		slog.Error("添加关键词发生错误", "err", err)
		if utils.IsErrDuplicatedKey(err) {
			e.Fail(c, codes.ErrKeywordExist, "the keyword already exists")
			return
		}
	}
	e.Ok(c)
}

// @Summary 更新SEO项目关键词配置表
// @Tags seo-SeoProjectKeywords
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectKeywordsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-keywords/update [post]
// @Security Bearer
func (e *SeoProjectKeywordsApi) Update(c *gin.Context) {
	var req dto.SeoProjectKeywordsDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if req.IsActive == 0 {
		// 禁用关键词
		if err := service.SerSeoProjectKeywords.DB().Model(&models.SeoProjectKeywords{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).Update("is_active", 0).Error; err != nil {
			e.Error(c, err)
			return
		}
	} else {
		// 启用关键词
		if err := service.SerSeoProjectKeywords.DB().Model(&models.SeoProjectKeywords{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).Update("is_active", 1).Error; err != nil {
			e.Error(c, err)
			return
		}
	}
	e.Ok(c)
}

// @Summary 删除SEO项目关键词配置表
// @Tags seo-SeoProjectKeywords
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoProjectKeywords} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project-keywords/del [post]
// @Security Bearer
func (e *SeoProjectKeywordsApi) Del(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if err := service.SerSeoProjectKeywords.DB().Model(&models.SeoProjectKeywords{}).Where("id = ? AND user_id = ?", req.Id, utils.GetAppUid(c)).Delete(&models.SeoProjectKeywords{}).Error; err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c)
}

func (e *SeoProjectKeywordsApi) FirstLastRank(c *gin.Context) {
	var req dto.FirstLastRankReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	if req.ProjectId <= 0 {
		e.Fail(c, codes.ErrParams, "projectId is empty")
		return
	}

	if req.EngineType == "" {
		e.Fail(c, codes.ErrParams, "engineType is empty")
		return
	}

	// 验证开始日期格式
	if req.StartDate == "" {
		e.Fail(c, codes.ErrParams, "startDate is empty")
		return
	}
	// 验证结束日期
	if req.EndDate == "" {
		e.Fail(c, codes.ErrParams, "endDate is empty")
		return
	}

	// 可选：添加日期格式验证
	layout := "2006-01-02" // 根据实际格式调整
	if _, err := time.Parse(layout, req.StartDate); err != nil {
		e.Fail(c, codes.ErrParams, "startDate format is invalid, expected format: YYYY-MM-DD")
		return
	}
	if _, err := time.Parse(layout, req.EndDate); err != nil {
		e.Fail(c, codes.ErrParams, "endDate format is invalid, expected format: YYYY-MM-DD")
		return
	}

	// 验证结束日期不小于开始日期
	startTime, _ := time.Parse(layout, req.StartDate)
	endTime, _ := time.Parse(layout, req.EndDate)
	if endTime.Before(startTime) {
		e.Fail(c, codes.ErrParams, "endDate must be after or equal to startDate")
		return
	}
	// 验证结束日期和开始日期不超过3个月
	if endTime.Sub(startTime) > 3*30*24*time.Hour {
		e.Fail(c, codes.ErrParams, "endDate and startDate must be within 90 days")
		return
	}

	req.UserId = int(utils.GetAppUid(c))

	keywords := make([]models.SeoProjectKeywords, 0, req.GetSize())
	var total int64
	if err := service.SerSeoProjectKeywords.QueryPage(req, &keywords, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}

	keywordIDs := []int{}
	for _, keyword := range keywords {
		keywordIDs = append(keywordIDs, keyword.KeywordId)
	}

	ranks := []dto.FirstLastRankItem{}

	if err := service.SerSeoUserRankingHistory.DB().Raw(`
WITH ranked_data AS (
    SELECT 
        r.keyword_id,
        r.domain_id,
        r.rank_position,
        r.created_date,
        ROW_NUMBER() OVER (PARTITION BY r.keyword_id, r.domain_id ORDER BY r.created_date) AS first_rn,
        ROW_NUMBER() OVER (PARTITION BY r.keyword_id, r.domain_id ORDER BY r.created_date DESC) AS last_rn
    FROM seo_user_ranking_history r
    WHERE r.deleted_at IS NULL AND r.rank_position > 0 AND r.user_id=? AND r.project_id=? AND r.engine_type=? AND r.created_date >= ? AND r.created_date <= ? AND r.keyword_id IN (?)
),
first_last_rank AS (
    SELECT 
        f.keyword_id,
        f.domain_id,
        f.created_date AS first_date,
        f.rank_position AS first_rank,
        l.created_date AS last_date,
        l.rank_position AS last_rank,
        l.rank_position - f.rank_position AS rank_diff
    FROM ranked_data f
    INNER JOIN ranked_data l ON f.keyword_id = l.keyword_id 
        AND f.domain_id = l.domain_id
    WHERE f.first_rn = 1 
        AND l.last_rn = 1
)
SELECT 
    k.project_id,
    k.keyword_id,
    k.key_name,
    flr.domain_id,
    d.domain_name,
    flr.first_date,
    flr.first_rank,
    flr.last_date,
    flr.last_rank,
    flr.rank_diff
FROM first_last_rank flr
INNER JOIN seo_project_keywords k ON flr.keyword_id = k.keyword_id
INNER JOIN seo_user_domains d ON flr.domain_id = d.domain_id
WHERE k.deleted_at IS NULL 
ORDER BY k.key_name, flr.domain_id
	`, req.UserId, req.ProjectId, req.EngineType, req.StartDate, req.EndDate, keywordIDs).Scan(&ranks).Error; err != nil {
		e.Error(c, err)
		return
	}

	// 合并排名数据
	rankMap := map[int][]dto.FirstLastRankItem{}
	for _, rank := range ranks {
		rankMap[rank.KeywordId] = append(rankMap[rank.KeywordId], rank)
	}

	list := []dto.FirstLastRankRes{}
	for _, keyword := range keywords {
		list = append(list, dto.FirstLastRankRes{
			Id:        keyword.Id,
			ProjectId: keyword.ProjectId,
			KeywordId: keyword.KeywordId,
			KeyName:   keyword.KeyName,
			Domains:   rankMap[keyword.KeywordId],
		})
	}

	e.Ok(c, list)
}
