package apis

import (
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"

	"github.com/baowk/dilu-core/core/base"
	"github.com/gin-gonic/gin"
	"github.com/jinzhu/copier"
)

type SeoDomainsApi struct {
	base.BaseApi
}

var ApiSeoDomains = SeoDomainsApi{}

// @Summary 获取SEO域名表列表
// @Tags seo-SeoDomains
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoDomainsGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoDomains}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-domains/page [post]
// @Security Bearer
func (e *SeoDomainsApi) QueryPage(c *gin.Context) {
	var req dto.SeoDomainsGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	list := make([]models.SeoDomains, 0, req.GetSize())
	var total int64

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	if err := service.SerSeoDomains.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

// @Summary 获取SEO域名表
// @Tags seo-SeoDomains
// @Accept application/json
// @Product application/json
// @Param data body base.ReqId true "body"
// @Success 200 {object} base.Resp{data=models.SeoDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-domains/get [post]
// @Security Bearer
func (e *SeoDomainsApi) Get(c *gin.Context) {
	var req base.ReqId
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoDomains
	if err := service.SerSeoDomains.Get(req.Id, &data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 创建SEO域名表
// @Tags seo-SeoDomains
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoDomainsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-domains/create [post]
// @Security Bearer
func (e *SeoDomainsApi) Create(c *gin.Context) {
	var req dto.SeoDomainsDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoDomains
	copier.Copy(&data, req)
	if err := service.SerSeoDomains.Create(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 更新SEO域名表
// @Tags seo-SeoDomains
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoDomainsDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-domains/update [post]
// @Security Bearer
func (e *SeoDomainsApi) Update(c *gin.Context) {
	var req dto.SeoDomainsDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	var data models.SeoDomains
	copier.Copy(&data, req)
	if err := service.SerSeoDomains.UpdateById(&data); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
}

// @Summary 删除SEO域名表
// @Tags seo-SeoDomains
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoDomains} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-domains/del [post]
// @Security Bearer
func (e *SeoDomainsApi) Del(c *gin.Context) {
	var req base.ReqIds
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}
	if err := service.SerSeoDomains.DelIds(&models.SeoDomains{}, req.Ids); err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c)
}
