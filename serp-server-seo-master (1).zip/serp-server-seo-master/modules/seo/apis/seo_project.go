package apis

import (
	"dilu/common/third/serp_api"
	"dilu/common/utils"
	"dilu/common/utils/cron"
	"dilu/modules/seo/models"
	"dilu/modules/seo/service"
	"dilu/modules/seo/service/dto"
	"errors"
	"log/slog"
	"time"

	"github.com/baowk/dilu-core/core/base"
	"github.com/dreamsxin/go-now"
	"github.com/gin-gonic/gin"
)

type SeoProjectApi struct {
	base.BaseApi
}

var ApiSeoProject = SeoProjectApi{}

func (e *SeoProjectApi) GetEngineTypes(c *gin.Context) {

	e.Ok(c, []string{serp_api.ENGINE_TO_BING, serp_api.ENGINE_TO_GOOGLE})
}

// QueryPage @Summary 获取SEO项目配置表列表
// @Tags seo-SeoProject
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectGetPageReq true "body"
// @Success 200 {object} base.Resp{data=base.PageResp{list=[]models.SeoProject}} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project/page [post]
// @Security Bearer
func (e *SeoProjectApi) QueryPage(c *gin.Context) {
	var req dto.SeoProjectGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.SortOrder == "" {
		req.SortOrder = "desc"
	}

	req.UserId = int(utils.GetAppUid(c))

	list := make([]models.SeoProject, 0, req.GetSize())
	var total int64
	if err := service.SerSeoProject.QueryPage(req, &list, &total, req.GetSize(), req.GetOffset()); err != nil {
		e.Error(c, err)
		return
	}
	e.Page(c, list, total, req.GetPage(), req.GetSize())
}

// Get @Summary 获取SEO项目配置表
// @Tags seo-SeoProject
// @Accept application/json
// @Product application/json
// @Param data body base.ReqId true "body"
// @Success 200 {object} base.Resp{data=models.SeoProject} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project/get [get]
// @Security Bearer
func (e *SeoProjectApi) Get(c *gin.Context) {
	var req dto.SeoProjectGetPageReq

	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.ProjectId <= 0 {
		e.Error(c, errors.New("projectId is empty"))
		return
	}

	userId := int(utils.GetAppUid(c))

	data := models.SeoProject{}
	err := service.SerSeoProject.DB().Where("user_id = ? AND id = ?", userId, req.ProjectId).First(&data).Error
	if err != nil {
		e.Error(c, err)
		return
	}
	e.Ok(c, data)
	// rets, err := service.SerSeoProject.GetDetailByProIdAndUserId(userId, req.ProjectId)

	// if err != nil {
	// 	e.Error(c, err)
	// 	return
	// }

	// e.Ok(c, rets)
}

// Create @Summary 创建SEO项目配置表
// @Tags seo-SeoProject
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoProject} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project/create [post]
// @Security Bearer
func (e *SeoProjectApi) Create(c *gin.Context) {
	var req dto.SeoProjectDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	req.UserId = int(utils.GetAppUid(c))

	if code, err := service.SerSeoProject.CreateSeoProject(req); err != nil {
		slog.Error("create seo project error", "err", err)
		e.Fail(c, code, err.Error())
		return
	}

	e.Ok(c)
}

// Update @Summary 更新SEO项目配置表
// @Tags seo-SeoProject
// @Accept application/json
// @Product application/json
// @Param data body dto.SeoProjectDto true "body"
// @Success 200 {object} base.Resp{data=models.SeoProject} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project/update [post]
// @Security Bearer
func (e *SeoProjectApi) Update(c *gin.Context) {
	var req dto.SeoProjectDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	req.UserId = int(utils.GetAppUid(c))

	if req.ProName == "" {
		e.Error(c, errors.New("proName is empty"))
		return
	}

	ret := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("id = ? AND user_id = ?", req.Id, req.UserId).UpdateColumn("pro_name", req.ProName)
	if ret.Error != nil {
		e.Error(c, ret.Error)
		return
	}

	e.Ok(c)
}

func (e *SeoProjectApi) UpdateCron(c *gin.Context) {
	var req dto.SeoProjectDto
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	req.UserId = int(utils.GetAppUid(c))

	// 查找项目是否存在
	var project models.SeoProject
	err := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("user_id = ? AND id = ?", req.UserId, req.Id).First(&project).Error
	if err != nil {
		e.Error(c, err)
		return
	}

	// 校验定时任务
	cronExpr, err := cron.NewCronTask(req.CronTasks.SchType, req.CronTasks.Days, req.CronTasks.Hour, req.CronTasks.Minute).GeneratedCronExpr()
	if err != nil {
		e.Error(c, err)
		return
	}
	if cronExpr == "" {
		e.Error(c, errors.New("the cron expression is invalid"))
		return
	}

	updates := map[string]interface{}{
		"sch_type":  req.CronTasks.SchType,
		"days":      req.CronTasks.Days,
		"hour":      req.CronTasks.Hour,
		"minute":    req.CronTasks.Minute,
		"cron_expr": cronExpr,
	}
	// 判断是否是在当天
	if project.LastRunAt != nil {
		nowdatestr := time.Now().Format("2006-01-02")
		datestr := project.LastRunAt.Format("2006-01-02")
		if nowdatestr == datestr { // 今日已经执行过了，则需要更新下一次执行时间
			nextRunAt, err := cron.NextRunTime(now.EndOfDay(), cronExpr)
			if err != nil {
				e.Error(c, err)
				return
			}
			updates["next_run_at"] = nextRunAt
		}
	}

	// 更新项目的定时任务表达式
	ret := service.SerSeoProject.DB().Model(&models.SeoProject{}).Where("id = ? AND user_id = ?", req.Id, req.UserId).Updates(updates)
	if ret.Error != nil {
		e.Error(c, ret.Error)
		return
	}

	e.Ok(c)
}

// Del @Summary 删除SEO项目配置表
// @Tags seo-SeoProject
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoProject} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project/del [post]
// @Security Bearer
func (e *SeoProjectApi) Del(c *gin.Context) {
	var req dto.SeoProjectGetPageReq
	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.ProjectId <= 0 {
		e.Error(c, errors.New("projectId is empty"))
		return
	}

	userId := int(utils.GetAppUid(c))
	if err := service.SerSeoProject.DelProById(userId, req.ProjectId); err != nil {
		e.Error(c, err)
		return
	}

	e.Ok(c)
}

// OnOrOffState 启动获取停止项目
// @Tags seo-SeoProject
// @Accept application/json
// @Product application/json
// @Param data body base.ReqIds true "body"
// @Success 200 {object} base.Resp{data=models.SeoProject} "{"code": 200, "data": [...]}"
// @Router /api/v1/seo/seo-project/on-off [post]
// @Security Bearer
func (e *SeoProjectApi) OnOrOffState(c *gin.Context) {
	var req dto.SeoProjectGetPageReq

	if err := c.ShouldBind(&req); err != nil {
		e.Error(c, err)
		return
	}

	if req.ProjectId <= 0 {
		e.Error(c, errors.New("projectId is empty"))
		return
	}

	if req.State != models.STATE_TO_NORMAL && req.State != models.STATE_TO_STOP {
		e.Error(c, errors.New("state value error"))
		return
	}

	userId := int(utils.GetAppUid(c))
	upErr := service.SerSeoProject.ChangeProStateByUserIdAndProId(int64(userId), req.ProjectId, req.State)
	if upErr != nil {
		e.Error(c, upErr)
		return
	}

	e.Ok(c)
}
