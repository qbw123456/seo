package service

import (
	"dilu/modules/seo/models"
	"dilu/modules/seo/service/dto"
	"log/slog"

	"github.com/baowk/dilu-core/core/base"
	"gorm.io/gorm"
)

type SeoUserDomainsService struct {
	*base.BaseService
}

var SerSeoUserDomains = SeoUserDomainsService{
	base.NewService("seo"),
}

// AddUserDomain 添加用户域名
func (d *SeoUserDomainsService) AddUserDomain(tx *gorm.DB, userId, projectId int, domains []dto.SeoUserDomainsDto) (err error) {
	var dos []models.SeoUserDomains
	for _, dom := range domains {
		if dom.Id > 0 {
			continue
		}

		if dom.DomainType != 1 {
			dom.DomainType = 2
		}
		seoDo := models.SeoUserDomains{
			DomainId:   dom.DomainId,
			DomainName: dom.DomainName,
			UserId:     userId,
			ProjectId:  projectId,
			IsActive:   models.DOMAIN_IS_ACTIVE_OK,
			DomainType: dom.DomainType,
		}
		dos = append(dos, seoDo)
	}
	if len(dos) <= 0 {
		return
	}

	if err = tx.Model(&models.SeoUserDomains{}).
		// Clauses(clause.OnConflict{
		// 	Columns: []clause.Column{
		// 		{Name: "user_id"},
		// 		{Name: "project_id"},
		// 		{Name: "domain_name"},
		// 	},
		// 	DoNothing: true,
		// }).
		CreateInBatches(dos, 1000).Error; err != nil {
		slog.Error("批量添加用户域名", "err", err)
	}

	return
}

func (d *SeoUserDomainsService) GetDomainCountByProIdAndUserId(userId, proId int) (total int64, err error) {
	err = d.DB().Model(&models.SeoProjectTask{}).Where("user_id = ? and project_id = ?", userId, proId).Count(&total).Error
	return
}

// GetsByProIdAndUserIdAndKeyId 获取指定条件下的域名数据集
func (d *SeoUserDomainsService) GetsByProIdAndUserIdAndKeyId(userId, proId int) (domains []models.SeoUserDomains, err error) {
	err = d.DB().Where("user_id = ? and project_id = ? and is_active = ?", userId, proId, models.DOMAIN_IS_ACTIVE_OK).
		Find(&domains).Error
	return
}

func (d *SeoUserDomainsService) GetByDomainName(userId, proId int, dname string) (domains models.SeoUserDomains, err error) {
	err = d.DB().Where("user_id = ? and project_id = ? and domain_name = ? and deleted_at is null", userId, proId, dname).
		Find(&domains).Error
	return
}
