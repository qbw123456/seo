package service

import (
	"dilu/common/codes"
	"dilu/common/config"
	"dilu/common/utils"
	"dilu/common/utils/cron"
	accSer "dilu/modules/account/service"
	"dilu/modules/seo/models"
	"dilu/modules/seo/service/dto"
	"errors"
	"log/slog"
	"strings"
	"time"

	"github.com/baowk/dilu-core/core/base"
	"github.com/dreamsxin/go-now"
	"gorm.io/gorm"
)

type SeoProjectService struct {
	*base.BaseService
}

var SerSeoProject = SeoProjectService{
	base.NewService("seo"),
}

// CreateSeoProject 创建项目
func (seo *SeoProjectService) CreateSeoProject(req dto.SeoProjectDto) (int, error) {
	req.ProName = strings.TrimSpace(req.ProName)
	if req.ProName == "" {
		return codes.ErrProName, errors.New("the project name cannot be empty")
	}
	if len([]rune(req.ProName)) > 30 {
		return codes.ErrProName, errors.New("the project name is too long")
	}
	domainCnt := len(req.DomainList)
	keywordsCnt := len(req.KeywordList)
	engineCnt := len(req.EngineTypes)

	if domainCnt <= 0 {
		return codes.ErrDomainEmpty, errors.New("the domain name cannot be empty")
	}
	if domainCnt > 10 {
		return codes.ErrDomainNumTooMany, errors.New("there are too many domain")
	}
	if keywordsCnt <= 0 {
		return codes.ErrKeywordEmpty, errors.New("the keywords cannot be empty")
	}
	if keywordsCnt > 1000 {
		return codes.ErrKeywordNumTooMany, errors.New("there are too many key words")
	}
	if engineCnt <= 0 {
		return codes.ErrEngineEmpty, errors.New("the engine cannot be empty")
	}
	if !req.ValidKeywordList() {
		return codes.ErrKeywordInvalid, errors.New("the domain name is invalid")
	}
	if !req.ValidDomainList() {
		return codes.ErrDomainInvalid, errors.New("the domain name is invalid")
	}
	if !req.ValidEnginTypes() {
		return codes.ErrEngineInvalid, errors.New("the engine is invalid")
	}
	// if !req.ValidDeviceTypes() {
	// 	return errors.New("the device type is invalid")
	// }

	// 校验定时任务
	cronExpr, err := cron.NewCronTask(req.CronTasks.SchType, req.CronTasks.Days, req.CronTasks.Hour, req.CronTasks.Minute).GeneratedCronExpr()
	if err != nil {
		return codes.FAILURE, err
	}
	if cronExpr == "" {
		return codes.FAILURE, errors.New("the cron expression is invalid")
	}

	userInfo, err := accSer.SerAccount.GetAccount(req.UserId)
	if err != nil {
		return codes.FAILURE, errors.New("failed to obtain user information " + err.Error())
	}

	// 判断项目数量是否超出套餐
	total := int64(0)
	err = seo.DB().Model(&models.SeoProject{}).Where("user_id=?", req.UserId).Count(&total).Error
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return codes.FAILURE, err
		}
	}

	if userInfo.Limits.Project <= int(total) {
		return codes.ErrProjectNumTooMany, errors.New("the project number exceeds the plan limit")
	}

	// 判断项目名是否已使用
	project := models.SeoProject{}
	err = seo.DB().Model(&models.SeoProject{}).Where("user_id=? AND pro_name = ?", req.UserId, req.ProName).First(&project).Error
	if err != nil {
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return codes.FAILURE, err
		}
	} else {
		return codes.ErrProNameExist, errors.New("the project name already exists")
	}

	// 需要扣减的点数 计算方式：域名x关键词x搜索引擎x2
	score := int64(domainCnt * keywordsCnt * engineCnt * config.Ext.SerpAPI.ChargeBase.BaseTwo)

	if userInfo.Amount < score {
		return codes.ErrAmountNotEnough, errors.New("you don't have enough points, please recharge")
	}

	// 查找已有关键词，不存在则添加
	keyNames := make([]string, 0, keywordsCnt)

	// 新增关键词数量
	for _, kd := range req.KeywordList {
		_keName := strings.TrimSpace(kd.KeyName)
		keyNames = append(keyNames, _keName)
	}

	keywords := []models.SeoKeywords{}
	err = seo.DB().Model(&models.SeoKeywords{}).Where("key_name in ?", keyNames).Find(&keywords).Error
	if err != nil {
		return codes.FAILURE, err
	}

	noExistKeywords := []string{}
	if len(keywords) > 0 {
		keyNameMap := make(map[string]bool)
		for _, keyword := range keywords {
			keyNameMap[keyword.KeyName] = true
		}

		for _, keyname := range keyNames {
			if _, ok := keyNameMap[keyname]; !ok {
				noExistKeywords = append(noExistKeywords, keyname)
			}
		}
	} else {
		noExistKeywords = keyNames
	}

	if len(noExistKeywords) > 0 {
		// 添加关键词
		if addKeyWordsEr := SerSeoKeywords.UpsertSeoKeyword(noExistKeywords); addKeyWordsEr != nil {
			return codes.FAILURE, addKeyWordsEr
		}

		// 获取关键词Ids
		keywords, err = SerSeoKeywords.ListByKeyNames(keyNames)
		if err != nil {
			return codes.FAILURE, err
		}

	}
	keywordIds := map[string]int{}
	for _, keyword := range keywords {
		keywordIds[keyword.KeyName] = keyword.Id
	}

	for i, kd := range req.KeywordList {
		if _, ok := keywordIds[kd.KeyName]; !ok {
			return codes.FAILURE, errors.New("the keyword " + kd.KeyName + " does not exist")
		}
		req.KeywordList[i].KeywordId = keywordIds[kd.KeyName]
	}

	// 查找域名，不存在则添加
	domainNames := make([]string, 0, domainCnt)
	for _, d := range req.DomainList {
		name := strings.TrimSpace(d.DomainName)
		domainNames = append(domainNames, name)
	}
	domains := []models.SeoDomains{}
	err = seo.DB().Model(&models.SeoDomains{}).Where("domain_name in ?", domainNames).Find(&domains).Error
	if err != nil {
		return codes.FAILURE, err
	}

	noExistDomains := []string{}
	if len(domains) > 0 {
		domainNameMap := make(map[string]bool)
		for _, domain := range domains {
			domainNameMap[domain.DomainName] = true
		}

		for _, name := range domainNames {
			if _, ok := domainNameMap[name]; !ok {
				noExistDomains = append(noExistDomains, name)
			}
		}
	} else {
		noExistDomains = domainNames
	}

	if len(noExistDomains) > 0 {
		// 添加域名
		if addDomainsEr := SerSeoDomains.UpsertSeoDomain(noExistDomains); addDomainsEr != nil {
			return codes.FAILURE, addDomainsEr
		}
		err = seo.DB().Model(&models.SeoDomains{}).Where("domain_name in ?", domainNames).Find(&domains).Error
		if err != nil {
			return codes.FAILURE, err
		}
	}
	domainIds := map[string]int{}
	for _, domain := range domains {
		domainIds[domain.DomainName] = domain.Id
	}

	for i, kd := range req.DomainList {
		if _, ok := domainIds[kd.DomainName]; !ok {
			return codes.FAILURE, errors.New("the domain " + kd.DomainName + " does not exist")
		}
		req.DomainList[i].DomainId = domainIds[kd.DomainName]
	}

	// handle.
	proOperationErr := seo.DB().Transaction(func(tx *gorm.DB) error {
		// 添加项目
		projectId, addProErr := seo.addSeoProjectInertId(tx, req)

		if addProErr != nil {
			if utils.IsErrDuplicatedKey(addProErr) {
				return errors.New("the project name already exists")
			}
			return errors.New("add project error")
		}

		// 添加关键词
		if err := SerSeoProjectKeywords.AddProjectKeywords(tx, req.UserId, projectId, req.KeywordList); err != nil {
			slog.Error("添加用户域名发生错误", "err", err)
			return err
		}

		// 添加用户域名
		if err := SerSeoUserDomains.AddUserDomain(tx, req.UserId, projectId, req.DomainList); err != nil {
			slog.Error("添加用户域名发生错误", "err", err)
			return err
		}

		// // 添加任务
		// addTaskErr := SerSeoProjectTask.AddCronTask(tx, req.UserId, projectId, req.EngineTypes, req.CronTasks, keywordIds)
		// if addTaskErr != nil {
		// 	return addTaskErr
		// }

		return nil
	})

	if proOperationErr != nil {
		slog.Error("添加项目发生错误", "err", proOperationErr)
		return codes.FAILURE, proOperationErr
	}

	// todo 默认执行抓取数据处理...

	return codes.SUCCESS, nil
}

// ChangeProStateByUserIdAndProId 启动或停止项目
func (seo *SeoProjectService) ChangeProStateByUserIdAndProId(userId int64, projectId, state int) (err error) {
	var proj models.SeoProject

	err = seo.DB().Model(&models.SeoProject{}).Where("id = ? and user_id = ?", projectId, userId).First(&proj).Error
	if err != nil {
		return
	}

	// 启动项目
	if state == models.STATE_TO_NORMAL {
		// if proj.LifeTime.Before(time.Now()) {
		// 	return errors.New("this project has been completed and cannot be started again")
		// }

		// 获取用户账户信息
		account, accountErr := accSer.SerAccount.GetAccount(int(userId))
		if accountErr != nil {
			return accountErr
		}

		// 判断点数
		if account.Amount <= 0 {
			return errors.New("you don't have enough points, please recharge")
		}

		// 获取项目预消耗点数
		keywordsCnt, _ := SerSeoProjectTask.GetTaskCountByProIdAndUserId(int(userId), projectId)
		domainCnt, _ := SerSeoUserDomains.GetDomainCountByProIdAndUserId(int(userId), projectId)
		engineCnt := int64(len(proj.EngineTypes))

		// 需要扣减的点数 计算方式：域名x关键词x搜索引擎x2
		score := domainCnt * keywordsCnt * engineCnt * int64(config.Ext.SerpAPI.ChargeBase.BaseTwo)

		// 判断账户点数
		if account.Amount < score {
			return errors.New("you don't have enough points, please recharge")
		}

		// 启动项目
		err = seo.DB().Model(&models.SeoProject{}).Where("id = ? and user_id = ?", projectId, userId).
			UpdateColumns(map[string]any{
				"state":      models.STATE_TO_NORMAL,
				"updated_at": time.Now(),
			}).Error
		if err != nil {
			return
		}
	} else {
		// 停止项目
		err = seo.DB().Model(&models.SeoProject{}).Where("id = ? and user_id = ?", projectId, userId).
			UpdateColumns(map[string]any{
				"state":      models.STATE_TO_STOP,
				"updated_at": time.Now(),
			}).Error
		if err != nil {
			return
		}
	}

	return
}

func (seo *SeoProjectService) GetOneById(userId, proId int) (pro models.SeoProject, err error) {
	err = seo.DB().Model(&models.SeoProject{}).
		Where("id = ? and user_id = ? and deleted_at is null", proId, userId).
		First(&pro).Error
	return
}

// DelProById 删除项目
func (seo *SeoProjectService) DelProById(userId, proId int) (err error) {
	var pro models.SeoProject
	err = seo.DB().Model(&models.SeoProject{}).Where("id = ? and user_id = ?", proId, userId).First(&pro).Error
	if err != nil {
		slog.Error("删除项目失败", "error", err)
		return
	}

	// 运行中的项目不允许删除
	if pro.State == models.STATE_TO_NORMAL {
		return errors.New("project running. deletion is not allowed")
	}

	// 删除处理
	err = seo.DB().Transaction(func(tx *gorm.DB) error {
		// 删除项目的所有任务
		if delTaskErr := SerSeoProjectTask.DeleteProjectTasks(tx, userId, proId); delTaskErr != nil {
			return delTaskErr
		}

		// 更新项目为删除状态
		if orjErr := tx.Where("id = ? and user_id = ?", proId, userId).
			Delete(&models.SeoProject{}).Error; orjErr != nil {
			return orjErr
		}

		// 更新用户域名表对应项目为删除状态
		if doErr := tx.Where("user_id = ? and project_id = ?", userId, proId).Delete(&models.SeoUserDomains{}).Error; doErr != nil {
			return doErr
		}

		// 更新项目关键词表对应项目为删除状态
		if doErr := tx.Where("user_id = ? and project_id = ?", userId, proId).Delete(&models.SeoProjectKeywords{}).Error; doErr != nil {
			return doErr
		}

		return nil
	})

	if err != nil {
		slog.Error("删除项目失败", "err", err)
		return errors.New("delete failed")
	}

	return nil
}

// 添加SEO项目，并返回新项目ID
func (seo *SeoProjectService) addSeoProjectInertId(tx *gorm.DB, req dto.SeoProjectDto) (int, error) {

	// 校验定时任务
	cronExpr, err := cron.NewCronTask(req.CronTasks.SchType, req.CronTasks.Days, req.CronTasks.Hour, req.CronTasks.Minute).GeneratedCronExpr()
	if err != nil {
		return codes.FAILURE, err
	}
	if cronExpr == "" {
		return codes.FAILURE, errors.New("the cron expression is invalid")
	}

	nextRunAt := time.Now()

	if req.Exec == 0 {
		// 更新明日的执行时间
		nextRunAt, err = cron.NextRunTime(now.EndOfDay(), cronExpr)
		if err != nil {
			return 0, err
		}
	}

	project := models.SeoProject{
		UserId:      req.UserId,
		ProName:     strings.TrimSpace(req.ProName),
		KeywordNum:  len(req.KeywordList),
		DomainNum:   len(req.DomainList),
		EngineTypes: req.EngineTypes,
		DeviceTypes: req.DeviceTypes,
		LifeTime:    time.Unix(req.LifeTime, 0),
		SchType:     req.CronTasks.SchType,
		Days:        req.CronTasks.Days,
		Hour:        req.CronTasks.Hour,
		Minute:      req.CronTasks.Minute,
		CronExpr:    cronExpr,
		NextRunAt:   nextRunAt,
		State:       models.STATE_TO_NORMAL,
	}

	err = tx.Model(&models.SeoProject{}).Create(&project).Error
	if err != nil {
		return 0, err
	}

	return project.Id, nil
}
