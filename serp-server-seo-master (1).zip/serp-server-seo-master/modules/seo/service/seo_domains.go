package service

import (
	"dilu/modules/seo/models"
	"strings"

	"github.com/baowk/dilu-core/core/base"
	"gorm.io/gorm/clause"
)

type SeoDomainsService struct {
	*base.BaseService
}

var SerSeoDomains = SeoDomainsService{
	base.NewService("seo"),
}

func (k *SeoDomainsService) UpsertSeoDomain(domains []string) (err error) {

	list := make([]models.SeoDomains, 0, len(domains))

	for _, domain := range domains {
		list = append(list, models.SeoDomains{
			DomainName: strings.TrimSpace(domain),
		})
	}

	err = k.DB().Model(&models.SeoDomains{}).Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "domain_name"}},
		DoNothing: true,
	}).Create(&list).Error
	return
}
