package service

import (
	"dilu/modules/seo/models"
	"dilu/modules/seo/service/dto"
	"log/slog"

	"github.com/baowk/dilu-core/core/base"
	"gorm.io/gorm"
)

type SeoProjectKeywordsService struct {
	*base.BaseService
}

var SerSeoProjectKeywords = SeoProjectKeywordsService{
	base.NewService("seo"),
}

func (d *SeoProjectKeywordsService) AddProjectKeywords(tx *gorm.DB, userId, projectId int, keywords []dto.SeoProjectKeywordsDto) (err error) {
	// 待添加的关键词
	var add []models.SeoProjectKeywords
	for _, keyword := range keywords {
		if keyword.Id > 0 {
			continue
		}
		add = append(add, models.SeoProjectKeywords{
			UserId:    userId,
			ProjectId: projectId,
			KeywordId: keyword.KeywordId,
			KeyName:   keyword.KeyName,
			IsActive:  1, // 默认启用
		})
	}
	if len(add) <= 0 {
		return
	}

	if err = tx.Model(&models.SeoProjectKeywords{}).CreateInBatches(add, 1000).Error; err != nil {
		slog.Error("批量添加关键词失败", "err", err)
		return
	}

	return
}
