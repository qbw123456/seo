package service

import (
	"dilu/modules/seo/models"
	"strings"
	"time"

	"github.com/baowk/dilu-core/core/base"
	"gorm.io/gorm/clause"
)

type SeoKeywordsService struct {
	*base.BaseService
}

var SerSeoKeywords = SeoKeywordsService{
	base.NewService("seo"),
}

// UpsertSeoKeyword 批量操作关键词（不存在新增、存在更新）
func (k *SeoKeywordsService) UpsertSeoKeyword(keywords []string) (err error) {
	now := time.Now()

	list := make([]models.SeoKeywords, 0, len(keywords))

	for _, key := range keywords {
		list = append(list, models.SeoKeywords{
			KeyName:   strings.TrimSpace(key),
			CreatedAt: now,
			State:     models.KEY_WORDS_STATE_TO_NORMAL,
		})
	}

	err = k.DB().Model(&models.SeoKeywords{}).Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "key_name"}},
		DoNothing: true,
	}).Create(&list).Error
	return
}

// GetKeyIdsByKeyNames 通过关键词获取关键词ID集
func (k *SeoKeywordsService) ListByKeyNames(keywords []string) (list []models.SeoKeywords, err error) {
	err = k.DB().Model(&models.SeoKeywords{}).Where("key_name in ?", keywords).Find(&list).Error
	return
}

// GetKeyIdsByKeyNames 通过关键词获取关键词ID集
func (k *SeoKeywordsService) GetKeyIdsByKeyNames(keywords []string) (ids []int, err error) {
	err = k.DB().Model(&models.SeoKeywords{}).Where("key_name in ?", keywords).Pluck("id", &ids).Error
	return
}

func (k *SeoKeywordsService) GetOneById(keywordId int) (keyword models.SeoKeywords, err error) {
	err = k.DB().Where("id = ? and state = ?", keywordId, models.KEY_WORDS_STATE_TO_NORMAL).First(&keyword).Error
	return
}
