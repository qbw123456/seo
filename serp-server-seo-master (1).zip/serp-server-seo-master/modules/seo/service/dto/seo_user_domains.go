package dto

import (
	"dilu/modules/seo/models"

	"github.com/baowk/dilu-core/core/base"
)

type SeoUserDomainsGetPageReq struct {
	base.ReqPage `query:"-"`
	SortOrder    string `json:"-" query:"type:order;column:id"`
	UserId       int    `json:"userId" query:"type:eq;column:user_id"`       //用户ID
	ProjectId    int    `json:"projectId" query:"type:eq;column:project_id"` //项目ID
}

func (SeoUserDomainsGetPageReq) TableName() string {
	return models.TBSeoUserDomains
}

// SEO用户域名配置表
type SeoUserDomainsDto struct {
	Id         int    `json:"id"`         //主键
	ProjectId  int    `json:"projectId"`  //项目ID
	DomainId   int    `json:"domainId"`   //域名ID
	DomainName string `json:"domainName"` //域名
	DomainType int    `json:"domainType"` // 域名类型
	IsActive   int8   `json:"isActive"`   //是否匹配；0：否；1：是
}
