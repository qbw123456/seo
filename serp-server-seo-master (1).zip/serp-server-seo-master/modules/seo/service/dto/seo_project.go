package dto

import (
	"dilu/common/utils"
	"dilu/modules/seo/models"
	"strings"
	"time"

	"github.com/baowk/dilu-core/core/base"
	"gorm.io/datatypes"
)

type SeoProjectGetPageReq struct {
	base.ReqPage `query:"-"`
	UserId       int    `json:"userId" query:"type:eq;column:user_id"`       //用户ID
	ProjectId    int    `json:"projectId" query:"type:eq;column:project_id"` //项目ID
	SortOrder    string `json:"-" query:"type:order;column:id"`
	ProName      string `json:"proName" form:"proName" query:"type:like;column:pro_name"`
	State        int    `json:"state" form:"state" query:"type:eq;column:state"`
}

type SeoProjectRes struct {
	Id          int       `json:"id"`
	ProName     string    `json:"proName"`     // 项目名称
	EnginTypes  []string  `json:"enginType"`   // 搜索引擎类型；google，bing，baidu
	DeviceTypes []string  `json:"deviceType"`  // 设备类型；pc，mobile
	DomainCont  int64     `json:"domainCont"`  // 域名数
	KeywordCont int64     `json:"keywordCont"` // 关键词数
	CronType    string    `json:"cronType"`    // 定时任务执行频率
	LifeTime    time.Time `json:"endTime"`     // 项目生命周期结束时间
	StartTime   time.Time `json:"startTime"`   // 项目开始时间
}

func (SeoProjectGetPageReq) TableName() string {
	return models.TBSeoProject
}

// SeoProjectDto SEO项目配置表
type SeoProjectDto struct {
	Id             int                         `json:"id"`
	Exec           int                         `json:"exec"`             // 是否立即执行
	UserId         int                         `json:"userId,omitempty"` // 用户ID
	ProName        string                      `json:"proName"`          // 项目名称
	EngineTypes    datatypes.JSONSlice[string] `json:"engineTypes"`      // 搜索引擎类型；google，bing，baidu
	DeviceTypes    datatypes.JSONSlice[string] `json:"deviceTypes"`      // 设备类型；pc，mobile
	DomainList     []SeoUserDomainsDto         `json:"domainList"`       // 域名列表
	KeywordList    []SeoProjectKeywordsDto     `json:"keywordList"`      // 关键词列表
	LifeTime       int64                       `json:"lifeTime"`         // 项目生命周期
	CronTasks      SeoTaskCron                 `json:"cronTasks"`        // 定时任务参数
	PendingTasks   int64                       `json:"pendingTasks"`     // 待执行任务数
	CompletedTasks int64                       `json:"completedTasks"`   // 已完成任务数
}

func (s *SeoProjectDto) ValidKeywordList() bool {
	for i, kd := range s.KeywordList {
		s.KeywordList[i].KeyName = strings.TrimSpace(kd.KeyName)
		if s.KeywordList[i].KeyName == "" {
			return false
		}
		if len(s.KeywordList[i].KeyName) > 30 {
			return false
		}
		if kd.IsActive != 0 && kd.IsActive != 1 {
			return false
		}
	}
	return true
}

func (s SeoProjectDto) ValidDomainList() bool {
	for _, domain := range s.DomainList {
		if domain.DomainName == "" {
			return false
		}
		if domain.IsActive != 0 && domain.IsActive != 1 {
			return false
		}
		if !utils.IsValidDomain(domain.DomainName) {
			return false
		}
	}
	return true
}

func (s SeoProjectDto) ValidEnginTypes() bool {
	for _, engin := range s.EngineTypes {
		if engin != "google" && engin != "bing" && engin != "baidu" {
			return false
		}
	}
	return true
}

func (s SeoProjectDto) ValidDeviceTypes() bool {
	for _, device := range s.DeviceTypes {
		if device != "pc" && device != "mobile" {
			return false
		}
	}
	return true
}

type SeoTaskCron struct {
	SchType string `json:"schType"`          // 执行周期类型 hourly，daily，weekly，monthly
	Days    string `json:"days,omitempty"`   // 执行周期值，例：1,4,5,9
	Hour    int    `json:"hour,omitempty"`   // 具体执行小时
	Minute  int    `json:"minute,omitempty"` // 具体执行分钟
}
