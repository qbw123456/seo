package dto

import (
    "github.com/baowk/dilu-core/core/base"
    "dilu/modules/seo/models"
)

type SeoResultsGetPageReq struct {
	base.ReqPage `query:"-"`
    SortOrder  string `json:"-" query:"type:order;column:id"`
    
    
}

func (SeoResultsGetPageReq) TableName() string {
	return models.TBSeoResults
}


//SEO数据结果表
type SeoResultsDto struct {
    
    Id int `json:"id"` //主键
    EngineName string `json:"engineName"` //引擎名称；google bing baidu ... 
    RankPosition int `json:"rankPosition"` //排名位置 
    KeywordName string `json:"keywordName"` //关键词名称 
    KeywordId int `json:"keywordId"` //关键词表ID 
    Title string `json:"title"` //名称 
    Link string `json:"link"` //结果域名1 
    DisplayedLink string `json:"displayedLink"` //结果域名2 
}