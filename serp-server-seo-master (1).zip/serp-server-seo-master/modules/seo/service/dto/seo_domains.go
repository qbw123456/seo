package dto

import (
    "github.com/baowk/dilu-core/core/base"
    "dilu/modules/seo/models"
)

type SeoDomainsGetPageReq struct {
	base.ReqPage `query:"-"`
    SortOrder  string `json:"-" query:"type:order;column:id"`
    
    
}

func (SeoDomainsGetPageReq) TableName() string {
	return models.TBSeoDomains
}


//SEO域名表
type SeoDomainsDto struct {
    
    Id int `json:"id"` //主键
    DomainName string `json:"domainName"` //域名 
}