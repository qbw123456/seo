package dto

import (
    "time"
    "github.com/baowk/dilu-core/core/base"
    "dilu/modules/seo/models"
)

type SeoTaskExecLogGetPageReq struct {
	base.ReqPage `query:"-"`
    SortOrder  string `json:"-" query:"type:order;column:id"`
    
    
}

func (SeoTaskExecLogGetPageReq) TableName() string {
	return models.TBSeoTaskExecLog
}


//SEO项目任务执行记录表
type SeoTaskExecLogDto struct {
    
    Id int `json:"id"` //主键
    UserId int `json:"userId"` //用户ID 
    ProjectId int `json:"projectId"` //项目ID 
    TaskId int `json:"taskId"` //任务ID 
    StartTime time.Time `json:"startTime"` //任务开始时间 
    FinishedTime time.Time `json:"finishedTime"` //任务完成时间 
    State int8 `json:"state"` //状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束 
    TotalKeyworks int `json:"totalKeyworks"` //总关键词数 
    ProcessedKeyworks int `json:"processedKeyworks"` //已执行关键词数 
    SuccessCount int `json:"successCount"` //执行成功数 
    FaildCount int `json:"faildCount"` //执行失败数 
    ApiCount uint `json:"apiCount"` //api调用数 
    ErrMsg string `json:"errMsg"` //错误信息 
}