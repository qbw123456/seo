package dto

import (
	"encoding/json"
	"testing"
)

func TestJSONMarshal(t *testing.T) {
	domain := &SeoProjectDto{}

	jsonData, err := json.Marshal(domain)
	if err != nil {
		t.Errorf("JSON marshal failed: %v", err)
	}
	t.Log(string(jsonData))
}
