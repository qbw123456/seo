package dto

import (
	"dilu/common/utils"
	"dilu/modules/seo/models"

	"github.com/baowk/dilu-core/core/base"
)

type SeoProjectKeywordsGetPageReq struct {
	base.ReqPage `query:"-"`
	SortOrder    string `json:"-" query:"type:order;column:id"`
	UserId       int    `json:"userId" query:"type:eq;column:user_id"`       //用户ID
	ProjectId    int    `json:"projectId" query:"type:eq;column:project_id"` //项目ID
	KeyName      string `json:"keyName" query:"type:like;column:key_name"`   //关键词
}

func (SeoProjectKeywordsGetPageReq) TableName() string {
	return models.TBSeoProjectKeywords
}

// SEO用户域名配置表
type SeoProjectKeywordsDto struct {
	Id        uint   `json:"id"`        //主键
	ProjectId int    `json:"projectId"` //项目ID
	KeywordId int    `json:"keywordId"` //
	KeyName   string `json:"keyName"`   //关键词
	IsActive  int8   `json:"isActive"`  //是否启用；0：否；1：是
}

type FirstLastRankReq struct {
	base.ReqPage `query:"-"`
	SortOrder    string `json:"-" query:"type:order;column:id"`
	UserId       int    `json:"userId" query:"type:eq;column:user_id"`       //用户ID
	ProjectId    int    `json:"projectId" query:"type:eq;column:project_id"` //项目ID
	KeyName      string `json:"keyName" query:"type:like;column:key_name"`   //关键词
	EngineType   string `json:"engineType"`                                  //搜索引擎类型
	StartDate    string `json:"startDate"`                                   //开始日期
	EndDate      string `json:"endDate"`                                     //结束日期
}

func (FirstLastRankReq) TableName() string {
	return models.TBSeoProjectKeywords
}

type FirstLastRankRes struct {
	Id        uint                `json:"id"`        //主键
	ProjectId int                 `json:"projectId"` //项目ID
	KeywordId int                 `json:"keywordId"` //
	KeyName   string              `json:"keyName"`   //关键词
	IsActive  int8                `json:"isActive"`  //是否启用；0：否；1：是
	Domains   []FirstLastRankItem `json:"domains"`   //域名
}

type FirstLastRankItem struct {
	ProjectId  int             `json:"projectId"`  //项目ID
	KeywordId  int             `json:"keywordId"`  //关键词ID
	KeyName    string          `json:"keyName"`    //关键词
	DomainId   int             `json:"domainId"`   //域名ID
	DomainName string          `json:"domainName"` //域名
	FirstDate  utils.LocalDate `json:"firstDate"`  //第一天
	FirstRank  int             `json:"firstRank"`  //第一天排名
	LastDate   utils.LocalDate `json:"lastDate"`   //最后一天
	LastRank   int             `json:"lastRank"`   //最后一天排名
	RankDirr   int             `json:"rankDiff"`   //位差
}
