package dto

import (
	"dilu/modules/seo/models"
	"time"

	"github.com/baowk/dilu-core/core/base"
)

type SeoProjectTaskGetPageReq struct {
	base.ReqPage `query:"-"`
	SortOrder    string `json:"-" query:"type:order;column:id"`
	UserId       int    `json:"userId" query:"type:eq;column:user_id"`       //用户ID
	ProjectId    int    `json:"projectId" query:"type:eq;column:project_id"` //项目ID
}

func (SeoProjectTaskGetPageReq) TableName() string {
	return models.TBSeoProjectTask
}

// SEO项目任务表
type SeoProjectTaskDto struct {
	Id         int       `json:"id"`         //主键
	UserId     int       `json:"userId"`     //用户ID
	ProjectId  int       `json:"projectId"`  //SEO 项目ID
	KeywordId  int       `json:"keywordId"`  //关键词ID
	EngineType string    `json:"engineType"` //搜索引擎类型；google，bing，baidu
	State      int8      `json:"state"`      //状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束
	NextRunAt  time.Time `json:"nextRunAt"`  //下次执行时间
}
