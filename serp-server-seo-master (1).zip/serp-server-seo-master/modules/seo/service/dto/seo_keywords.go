package dto

import (
	"dilu/modules/seo/models"

	"github.com/baowk/dilu-core/core/base"
)

type SeoKeywordsGetPageReq struct {
	base.ReqPage `query:"-"`
	SortOrder    string `json:"-" query:"type:order;column:id"`
}

func (SeoKeywordsGetPageReq) TableName() string {
	return models.TBSeoKeywords
}

// SEO关键词表
type SeoKeywordsDto struct {
	Id      int    `json:"id"`      //主键
	KeyName string `json:"keyName"` //关键词名称
	State   int8   `json:"state"`   //状态：0：禁用；1：正常
}
