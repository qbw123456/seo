package dto

import (
	"dilu/common/utils"
	"dilu/modules/seo/models"
	"time"

	"github.com/baowk/dilu-core/core/base"
)

type SeoUserRankingHistoryGetPageReq struct {
	base.ReqPage `query:"-"`
	SortOrder    string `json:"-" form:"sortOrder" query:"type:order;column:id"`
	UserId       int    `json:"userId" form:"userId" query:"type:eq;column:user_id"`          //用户ID
	ProjectId    int    `json:"projectId" form:"projectId" query:"type:eq;column:project_id"` //项目ID
	DomainId     int    `json:"domainId" form:"domainId" query:"type:eq;column:domain_id"`    //域名ID
	KeywordName  string `json:"keywordName" form:"keywordName" query:"-"`                     //关键词名称
	EngineType   string `json:"engineType" form:"engineType" query:"-"`                       //搜索引擎类型
}

func (SeoUserRankingHistoryGetPageReq) TableName() string {
	return models.TBSeoUserRankingHistory
}

// SEO用户排名数据变化记录
type SeoUserRankingHistoryDto struct {
	Id           int       `json:"id"`           //主键
	UserId       int       `json:"userId"`       //用户ID
	ProjectId    int       `json:"projectId"`    //SEO 项目ID
	ProjectName  string    `json:"projectName"`  //SEO 项目名称
	TaskId       int       `json:"taskId"`       //任务ID
	KeywordId    int       `json:"keywordId"`    //关键词表ID
	KeywordName  string    `json:"keywordName"`  //关键词名称
	DomainId     int       `json:"domainId"`     //域名表ID
	DomainName   string    `json:"domainName"`   //域名名称
	EngineType   string    `json:"engineType"`   //搜索引擎类型
	RankPosition int       `json:"rankPosition"` //排名位置
	PreRanking   int       `json:"preRanking"`   //上次排名位置
	RankChange   int       `json:"rankChange"`   //排名变化
	CreatedAt    time.Time `json:"createdAt"`    //创建时间
}

type DistributionReq struct {
	UserId     int    `json:"userId"`     //用户ID
	ProjectId  int    `json:"projectId"`  //项目ID
	DomainId   int    `json:"domainId"`   //域名ID
	EngineType string `json:"engineType"` //搜索引擎类型
	StartDate  string `json:"startDate"`  //开始日期
	EndDate    string `json:"endDate"`    //结束日期
}

type DistributionRes struct {
	CreatedDate utils.LocalDate `json:"createdDate"` //创建日期
	R1          int             `json:"r1"`          //排名1-3数量
	R2          int             `json:"r2"`          //排名4-10数量
	R3          int             `json:"r3"`          //排名11-20数量
	R4          int             `json:"r4"`          //排名21-30数量
	R5          int             `json:"r5"`          //排名31-50数量
	R6          int             `json:"r6"`          //排名51-100数量
}
