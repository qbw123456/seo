package service

import (
	"dilu/modules/seo/models"
	"time"

	"gorm.io/gorm"

	"github.com/baowk/dilu-core/core/base"
	"gorm.io/gorm/clause"
)

type SeoResultsService struct {
	*base.BaseService
}

var SerSeoResults = SeoResultsService{
	base.NewService("seo"),
}

// GetResultsByKIdAndEngine 获取当天指定关键词和引擎的结果
// keywordId 关键词ID
// engineName 引擎名称
func (s *SeoResultsService) GetResultsByKIdAndEngine(keywordId int, engineName string) (results []models.SeoResults, err error) {
	currentDate := time.Now().Format(time.DateOnly)

	err = s.DB().Model(&models.SeoResults{}).
		Where("created_date = ? and keyword_id = ? and engine_type = ?", currentDate, keywordId, engineName).
		Order("rank_position asc").
		Limit(1000).Find(&results).Error
	return
}

// SaveResults 保存结果
func (s *SeoResultsService) SaveResults(results []models.SeoResults) error {
	return s.DB().Transaction(func(tx *gorm.DB) error {
		return tx.Clauses(clause.OnConflict{
			Columns:   []clause.Column{{Name: "created_date"}, {Name: "keyword_id"}, {Name: "engine_name"}, {Name: "rank_position"}, {Name: "current"}},
			DoUpdates: clause.AssignmentColumns([]string{"title", "rank_position", "link", "displayed_link", "current", "updated_at"}),
		}).CreateInBatches(results, len(results)).Error
	})
}
