package service

import (
	"dilu/common/config"
	"dilu/modules/seo/models"
	"dilu/modules/seo/service/dto"
	"log/slog"
	"strings"
	"time"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"

	"github.com/baowk/dilu-core/core/base"
)

type SeoUserRankingHistoryService struct {
	*base.BaseService
}

var SerSeoUserRankingHistory = SeoUserRankingHistoryService{
	base.NewService("seo"),
}

func (s *SeoUserRankingHistoryService) QueryPage(req dto.SeoUserRankingHistoryGetPageReq, models any, total *int64, limit, offset int) error {

	db := s.DB().Table("seo_user_ranking_history").Select("seo_user_ranking_history.*, seo_project.pro_name AS project_name, seo_keywords.key_name AS keyword_name, seo_domains.domain_name AS domain_name, seo_project_task.engine_type AS engine_type").
		Joins("left join seo_project on (seo_project.id=seo_user_ranking_history.project_id)").
		Joins("left join seo_keywords on (seo_keywords.id=seo_user_ranking_history.keyword_id)").
		Joins("left join seo_domains on (seo_domains.id=seo_user_ranking_history.domain_id)").
		Joins("left join seo_project_task on (seo_project_task.id=seo_user_ranking_history.task_id)")

	if req.KeywordName != "" {
		db = db.Where("seo_keywords.key_name LIKE ?", "%"+req.KeywordName+"%")
	}
	if req.EngineType != "" {
		db = db.Where("seo_project_task.engine_type = ?", req.EngineType)
	}
	return db.Scopes(s.MakeCondition(req)).Limit(limit).Offset(offset).
		Find(models).Limit(-1).Offset(-1).Count(total).Error
}

// CreateRankingHistories 创建排名历史记录
// userId 用户ID
// taskId 任务ID
// keywordId 关键词ID
// results 搜索结果
// domains 用户配置的域名
func (s *SeoUserRankingHistoryService) CreateRankingHistories(userId, taskId, keywordId int, results []models.SeoResults, domains []models.SeoUserDomains) ([]models.SeoUserRankingHistory, error) {
	var rankHistories []models.SeoUserRankingHistory
	var matchedCount int

	for _, result := range results {
		for _, domain := range domains {
			if s.matchDomain(result.Link, domain.DomainName, domain.DomainType) || s.matchDomain(result.DisplayedLink, domain.DomainName, domain.DomainType) {
				// 获取上一次的排名
				var preRanking int

				s.DB().Model(&models.SeoUserRankingHistory{}).
					Where("user_id = ? and task_id = ? and keyword_id = ? and domain_id = ?", userId, taskId, keywordId, domain.Id).
					Order("id desc").
					Pluck("rank_position", &preRanking)

				// 计算排名变化
				rankChange := 0
				if preRanking > 0 {
					rankChange = preRanking - result.RankPosition
				}

				// 构建排名历史记录
				rankHistory := models.SeoUserRankingHistory{
					UserId:       userId,
					TaskId:       taskId,
					KeywordId:    keywordId,
					DomainId:     domain.Id,
					RankPosition: result.RankPosition,
					PreRanking:   preRanking,
					RankChange:   rankChange,
					CreatedAt:    time.Now(),
				}
				rankHistories = append(rankHistories, rankHistory)
				matchedCount++
			}
		}
	}

	// 写入匹配的结果到seo_user_ranking_history表
	if len(rankHistories) > 0 {
		if err := s.DB().CreateInBatches(rankHistories, 100).Error; err != nil {
			return nil, err
		}
	}

	return rankHistories, nil
}

// GetRankingHistoriesWithTx 获取排名历史记录
func (s *SeoUserRankingHistoryService) GetRankingHistoriesWithTx(tx *gorm.DB, userId, taskId, keywordId int, engineType string, results []models.SeoResults, domains []models.SeoUserDomains) ([]models.SeoUserRankingHistory, error) {
	var rankHistories []models.SeoUserRankingHistory

	_now := time.Now()
	m := map[int]bool{}
	for _, result := range results {
		for _, domain := range domains {
			slog.Debug("matchDomain", "link", result.Link, "domainName", domain.DomainName, "domainType", domain.DomainType)
			if s.matchDomain(result.Link, domain.DomainName, domain.DomainType) || s.matchDomain(result.DisplayedLink, domain.DomainName, domain.DomainType) {
				// 获取上一次的排名
				var preRanking int

				tx.Model(&models.SeoUserRankingHistory{}).
					Where("user_id = ? and project_id = ? and keyword_id = ? and domain_id = ?", userId, domain.ProjectId, keywordId, domain.Id).
					Order("id desc").Limit(1).
					Pluck("rank_position", &preRanking)

				// 计算排名变化
				rankChange := 0

				if preRanking != 0 {
					slog.Debug("获取上一次的排名", "userId", userId, "keywordId", keywordId, "domainId", domain.Id, "preRanking", preRanking)
					// 如果最新排名大于历史排名说明排名落后了，最新排名 - 历史排名 = 落后排名位置数
					if result.RankPosition > preRanking {
						rankChange = -(result.RankPosition - preRanking)

						//  如果最新排名小于历史排名说明排名靠前了，历史排名 - 最新排名 = 靠前排名位置数
					} else if result.RankPosition < preRanking {
						rankChange = +(preRanking - result.RankPosition)
					}
				}

				slog.Debug("amount", "userId", userId, "keywordId", keywordId, "domainId", domain.Id, "amount", config.Ext.SerpAPI.ChargeBase.BaseTwo)
				// 构建排名历史记录
				rankHistory := models.SeoUserRankingHistory{
					UserId:       userId,
					ProjectId:    domain.ProjectId,
					TaskId:       taskId,
					KeywordId:    keywordId,
					DomainId:     domain.DomainId,
					EngineType:   engineType,
					RankPosition: result.RankPosition,
					PreRanking:   preRanking,
					RankChange:   rankChange,
					Amount:       config.Ext.SerpAPI.ChargeBase.BaseTwo,
					CreatedAt:    _now,
					CreatedDate:  _now,
				}
				rankHistories = append(rankHistories, rankHistory)
				m[domain.Id] = true
			}
		}
	}

	// 未获取到排名的域名生成一个排名历史记录
	for _, domain := range domains {
		if _, ok := m[domain.Id]; ok {
			continue
		}

		// 构建排名历史记录
		rankHistory := models.SeoUserRankingHistory{
			UserId:       userId,
			ProjectId:    domain.ProjectId,
			TaskId:       taskId,
			KeywordId:    keywordId,
			DomainId:     domain.Id,
			EngineType:   engineType,
			RankPosition: 0,
			PreRanking:   0,
			RankChange:   0,
			Amount:       config.Ext.SerpAPI.ChargeBase.BaseTwo,
			CreatedAt:    _now,
			CreatedDate:  _now,
		}
		rankHistories = append(rankHistories, rankHistory)
	}

	return rankHistories, nil
}

// CreateRankingHistoriesWith 添加用户排名数据
func (s *SeoUserRankingHistoryService) CreateRankingHistoriesWith(tx *gorm.DB, rankHistories []models.SeoUserRankingHistory) error {
	return tx.Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "project_id"}, {Name: "keyword_id"}, {Name: "domain_id"}, {Name: "created_date"}},
		UpdateAll: true,
	}).CreateInBatches(rankHistories, len(rankHistories)).Error
}

// matchDomain 检查URL是否匹配配置的域名
func (s *SeoUserRankingHistoryService) matchDomain(url, domain string, domainType int) bool {
	if domain == "" {
		return false
	}
	if domainType == 1 { // 根域 后缀匹配
		return strings.HasSuffix(url, domain)
	} else { // 完整匹配
		return url == domain || url == "https://"+domain || url == "http://"+domain
	}
}
