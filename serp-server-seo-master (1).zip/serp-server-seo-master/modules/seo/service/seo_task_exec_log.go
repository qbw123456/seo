package service

import (
	"dilu/modules/seo/models"
	"time"

	"github.com/baowk/dilu-core/core/base"
)

type SeoTaskExecLogService struct {
	*base.BaseService
}

var SerSeoTaskExecLog = SeoTaskExecLogService{
	base.NewService("seo"),
}

// CreateExecLog 创建任务执行日志
func (s *SeoTaskExecLogService) CreateExecLog(userId, projectId, taskId int, state int8, totalKeywords, processedKeywords, successCount, failCount int, apiCount uint, errMsg string) error {
	now := time.Now()
	finishedTime := now
	execLog := models.SeoTaskExecLog{
		UserId:            userId,
		ProjectId:         projectId,
		TaskId:            taskId,
		StartTime:         now,
		FinishedTime:      &finishedTime,
		State:             state,
		TotalKeyworks:     totalKeywords,
		ProcessedKeyworks: processedKeywords,
		SuccessCount:      successCount,
		FaildCount:        failCount,
		ApiCount:          apiCount,
		ErrMsg:            errMsg,
		CreatedAt:         now,
	}
	return s.DB().Create(&execLog).Error
}

// CreateRunningLog 创建任务开始执行的日志
func (s *SeoTaskExecLogService) CreateRunningLog(userId, projectId, taskId int) (time.Time, error) {
	now := time.Now()
	finishedTime := now // 用于后续更新
	execLog := models.SeoTaskExecLog{
		UserId:            userId,
		ProjectId:         projectId,
		TaskId:            taskId,
		StartTime:         now,
		FinishedTime:      nil,
		State:             models.TASK_TATE_TO_RUNNING,
		TotalKeyworks:     0,
		ProcessedKeyworks: 0,
		SuccessCount:      0,
		FaildCount:        0,
		ApiCount:          0,
		CreatedAt:         now,
	}
	err := s.DB().Create(&execLog).Error
	return finishedTime, err
}

// CreateFinishedLog 创建任务完成的日志
func (s *SeoTaskExecLogService) CreateFinishedLog(userId, projectId, taskId int, startTime time.Time, state int8, processedKeywords, successCount, failCount int, apiCount uint, errMsg string) error {
	now := time.Now()
	finishedTime := now
	execLog := models.SeoTaskExecLog{
		UserId:            userId,
		ProjectId:         projectId,
		TaskId:            taskId,
		StartTime:         startTime,
		FinishedTime:      &finishedTime, // 任务完成，设置完成时间
		State:             state,
		TotalKeyworks:     1,
		ProcessedKeyworks: processedKeywords,
		SuccessCount:      successCount,
		FaildCount:        failCount,
		ApiCount:          apiCount,
		ErrMsg:            errMsg,
		CreatedAt:         now,
	}
	return s.DB().Create(&execLog).Error
}

// CreateTaskErrorLog 创建任务错误日志
func (s *SeoTaskExecLogService) CreateTaskErrorLog(userId, projectId, taskId int, startTime time.Time, errMsg string) error {
	now := time.Now()
	finishedTime := now
	execLog := models.SeoTaskExecLog{
		UserId:            userId,
		ProjectId:         projectId,
		TaskId:            taskId,
		StartTime:         startTime,
		FinishedTime:      &finishedTime,
		State:             -1,
		TotalKeyworks:     0,
		ProcessedKeyworks: 0,
		SuccessCount:      0,
		FaildCount:        0,
		ApiCount:          0,
		ErrMsg:            errMsg,
		CreatedAt:         now,
	}
	return s.DB().Create(&execLog).Error
}

// CreateProjectStopLog 创建项目停止日志
func (s *SeoTaskExecLogService) CreateProjectStopLog(userId, projectId, taskCount int) error {
	now := time.Now()
	finishedTime := now
	execLog := models.SeoTaskExecLog{
		UserId:            userId,
		ProjectId:         projectId,
		TaskId:            0,
		StartTime:         now,
		FinishedTime:      &finishedTime,
		State:             models.TASK_TATE_TO_PAUSE,
		TotalKeyworks:     taskCount,
		ProcessedKeyworks: 0,
		SuccessCount:      0,
		FaildCount:        0,
		ApiCount:          0,
		ErrMsg:            "项目停止，任务暂停",
		CreatedAt:         now,
	}
	return s.DB().Create(&execLog).Error
}

// CreateProjectDeleteLog 创建项目删除日志
func (s *SeoTaskExecLogService) CreateProjectDeleteLog(userId, projectId, taskCount int) error {
	now := time.Now()
	finishedTime := now
	execLog := models.SeoTaskExecLog{
		UserId:            userId,
		ProjectId:         projectId,
		TaskId:            0,
		StartTime:         now,
		FinishedTime:      &finishedTime,
		State:             models.TASK_TATE_TO_STOP,
		TotalKeyworks:     taskCount,
		ProcessedKeyworks: 0,
		SuccessCount:      0,
		FaildCount:        0,
		ApiCount:          0,
		ErrMsg:            "项目删除，任务结束",
		CreatedAt:         now,
	}
	return s.DB().Create(&execLog).Error
}
