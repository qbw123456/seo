package service

import (
	"dilu/common/config"
	"dilu/common/third/serp_api"
	"dilu/common/utils"
	"dilu/common/utils/cron"
	"dilu/modules/account/service"
	"dilu/modules/scheduler/worker"
	"dilu/modules/seo/models"
	"errors"
	"log/slog"
	"time"

	"github.com/baowk/dilu-core/core/base"
	"github.com/dreamsxin/go-now"
	"gorm.io/gorm"
)

type SeoProjectTaskService struct {
	*base.BaseService
}

var SerSeoProjectTask = SeoProjectTaskService{
	base.NewService("seo"),
}

// AddCronTask 添加任务ID
// userId 用户ID
// proId 项目ID
// engine 浏览器引擎
// schType 执行周期：daily，weekly，monthly
// execTime 执行时间
// days 执行周期天数
func (t *SeoProjectTaskService) AddCronTask(project *models.SeoProject) error {

	// 计算明日执行时间
	if project.CronExpr == "" {
		return errors.New("the cron expression is invalid")
	}

	// 查询关键词
	var keywordIds []int
	if err := SerSeoProjectKeywords.DB().Model(&models.SeoProjectKeywords{}).
		Where("project_id = ?", project.Id).
		Pluck("keyword_id", &keywordIds).Error; err != nil {
		slog.Error("查询关键词失败", "project_id", project.Id, "error", err)
		return err
	}

	kLen := len(keywordIds) * len(project.EngineTypes)

	tasks := make([]models.SeoProjectTask, 0, kLen)

	for _, kId := range keywordIds {
		for _, engine := range project.EngineTypes {
			ret := models.SeoProjectTask{
				UserId:     project.UserId,
				ProjectId:  project.Id,
				KeywordId:  kId,
				EngineType: engine,
				DeviceType: "pc", // 暂时只支持 pc
				NextRunAt:  &project.NextRunAt,
			}
			tasks = append(tasks, ret)
		}
	}

	return t.DB().Transaction(func(tx *gorm.DB) error {
		// 更新明日的执行时间
		nextRunAt, err := cron.NextRunTime(now.EndOfDay(), project.CronExpr)
		if err != nil {
			return err
		}
		tx.Model(&models.SeoProject{}).Where("id = ?", project.Id).Updates(map[string]interface{}{
			"next_run_at":   nextRunAt,
			"pending_tasks": kLen,
		})
		return tx.Model(&models.SeoProjectTask{}).CreateInBatches(tasks, kLen).Error
	})
}

// DeleteCronTask 删除任务
func (t *SeoProjectTaskService) DeleteCronTask(tx *gorm.DB, userId, proId int, engines []string) error {
	return tx.Where("user_id = ? and project_id = ? AND engine_type NOT IN ?", userId, proId, engines).Delete(&models.SeoProjectTask{}).Error
}

// GetOneByProIdAndUserId 获取项目里的最新一个任务
func (t *SeoProjectTaskService) GetOneByProIdAndUserId(userId, proId int) (task models.SeoProjectTask, err error) {
	err = t.DB().Model(&models.SeoProjectTask{}).Where("user_id = ? and project_id = ?", userId, proId).Order("id desc").First(&task).Error
	return
}

// GetTaskCountByProIdAndUserId 获取项目下的任务数
func (t *SeoProjectTaskService) GetTaskCountByProIdAndUserId(userId, proId int) (total int64, err error) {
	err = t.DB().Model(&models.SeoProjectTask{}).Where("user_id = ? and project_id = ?", userId, proId).Count(&total).Error
	return
}

// GetEngineCountByProjectId 获取项目的搜索引擎数量
func (t *SeoProjectTaskService) GetEngineCountByProjectId(userId, projectId int) (int, error) {
	ret, retErr := SerSeoProject.GetOneById(userId, projectId)
	if retErr != nil {
		slog.Error("获取项目的搜索引擎数量错误", "error", retErr)
		return 0, retErr
	}

	return len(ret.EngineTypes), nil
}

// ExecuteTask 执行SEO任务
func (t *SeoProjectTaskService) ExecuteTask(task worker.Task) error {

	slog.Debug("执行SEO任务", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId, "engineType", task.EngineType)

	// 判断余额是否足够
	account, err := service.SerAccount.GetAccount(task.UserId)
	if err != nil {
		slog.Error("获取用户账户失败", "projectId", task.ProjectId, "taskId", task.Id, "error", err.Error())
		return err
	}

	if account.Amount <= 0 {
		slog.Error("用户余额不足", "projectId", task.ProjectId, "taskId", task.Id, "userId", task.UserId, "amount", account.Amount)

		// 暂停该项目下的所有任务

		if pauseErr := t.StopProjectTasks(task.UserId, task.ProjectId); pauseErr != nil {
			slog.Error("暂停项目任务失败", "error", pauseErr)
		}

		return errors.New("insufficient balance")
	}

	var results []models.SeoResults
	var fromCache bool

	existingResults, exisErr := SerSeoResults.GetResultsByKIdAndEngine(task.KeywordId, task.EngineType)
	if exisErr != nil && !errors.Is(exisErr, gorm.ErrRecordNotFound) {
		slog.Error("查询缓存结果失败", "projectId", task.ProjectId, "taskId", task.Id, "error", exisErr.Error())
		return exisErr
	}

	// 如果有当天数据直接使用缓存数据
	if len(existingResults) > 0 {
		results = existingResults
		fromCache = true
	}

	// 调用SerpAPI获取数据
	if len(results) <= 0 {
		// 根据任务表里的关键词ID从关键词表找到关键词
		keyword, keywordErr := SerSeoKeywords.GetOneById(task.KeywordId)
		if keywordErr != nil {
			slog.Error("获取关键词信息失败", "projectId", task.ProjectId, "taskId", task.Id, "error", keywordErr.Error())
			return keywordErr
		}

		// 调用SerpAPI
		results, err = t.querySerpAPIWithPagination(task.EngineType, keyword.KeyName, keyword.Id)
		if err != nil {
			slog.Error("Serp API调用失败", "projectId", task.ProjectId, "taskId", task.Id, "error", err.Error())
			return err
		}

		if len(results) == 0 {
			slog.Error("Serp API调用无查询结果", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId)
			return nil
		}

		// 存储到results表
		if err := SerSeoResults.SaveResults(results); err != nil {
			slog.Error("存储数据到results表失败", "projectId", task.ProjectId, "taskId", task.Id, "error", err.Error())
			return err
		}
	}

	// 从用户域名表里获取当前这个项目配置的域名
	domains, doEr := SerSeoUserDomains.GetsByProIdAndUserIdAndKeyId(task.UserId, task.ProjectId)
	if doEr != nil {
		slog.Error("获取域名配置失败", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId, "error", doEr.Error())
		return doEr
	}

	// 使用事务保证创建排名历史和扣减余额的原子性
	return t.DB().Transaction(func(tx *gorm.DB) error {

		// 获取用户排名数据记录（匹配域名并计算排名变化）
		rankHistories, rankErr := SerSeoUserRankingHistory.GetRankingHistoriesWithTx(tx, task.UserId, task.Id, task.KeywordId, task.EngineType, results, domains)

		if rankErr != nil {
			slog.Error("获取用户历史排名记录失败", "projectId", task.ProjectId, "taskId", task.Id, "error", rankErr.Error)
			return rankErr
		}

		// 根据实际匹配数量扣减余额（每条匹配扣减2额度）
		deductAmount := len(rankHistories) * config.Ext.SerpAPI.ChargeBase.BaseTwo

		// 未匹配到任何数据，记录任务日志更新任务状态直接返回
		if deductAmount <= 0 {
			slog.Debug("无任何用户数据匹配，用户新排名数据添加失败", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId)

			// 更新任务状态和下次执行时间
			if upErr := t.updateTaskAfterExecutionWithTx(tx, task); upErr != nil {
				slog.Error("更新下次定时任务执行时间失败", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId, "error", upErr.Error())
				return upErr
			}
			return nil
		}

		// 有匹配数据，扣减余额
		result := service.SerAccount.DecrementAmount(tx, task.UserId, deductAmount)

		if result.Error != nil {
			slog.Error("扣减用户余额失败", "projectId", task.ProjectId, "taskId", task.Id, "error", result.Error)
			return result.Error
		}

		// 添加用户排名数据
		if adErr := SerSeoUserRankingHistory.CreateRankingHistoriesWith(tx, rankHistories); adErr != nil {
			slog.Error("添加用户排名数据失败", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId, "error", adErr.Error())
			return adErr
		}

		// 更新任务状态和下次执行时间
		if upErr := t.updateTaskAfterExecutionWithTx(tx, task); upErr != nil {
			slog.Error("更新下次定时任务执行时间失败", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId, "error", upErr.Error())
			return upErr
		}

		// 记录定时任务执行日志（成功）
		if !fromCache {
			slog.Debug("调用serpApi方式获取数据", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId)
		} else {
			slog.Debug("从数据表里获取结果数据", "projectId", task.ProjectId, "taskId", task.Id, "keywordId", task.KeywordId, "userId", task.UserId)
		}

		return nil
	})
}

// StopProjectTasks 停止项目的所有任务
func (t *SeoProjectTaskService) StopProjectTasks(userId, projectId int) error {
	return t.DB().Model(&models.SeoProjectTask{}).
		Where("user_id = ? and project_id = ? and deleted_at is null", userId, projectId).
		UpdateColumns(map[string]interface{}{
			"state":      models.TASK_TATE_TO_PAUSE,
			"updated_at": time.Now(),
		}).Error
}

// DeleteProjectTasks 删除项目的所有任务
func (t *SeoProjectTaskService) DeleteProjectTasks(tx *gorm.DB, userId, projectId int) error {

	return tx.Where("user_id = ? and project_id = ?", userId, projectId).
		Delete(&models.SeoProjectTask{}).Error
}

// GetTasksByProjectId 获取项目的所有任务
func (t *SeoProjectTaskService) GetTasksByProjectId(userId, projectId int) ([]models.SeoProjectTask, error) {
	var tasks []models.SeoProjectTask
	err := t.DB().Where("user_id = ? and project_id = ? and deleted_at is null", userId, projectId).Find(&tasks).Error
	return tasks, err
}

// GetTaskById 根据任务ID获取任务
func (t *SeoProjectTaskService) GetTaskById(taskId int) (models.SeoProjectTask, error) {
	var task models.SeoProjectTask
	err := t.DB().Where("id = ? and deleted_at is null", taskId).First(&task).Error
	return task, err
}

// GetTasksDue 获取待执行的任务
func (t *SeoProjectTaskService) GetTasksDue(lastId, batchSize int, endTime time.Time) (tasks []models.SeoProjectTask, err error) {
	err = t.DB().Model(&models.SeoProjectTask{}).Select("seo_project_task.*").
		//Joins("left join seo_project on seo_project.id = seo_project_task.project_id").
		//Where("seo_project_task.id > ? and seo_project_task.state in (-1,1,0)", lastId). // 测试
		// Where("seo_project_task.id > ? and seo_project_task.state in (-1,1,0,2) and seo_project_task.next_run_at <= ? and seo_project.state = ?", lastId, endTime, models.STATE_TO_NORMAL).
		Where("seo_project_task.id > ? and seo_project_task.state <> 2", lastId). // 所有未完成的任务
		Order("seo_project_task.id asc").
		Limit(batchSize + 1).
		Find(&tasks).Error
	return
}

// UpdateTaskState 更新任务状态
func (t *SeoProjectTaskService) UpdateTaskState(taskIds []int, state int8) error {
	return t.DB().Model(&models.SeoProjectTask{}).Where("id in (?)", taskIds).UpdateColumn("state", state).Error
}

// querySerpAPIWithPagination 调用Serp API分页查询排名，获取100条数据
func (t *SeoProjectTaskService) querySerpAPIWithPagination(engineType, keyword string, keywordId int) ([]models.SeoResults, error) {
	var _engines []string

	slog.Info("准备开始调用serpApi接口", "engineType", engineType, "keywordName", keyword)

	allResults := make([]models.SeoResults, 0, 100*len(_engines))

	apiPath, ok := serp_api.SerpApiMap[engineType]

	if !ok {
		slog.Error("Serp API调用失败, 引擎不存在", "engine", engineType, "keyword", keyword)
		return nil, errors.New("搜索引擎不存在；engine:" + engineType)
	}

	// 获取做大分页数
	maxPages := config.Ext.SerpAPI.MaxPage

	for page := 0; page < maxPages; page++ {
		pageIndex := 0

		if page > 0 {
			if engineType == serp_api.ENGINE_TO_BING {
				pageIndex = page*10 + 1
			} else {
				pageIndex = page * 10
			}
		}

		// 构建请求
		req := serp_api.Request{
			EngineType: engineType,
			Keywords:   keyword,
			EngineApi:  apiPath,
		}

		// 根据引擎类型设置分页参数
		if engineType == serp_api.ENGINE_TO_BING {
			req.First = pageIndex
			slog.Info("开始调用serpApi接口", "reqParams", req, "first", pageIndex)
		} else {
			req.Start = pageIndex
			slog.Info("开始调用serpApi接口", "reqParams", req, "start", pageIndex)
		}

		// 调用Serp API
		_resp, err := serp_api.CallWithDefaultClient(req)
		if err != nil {
			slog.Error("Serp API调用失败", "engine", engineType, "keyword", keyword, "page", page+1, "error", err)
			return nil, err
		}

		resp, err := serp_api.ToSearchAPIData(_resp.Data)
		if err != nil {
			slog.Error("解析Serp API响应失败", "engine", engineType, "keyword", keyword, "page", page+1, "error", err)
			return nil, err
		}

		// 如果没有结果，结束分页
		if len(resp.OrganicResults) == 0 {
			break
		}

		currentPage := utils.Convert[int](resp.Pagination.Current)

		for _, item := range resp.OrganicResults {
			link := ""
			if item.Link != nil {
				link = utils.Convert[string](item.Link)
			}

			_now := time.Now()

			result := models.SeoResults{
				EngineType:    engineType,
				RankPosition:  item.Position,
				KeywordName:   keyword,
				KeywordId:     keywordId,
				Title:         item.Title,
				Link:          link,
				Current:       currentPage,
				DisplayedLink: item.DisplayedLink,
				CreatedAt:     _now,
				CreatedDate:   _now,
				UpdatedAt:     _now,
			}
			allResults = append(allResults, result)
		}
	}

	return allResults, nil
}

// updateTaskAfterExecutionWithTx 任务执行完成后更新状态
func (t *SeoProjectTaskService) updateTaskAfterExecutionWithTx(tx *gorm.DB, task worker.Task) error {

	// 更新任务状态
	result := tx.Model(&models.SeoProjectTask{}).
		Where("id = ? and state = ?", task.Id, models.TASK_TATE_TO_RUNNING).
		UpdateColumns(map[string]interface{}{
			"state":      models.TASK_TATE_TO_FINISHED,
			"updated_at": time.Now(),
		})

	if result.Error != nil {
		return result.Error
	}

	// 如果没有更新到记录，说明任务状态已被修改（可能被其他操作暂停或删除）
	if result.RowsAffected == 0 {
		slog.Warn("任务状态更新失败，任务可能已被修改", "taskId", task.Id)
		return errors.New("更新下次执行时间失败")
	}

	return nil
}

// calculateNextRunTime 计算下次执行时间
func (t *SeoProjectTaskService) calculateNextRunTime(cronExpr string) time.Time {
	return cron.CalculateNextRunTime(cronExpr)
}

// BatchUpdateTasks 批量更新任务
func (t *SeoProjectTaskService) BatchUpdateTasks(taskIds []int, state int8) error {
	return t.DB().Model(&models.SeoProjectTask{}).Where("id in (?)", taskIds).UpdateColumn("state", state).Error
}
