package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoProjectKeywordsRouter)
}

// 默认需登录认证的路由
func registerSeoProjectKeywordsRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-project-keywords").Use(middleware.JWTAppAuthMiddleware())
	{
		r.POST("/create", apis.ApiSeoProjectKeywords.Create)
		r.POST("/update", apis.ApiSeoProjectKeywords.Update)
		r.POST("/page", apis.ApiSeoProjectKeywords.QueryPage)
		r.POST("/del", apis.ApiSeoProjectKeywords.Del)
		r.POST("/first-last-rank", apis.ApiSeoProjectKeywords.FirstLastRank)
	}
}
