package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoUserDomainsRouter)
}

// 默认需登录认证的路由
func registerSeoUserDomainsRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-user-domains").Use(middleware.JWTAppAuthMiddleware())
	{
		r.GET("/get", apis.ApiSeoUserDomains.Get)
		r.POST("/create", apis.ApiSeoUserDomains.Create)
		r.POST("/update", apis.ApiSeoUserDomains.Update)
		r.POST("/page", apis.ApiSeoUserDomains.QueryPage)
		r.POST("/del", apis.ApiSeoUserDomains.Del)
	}
}
