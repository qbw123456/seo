package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoDomainsRouter)
}

// 默认需登录认证的路由
func registerSeoDomainsRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-domains").Use(middleware.JwtHandler()).Use(middleware.PermHandler())
	{
		r.GET("/get", apis.ApiSeoDomains.Get)
		r.POST("/create", apis.ApiSeoDomains.Create)
		r.POST("/update", apis.ApiSeoDomains.Update)
		r.POST("/page", apis.ApiSeoDomains.QueryPage)
		r.POST("/del", apis.ApiSeoDomains.Del)
	}
}
