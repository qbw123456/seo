package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoResultsRouter)
}

// 默认需登录认证的路由
func registerSeoResultsRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-results").Use(middleware.JWTAppAuthMiddleware())
	{
		r.GET("/get", apis.ApiSeoResults.Get)
		r.POST("/create", apis.ApiSeoResults.Create)
		r.POST("/update", apis.ApiSeoResults.Update)
		r.POST("/page", apis.ApiSeoResults.QueryPage)
		r.POST("/del", apis.ApiSeoResults.Del)
	}
}
