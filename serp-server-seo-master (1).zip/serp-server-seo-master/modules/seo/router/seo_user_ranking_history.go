package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoUserRankingHistoryRouter)
}

// 默认需登录认证的路由
func registerSeoUserRankingHistoryRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-user-ranking-history").Use(middleware.JWTAppAuthMiddleware())
	{
		r.POST("/page", apis.ApiSeoUserRankingHistory.QueryPage)
		r.Any("/export", apis.ApiSeoUserRankingHistory.Export)
		r.POST("/distribution", apis.ApiSeoUserRankingHistory.Distribution)
	}
}
