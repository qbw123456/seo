package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoProjectRouter)
}

// 默认需登录认证的路由
func registerSeoProjectRouter(v1 *gin.RouterGroup) {

	v1.Group("seo-project").Any("/engine-types", apis.ApiSeoProject.GetEngineTypes)
	r := v1.Group("seo-project").Use(middleware.JWTAppAuthMiddleware())
	{
		r.POST("/get", apis.ApiSeoProject.Get)
		r.POST("/create", apis.ApiSeoProject.Create)
		r.POST("/update", apis.ApiSeoProject.Update)
		r.POST("/update-cron", apis.ApiSeoProject.UpdateCron)
		r.POST("/page", apis.ApiSeoProject.QueryPage)
		r.POST("/del", apis.ApiSeoProject.Del)
		r.POST("/on-off", apis.ApiSeoProject.OnOrOffState)
	}
}
