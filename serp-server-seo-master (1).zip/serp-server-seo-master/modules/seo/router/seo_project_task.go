package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoProjectTaskRouter)
}

// 默认需登录认证的路由
func registerSeoProjectTaskRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-project-task").Use(middleware.JWTAppAuthMiddleware())
	{
		r.POST("/page", apis.ApiSeoProjectTask.QueryPage)
	}
}
