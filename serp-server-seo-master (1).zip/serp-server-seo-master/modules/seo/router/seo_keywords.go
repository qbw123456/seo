package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoKeywordsRouter)
}

// 默认需登录认证的路由
func registerSeoKeywordsRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-keywords").Use(middleware.JwtAdminHandler())
	{
		r.GET("/get", apis.ApiSeoKeywords.Get)
		r.POST("/create", apis.ApiSeoKeywords.Create)
		r.POST("/update", apis.ApiSeoKeywords.Update)
		r.POST("/page", apis.ApiSeoKeywords.QueryPage)
		r.POST("/del", apis.ApiSeoKeywords.Del)
	}
}
