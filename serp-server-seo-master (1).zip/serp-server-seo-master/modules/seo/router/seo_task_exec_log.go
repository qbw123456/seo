package router

import (
	"dilu/common/middleware"
	"dilu/modules/seo/apis"

	"github.com/gin-gonic/gin"
)

func init() {
	routerNoCheckRole = append(routerNoCheckRole, registerSeoTaskExecLogRouter)
}

// 默认需登录认证的路由
func registerSeoTaskExecLogRouter(v1 *gin.RouterGroup) {
	r := v1.Group("seo-task-exec-log").Use(middleware.JWTAppAuthMiddleware())
	{
		r.GET("/get", apis.ApiSeoTaskExecLog.Get)
		r.POST("/create", apis.ApiSeoTaskExecLog.Create)
		r.POST("/update", apis.ApiSeoTaskExecLog.Update)
		r.POST("/page", apis.ApiSeoTaskExecLog.QueryPage)
		r.POST("/del", apis.ApiSeoTaskExecLog.Del)
	}
}
