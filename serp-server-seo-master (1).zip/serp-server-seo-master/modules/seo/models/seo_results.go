package models

import (
	"time"
)

// SeoResults SEO数据结果表
type SeoResults struct {
	Id            int       `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"`                //主键
	EngineType    string    `json:"engineType" gorm:"type:varchar(32);comment:引擎类型；google bing baidu ..."` //引擎类型；google bing baidu ...
	RankPosition  int       `json:"rankPosition" gorm:"type:int;comment:排名位置"`                             //排名位置
	KeywordName   string    `json:"keywordName" gorm:"type:varchar(128);comment:关键词名称"`                    //关键词名称
	KeywordId     int       `json:"keywordId" gorm:"type:int;comment:关键词表ID"`                              //关键词表ID
	Title         string    `json:"title" gorm:"type:varchar(512);comment:名称"`                             //名称
	Link          string    `json:"link" gorm:"type:varchar(512);comment:结果域名1"`                           //结果域名1
	DisplayedLink string    `json:"displayedLink" gorm:"type:varchar(512);comment:结果域名2"`                  //结果域名2
	Current       int       `json:"current" gorm:"type:int;comment:当前页"`                                   //页数
	CreatedAt     time.Time `json:"createdAt" gorm:"type:datetime;comment:创建时间"`                           //创建时间
	CreatedDate   time.Time `json:"createdDate" gorm:"type:date;comment:创建日期"`                             //创建日期
	UpdatedAt     time.Time `json:"updatedAt" gorm:"type:datetime;comment:更新时间"`                           //更新时间
}

const TBSeoResults = "seo_results"

func (SeoResults) TableName() string {
	return TBSeoResults
}
