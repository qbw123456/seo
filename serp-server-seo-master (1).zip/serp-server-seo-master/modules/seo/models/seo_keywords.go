package models

import (
	"time"
)

const (
	KEY_WORDS_STATE_TO_NORMAL      = 1 // 正常
	KEY_WORDS_STATE_TO_NOT_ALLOWED = 2 // 禁止
)

// SeoKeywords SEO关键词表
type SeoKeywords struct {
	Id        int       `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"` //主键
	KeyName   string    `json:"keyName" gorm:"type:varchar(128);comment:关键词名称"`         //关键词名称
	State     int8      `json:"state" gorm:"type:tinyint(1);comment:状态：0：禁用；1：正常"`      //状态：0：禁用；1：正常
	CreatedAt time.Time `json:"createdAt" gorm:"type:datetime;comment:创建时间"`            //创建时间
}

const TBSeoKeywords = "seo_keywords"

func (SeoKeywords) TableName() string {
	return TBSeoKeywords
}
