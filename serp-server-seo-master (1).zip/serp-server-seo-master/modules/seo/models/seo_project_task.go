package models

import (
	"time"

	"gorm.io/gorm"
)

const (
	TASK_TATE_TO_FAILURE  = -1 // 失败
	TASK_TATE_TO_OFF      = 0  // 未开始
	TASK_TATE_TO_RUNNING  = 1  // 执行中
	TASK_TATE_TO_FINISHED = 2  // 完成
	TASK_TATE_TO_PAUSE    = 3  // 暂停
	TASK_TATE_TO_STOP     = 4  // 结束
)

// SeoProjectTask SEO项目任务表
type SeoProjectTask struct {
	Id         int            `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"`              // 主键
	UserId     int            `json:"userId" gorm:"type:int;comment:用户ID"`                                 // 用户ID
	ProjectId  int            `json:"projectId" gorm:"type:int;comment:SEO 项目ID"`                          // SEO 项目ID
	KeywordId  int            `json:"keywordId" gorm:"type:int;comment:关键词ID"`                             // 关键词ID
	EngineType string         `json:"engineType" gorm:"type:varchar(32);comment:搜索引擎类型；google，bing，baidu"` // 搜索引擎类型；google，bing，baidu
	DeviceType string         `json:"deviceType" gorm:"type:varchar(32);comment:设备类型；desktop，mobile"`      // 设备类型；desktop，mobile
	State      int            `json:"state" gorm:"type:tinyint;comment:状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束"`     //状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束
	NextRunAt  *time.Time     `json:"nextRunAt" gorm:"type:datetime;comment:下次执行时间"`                       // 下次执行时间
	CreatedAt  time.Time      `json:"createdAt" gorm:"type:datetime;comment:创建时间"`                         // 创建时间
	UpdatedAt  time.Time      `json:"updatedAt" gorm:"type:datetime;comment:更新时间"`                         // 更新时间
	DeletedAt  gorm.DeletedAt `json:"deletedAt,omitempty" gorm:"type:datetime;comment 删除时间"`               // 删除时间
}

type SeoProjectTaskExtend struct {
	SeoProjectTask
	KeyName string `json:"keyName"`
}

const TBSeoProjectTask = "seo_project_task"

func (SeoProjectTask) TableName() string {
	return TBSeoProjectTask
}
