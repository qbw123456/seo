package models

import ("gorm.io/gorm"
    "time"
    
)

//SEO域名表
type SeoDomains struct {
    
    Id int `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"` //主键
    DomainName string `json:"domainName" gorm:"type:varchar(250);comment:域名"` //域名 
    CreatedAt time.Time `json:"createdAt" gorm:"type:datetime;comment:创建时间"` //创建时间 
    DeletedAt gorm.DeletedAt `json:"-" gorm:"index;comment:删除时间"`     //删除时间
}

const TBSeoDomains = "seo_domains"

func (SeoDomains) TableName() string {
    return TBSeoDomains
}


