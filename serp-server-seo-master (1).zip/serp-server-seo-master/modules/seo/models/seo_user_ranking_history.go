package models

import (
	"time"

	"gorm.io/gorm"
)

// SeoUserRankingHistory SEO用户排名数据变化记录
type SeoUserRankingHistory struct {
	Id           int            `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"` //主键
	UserId       int            `json:"userId" gorm:"type:int;comment:用户ID"`                    //用户ID
	ProjectId    int            `json:"projectId" gorm:"type:int;comment:项目ID"`                 //项目ID
	TaskId       int            `json:"taskId" gorm:"type:int;comment:任务ID"`                    //任务ID
	KeywordId    int            `json:"keywordId" gorm:"type:int;comment:关键词表ID"`               //关键词表ID
	DomainId     int            `json:"domainId" gorm:"type:int;comment:域名表ID"`                 //域名表ID
	EngineType   string         `json:"engineType" gorm:"type:varchar(30);comment:搜索引擎"`        //搜索引擎
	RankPosition int            `json:"rankPosition" gorm:"type:int;comment:排名位置"`              //排名位置
	PreRanking   int            `json:"preRanking" gorm:"type:int;comment:上次排名位置"`              //上次排名位置
	RankChange   int            `json:"rankChange" gorm:"type:int;comment:排名变化"`                //排名变化
	Amount       int            `json:"amount" gorm:"type:int;comment:消耗点数"`                    //消耗点数
	CreatedAt    time.Time      `json:"createdAt" gorm:"type:datetime;comment:创建时间"`            //创建时间
	CreatedDate  time.Time      `json:"createdDate" gorm:"type:date;comment:创建日期"`              //创建日期
	DeletedAt    gorm.DeletedAt `json:"deletedAt,omitempty" gorm:"type:datetime;comment 删除时间"`  // 删除时间
}

const TBSeoUserRankingHistory = "seo_user_ranking_history"

func (SeoUserRankingHistory) TableName() string {
	return TBSeoUserRankingHistory
}
