package models

type EngineType struct {
	Google string `json:"google"`
	Bing   string `json:"bing"`
}

type DeviceType struct {
	Pc     string `json:"pc"`
	Mobile string `json:"mobile"`
}
