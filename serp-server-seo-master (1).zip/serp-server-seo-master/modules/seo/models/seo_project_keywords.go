package models

import (
	"time"

	"gorm.io/gorm"
)

// SEO用户域名配置表
type SeoProjectKeywords struct {
	Id        uint           `json:"id" gorm:"type:int unsigned;primaryKey;autoIncrement;comment:主键"` //主键
	UserId    int            `json:"userId" gorm:"type:int;comment:用户ID"`                             //用户ID
	ProjectId int            `json:"projectId" gorm:"type:int;comment:项目ID"`                          //项目ID
	KeywordId int            `json:"keywordId" gorm:"type:int;comment:KeywordId"`                     //
	KeyName   string         `json:"keyName" gorm:"type:varchar(128);comment:关键词名称"`                  //关键词名称
	IsActive  int8           `json:"isActive" gorm:"type:tinyint;comment:是否启用；0：否；1：是"`               //是否启用；0：否；1：是
	CreatedAt time.Time      `json:"createdAt" gorm:"type:datetime;comment:创建时间"`                     //创建时间
	DeletedAt gorm.DeletedAt `json:"deletedAt,omitempty" gorm:"type:datetime;comment 删除时间"`           // 删除时间
}

const TBSeoProjectKeywords = "seo_project_keywords"

func (SeoProjectKeywords) TableName() string {
	return TBSeoProjectKeywords
}
