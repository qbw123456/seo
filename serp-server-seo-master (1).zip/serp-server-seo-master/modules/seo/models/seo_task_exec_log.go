package models

import (
	"time"
)

// SeoTaskExecLog SEO项目任务执行记录表
type SeoTaskExecLog struct {
	Id                int       `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"`          //主键
	UserId            int       `json:"userId" gorm:"type:int;comment:用户ID"`                             //用户ID
	ProjectId         int       `json:"projectId" gorm:"type:int;comment:项目ID"`                          //项目ID
	TaskId            int       `json:"taskId" gorm:"type:int;comment:任务ID"`                             //任务ID
	StartTime         time.Time  `json:"startTime" gorm:"type:datetime;comment:任务开始时间"`                 //任务开始时间
	FinishedTime      *time.Time `json:"finishedTime,omitempty" gorm:"type:datetime;comment:任务完成时间"`    //任务完成时间（执行中为NULL）
	State             int8      `json:"state" gorm:"type:tinyint;comment:状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束"` //状态：-1失败 0未开始 1执行中 2完成 3暂停 4结束
	TotalKeyworks     int       `json:"totalKeyworks" gorm:"type:int;comment:总关键词数"`                     //总关键词数
	ProcessedKeyworks int       `json:"processedKeyworks" gorm:"type:int;comment:已执行关键词数"`               //已执行关键词数
	SuccessCount      int       `json:"successCount" gorm:"type:int;comment:执行成功数"`                      //执行成功数
	FaildCount        int       `json:"faildCount" gorm:"type:int;comment:执行失败数"`                        //执行失败数
	ApiCount          uint      `json:"apiCount" gorm:"type:int unsigned;comment:api调用数"`                //api调用数
	ErrMsg            string    `json:"errMsg" gorm:"type:varchar(512);comment:错误信息"`                    //错误信息
	CreatedAt         time.Time `json:"createdAt" gorm:"type:datetime;comment:创建时间"`                     //创建时间
}

const TBSeoTaskExecLog = "seo_task_exec_log"

func (SeoTaskExecLog) TableName() string {
	return TBSeoTaskExecLog
}
