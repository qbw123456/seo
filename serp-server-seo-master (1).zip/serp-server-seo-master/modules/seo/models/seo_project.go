package models

import (
	"time"

	"gorm.io/datatypes"
	"gorm.io/gorm"
)

const (
	STATE_TO_NORMAL = 1 // 正常
	STATE_TO_STOP   = 2 //停止
)

// SeoProject SEO项目配置表
type SeoProject struct {
	Id           int                         `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"`                                //主键
	UserId       int                         `json:"userId" gorm:"type:int;comment:用户ID"`                                                   //用户ID
	ProName      string                      `json:"proName" gorm:"type:varchar(64);comment:项目名称"`                                          //项目名称
	KeywordNum   int                         `json:"keywordNum" gorm:"type:int;comment:关键词数量"`                                              //关键词数量
	DomainNum    int                         `json:"domainNum" gorm:"type:int;comment:域名数量"`                                                //域名数量
	EngineTypes  datatypes.JSONSlice[string] `json:"engineTypes" gorm:"type:json;comment:搜索引擎类型；google，bing，baidu"`                         //搜索引擎类型；google，bing，baidu
	DeviceTypes  datatypes.JSONSlice[string] `json:"deviceTypes" gorm:"type:json;comment:设备类型；pc，mobbile"`                                  //设备类型；pc，mobbile
	Ranking      int8                        `json:"ranking" gorm:"type:tinyint;comment:排名设置；1:前10名，2:前20名， 3:前30名， 4:前40名，5:前50名，6：前100名"` //排名设置；1:前10名，2:前20名， 3:前30名， 4:前40名，5:前50名，6：前100名
	LifeTime     time.Time                   `json:"lifeTime" gorm:"type:datetime;comment:项目生命周期"`                                          //项目生命周期
	SchType      string                      `json:"schType" gorm:"type:varchar(16);comment:调度类型：hourly，daily，weekly，monthly"`              // 调度类型：hourly，daily，weekly，monthly
	Days         string                      `json:"days" gorm:"type:varchar(32);comment:执行周期天数"`                                           // 执行周期天数
	Hour         int                         `json:"hour" gorm:"type:tinyint;comment:具体执行小时"`                                               //具体执行小时
	Minute       int                         `json:"minute" gorm:"type:tinyint;comment:具体执行分钟"`                                             //具体执行分钟
	CronExpr     string                      `json:"cronExpr" gorm:"type:varchar(64);comment:cron表达式"`                                      // cron表达式
	NextRunAt    time.Time                   `json:"nextRunAt" gorm:"type:datetime;comment:下次执行时间"`                                         //下次执行时间
	LastRunAt    *time.Time                  `json:"lastRunAt" gorm:"type:datetime;comment:上次执行时间"`                                         //上次执行时间
	PendingTasks int64                       `json:"pendingTasks" gorm:"type:int;comment:待执行任务数"`                                           // 待执行任务数
	State        int8                        `json:"state" gorm:"type:tinyint(1);comment:项目状态；1：正常；2：停止"`                                   //项目状态；1：正常；2：停止
	CreatedAt    time.Time                   `json:"createdAt" gorm:"type:datetime;comment:创建时间"`                                           //创建时间
	UpdatedAt    time.Time                   `json:"updatedAt" gorm:"type:datetime;comment:更新时间"`                                           //更新时间
	DeletedAt    gorm.DeletedAt              `json:"deletedAt,omitempty" gorm:"type:datetime; comment 删除时间"`                                // 删除时间
}

const TBSeoProject = "seo_project"

func (SeoProject) TableName() string {
	return TBSeoProject
}

func (s *SeoProject) ValidEnginTypes() bool {
	for _, engin := range s.EngineTypes {
		if engin != "google" && engin != "bing" && engin != "baidu" {
			return false
		}
	}
	return true
}

func (s *SeoProject) ValidDeviceTypes() bool {
	for _, device := range s.DeviceTypes {
		if device != "pc" && device != "mobile" {
			return false
		}
	}
	return true
}
