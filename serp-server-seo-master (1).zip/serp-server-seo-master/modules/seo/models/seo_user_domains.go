package models

import (
	"time"

	"gorm.io/gorm"
)

const (
	DOMAIN_IS_ACTIVE_OK = 1 // 匹配
	DOMAIN_IS_ACIVE_NO  = 0 // 不匹配
)

// SEO用户域名配置表
type SeoUserDomains struct {
	Id         int            `json:"id" gorm:"type:int;primaryKey;autoIncrement;comment:主键"` //主键
	UserId     int            `json:"userId" gorm:"type:int;comment:用户ID"`                    //用户ID
	ProjectId  int            `json:"projectId" gorm:"type:int;comment:项目ID"`                 //项目ID
	DomainId   int            `json:"domainId" gorm:"type:int;comment:域名ID"`                  //域名ID
	DomainName string         `json:"domainName" gorm:"type:varchar(512);comment:域名"`         //域名
	IsActive   int            `json:"isActive" gorm:"type:tinyint;comment:是否匹配；0：否；1：是"`      //是否匹配；0：否；1：是
	DomainType int            `json:"domainType" gorm:"type:tinyint;comment:域名类型；1：根域；2：子域"`  // 域名类型
	CreatedAt  time.Time      `json:"createdAt" gorm:"type:datetime;comment:创建时间"`            //创建时间
	DeletedAt  gorm.DeletedAt `json:"deletedAt,omitempty" gorm:"type:datetime;comment 删除时间"`  // 删除时间
}

const TBSeoUserDomains = "seo_user_domains"

func (SeoUserDomains) TableName() string {
	return TBSeoUserDomains
}
